// Pinned to the independently verified v0.25 mock-USDG rehearsal. No URL override.
import {FINAL_IDS} from './final-rehearsal-config.mjs';
export const COLLECTOR = Object.freeze({
 chainId:46630,
 collection:'0xBFE18B1F7FbF42Aa32B4E3455a020901d4D573EC',
 art:'0x22Fa6A26298001Ce784B95dfda67A20317713858',
 payment:'0x85F72dC797f39ad93F73aFf8d59A74762d4D34EE',
 treasury:'0xE08Da0c38D8292256978834314fFa423f477c67d',
 provenance:'0xebf21d1a0c86678e70d8f9420d6c9ef04308d2b2bf1bf4db439e75d0e54e70d4',
 price:100000000n, supply:100, specimenIds:FINAL_IDS,
 directory:'output/onchain/final-v025/'
});
export function creatureIndex(id){return COLLECTOR.specimenIds.indexOf(id);}
export function creaturePage(id){const index=creatureIndex(id);return index<0?0:Math.floor(index/12);}
export function selectedCreature(search){
 const raw=new URLSearchParams(search).get('token');
 return raw!==null&&/^\d+$/.test(raw)&&creatureIndex(Number(raw))>=0?Number(raw):1;
}
export function mintBlocker(s){
 if(!s)return 'Checking availability…';
 if(s.paused)return 'Test mint is paused';
 if(s.sold)return 'This creature already has a home';
 if(!s.started)return 'This release has not opened yet';
 if(!s.account)return 'Connect a wallet to continue';
 if(s.hasMinted)return 'This wallet has already minted its one creature';
 if(s.balance<COLLECTOR.price)return 'Get free mock USDG to continue';
 if(s.allowance<COLLECTOR.price)return 'Approve 100 mock USDG to continue';
 return null;
}
export async function assertWallet(provider,account){
 const chain=await provider.request({method:'eth_chainId'});
 if(BigInt(chain)!==BigInt(COLLECTOR.chainId))throw Error('Switch to Robinhood Chain Testnet and reconnect.');
 const accounts=await provider.request({method:'eth_accounts'});
 if(!account||accounts?.[0]?.toLowerCase()!==account.toLowerCase())throw Error('Wallet account changed. Reconnect before continuing.');
}
