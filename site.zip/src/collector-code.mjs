// Runtime hashes read from Robinhood RPC after all 100 v0.25 media records and deployment receipts passed verification.
export const CODE_HASHES=Object.freeze({
  "collection": "0x3e99e9473c606964f3b2b5a33167d980e886a720d86b423a97b74779928fb133",
  "art": "0xd30424543b4ae96e225988c63023846722bfd4350255a00fa91df59a48eff644",
  "payment": "0x71a2d14e00a4f918a55355417ec732f46803002695fbf53bd052d040296a826e"
});
