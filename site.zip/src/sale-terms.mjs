// Creature-first direction accepted on 2026-09-16. The pilot size and single
// payment route are implementation proposals, not finalized mainnet terms.
export const SALE_TERMS = Object.freeze({
  supply: 10_000,
  initialReleaseSupply: 100,
  maxReleaseSupply: 100,
  currency: 'USD',
  priceUsdCents: null, // Public paid pricing remains undecided.
  paymentFamilies: Object.freeze(['USDG']),
  futurePaymentFamilies: Object.freeze(['ETH', 'STOCK_TOKEN']),
  stockTokenPolicy: 'verified-canonical-contracts-with-available-quotes',
  treasurySettlementTarget: 'USDG',
  launchFormat: 'public',
  strategy: 'creature-first',
  collectionTokenRequired: false,
  liquidityRequired: false,
  rewardsRequired: false,
  live: false
});

export function mintPriceLabel(config) {
  if(config.pricingMode === 'usd') {
    return Number.isSafeInteger(config.priceUsdCents) && config.priceUsdCents > 0
      ? `$${(config.priceUsdCents / 100).toFixed(config.priceUsdCents % 100 ? 2 : 0)} USD`
      : 'To be decided';
  }
  return typeof config.priceWei === 'string' && /^\d+$/.test(config.priceWei)
    ? `${BigInt(config.priceWei)} wei` : 'To be decided';
}
