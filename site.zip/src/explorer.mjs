export function tokenFromSearch(search, fallback = 738) {
  const value = new URLSearchParams(search).get("token");
  if (value === null || !/^\d{1,4}$/.test(value)) return fallback;
  const id = Number(value);
  return id >= 0 && id < 10_000 ? id : fallback;
}

export function readFavorites(raw) {
  try {
    const values = JSON.parse(raw);
    if (!Array.isArray(values)) return new Set();
    return new Set(values.filter((id) => Number.isInteger(id) && id >= 0 && id < 10_000));
  } catch { return new Set(); }
}

export function filterCollection(collection, { query = "", side = "all", form = "all", trait = "all", savedOnly = false, favorites = new Set() } = {}) {
  const text = query.trim().toLowerCase();
  const numeric = /^#?\d{1,4}$/.test(text) ? Number(text.replace("#", "")) : null;
  return collection.filter((item) => {
    if (trait !== "all") {
      const [key, value] = trait.split(":");
      if (item.traits[key]?.value !== value) return false;
    }
    if (savedOnly && !favorites.has(item.id)) return false;
    if (side === "bear" && item.balance >= 40) return false;
    if (side === "hybrid" && (item.balance < 40 || item.balance > 60)) return false;
    if (side === "bull" && item.balance <= 60) return false;
    if (form !== "all" && item.traits.form.value !== form) return false;
    if (!text) return true;
    if (numeric !== null) return item.id === numeric;
    return [item.name, item.rarity, ...Object.values(item.traits).map(({ label }) => label), item.personality.title]
      .some((value) => value.toLowerCase().includes(text));
  });
}
