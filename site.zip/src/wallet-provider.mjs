import {ROBINHOOD_TESTNET,selectNetwork} from './launch-config.mjs';

// EIP-6963 avoids routing Rabby requests through another extension's default provider.
// Wallet names/flags are self-reported display hints, not a trust guarantee.
export function discoverWallets(win,onChange){
 const entries=[];
 const list=()=>[...entries].sort((a,b)=>Number(b.isRabby)-Number(a.isRabby));
 function add(provider,info={}){
  if(typeof provider?.request!=='function')return;
  const isRabby=info.rdns==='io.rabby'||provider.isRabby===true;
  let entry=entries.find(e=>e.provider===provider);
  if(!entry){entry={id:String(entries.length),provider,name:isRabby?'Rabby Wallet':String(info.name||'Browser wallet'),isRabby};entries.push(entry);}
  else if(isRabby){entry.isRabby=true;entry.name='Rabby Wallet';}
  onChange(list());
 }
 win.addEventListener('eip6963:announceProvider',event=>add(event.detail?.provider,event.detail?.info));
 function scan(){
  win.dispatchEvent(new win.Event('eip6963:requestProvider'));
  const injected=win.ethereum;
  if(Array.isArray(injected?.providers))injected.providers.forEach(p=>add(p));
  add(injected);onChange(list());
 }
 win.addEventListener('ethereum#initialized',scan);
 scan();return {list,scan};
}

export async function connectWallet(provider,owner,network=ROBINHOOD_TESTNET){
 if(typeof provider?.request!=='function')throw Error('No wallet detected. Open this page in the browser where Rabby is installed.');
 const accounts=await provider.request({method:'eth_requestAccounts'});
 if(!Array.isArray(accounts)||typeof accounts[0]!=='string')throw Error('No account was shared. Unlock Rabby and approve the connection.');
 if(accounts[0].toLowerCase()!==owner.toLowerCase())throw Error('Select the approved owner wallet in Rabby: '+owner);
 await selectNetwork(provider,network);
 return accounts[0];
}
