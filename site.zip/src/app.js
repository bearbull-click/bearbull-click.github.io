import { tokenFromSearch, readFavorites, filterCollection } from "./explorer.mjs";
import {
  COLLECTION_SIZE,
  generateCollection,
  hornExpressionFor,
  pools,
  normalizeTokenId,
  spectrumAnatomy
} from "./core.mjs?v=43-insiders";

const canvas = document.querySelector("#portrait");
const ctx = canvas.getContext("2d", { alpha: false });
ctx.imageSmoothingEnabled = false;

const els = {
  id: document.querySelector("#specimen-id"),
  name: document.querySelector("#specimen-name"),
  rarity: document.querySelector("#rarity-badge"),
  points: document.querySelector("#rarity-score"),
  spectrum: document.querySelector("#spectrum"),
  spectrumValue: document.querySelector("#spectrum-value"),
  bearPercent: document.querySelector("#bear-percent"),
  bullPercent: document.querySelector("#bull-percent"),
  ticker: document.querySelector("#ticker-balance"),
  traitList: document.querySelector("#trait-list"),
  personality: document.querySelector("#personality-title"),
  habit: document.querySelector("#personality-habit"),
  conviction: document.querySelector("#personality-conviction"),
  voiceTrigger: document.querySelector("#voice-trigger"),
  roll: document.querySelector("#roll-button"),
  background: document.querySelector("#background-button"),
  sound: document.querySelector("#sound-button"),
  save: document.querySelector("#save-button"),
  soundNote: document.querySelector("#sound-note"),
  rack: document.querySelector("#specimen-rack"),
  habitatRack: document.querySelector("#habitat-rack"),
  tokenForm: document.querySelector("#token-form"),
  tokenInput: document.querySelector("#token-input"),
  previous: document.querySelector("#previous-token"),
  next: document.querySelector("#next-token")
};

const colors = {
  ink: "#07090a",
  soot: "#111617",
  bone: "#eadcbe",
  orange: "#ff5c35",
  honey: "#ffc43d",
  blue: "#3478f6",
  mint: "#5ee0a4",
  grass: "#25a463",
  mud: "#6c4328",
  sky: "#50b6cc",
  violet: "#6c4bd1",
  aqua: "#52c7d8",
  coral: "#e85b4a",
  lime: "#a9d94f"
};

const lofi = {
  night: "#0f4543",
  pine: "#20745b",
  moss: "#63a777",
  fog: "#a8d5bb",
  rain: "#5b9fba",
  storm: "#3f5d92",
  snow: "#e6eadf",
  cave: "#6b4d39",
  earth: "#98684a",
  sand: "#efb769",
  ember: "#ff6535",
  dusk: "#ad6f7d"
};

const habitatSystem = [
  { value: "jetrunway", label: "INFINITE RUNWAY", motion: "RUNWAY LIGHTS", tier: "MYTHIC" },
  { value: "ratecut", label: "WAITING FOR RATE CUTS", motion: "CLOCK TICK", tier: "EPIC" },
  { value: "chargeyard", label: "AFTER HOURS CHARGING", motion: "CHARGER PULSE", tier: "MYTHIC" },
  { value: "datacenter", label: "SERVER FARM", motion: "IDLE LIGHTS", tier: "EPIC" },
  { value: "cactusgarden", label: "CACTUS BREAK", motion: "DESERT CLOUD", tier: "RARE" },
  { value: "cloudnine", label: "CLOUD NINE TO FIVE", motion: "CLOUD DRIFT", tier: "EPIC" },
  { value: "forest", label: "PINE FOREST", motion: "FIREFLIES", tier: "COMMON" },
  { value: "sky", label: "OPEN SKY", motion: "CLOUD DRIFT", tier: "COMMON" },
  { value: "sunny", label: "SUNNY DAY", motion: "CLOUD DRIFT", tier: "COMMON" },
  { value: "grass", label: "GRASS FIELD", motion: "WHEAT SWAY", tier: "UNCOMMON" },
  { value: "mud", label: "MUD PIT", motion: "PUDDLE RINGS", tier: "UNCOMMON" },
  { value: "rainwindow", label: "RAIN WINDOW", motion: "WINDOW RAIN", tier: "UNCOMMON" },
  { value: "bamboo", label: "BAMBOO GROVE", motion: "FALLING LEAF", tier: "RARE" },
  { value: "cave", label: "BEAR CAVE", motion: "CRYSTAL GLINT", tier: "RARE" },
  { value: "fire", label: "FIRELIGHT ROOM", motion: "EMBER LOOP", tier: "RARE" },
  { value: "storm", label: "STORM PLATEAU", motion: "PASSING RAIN", tier: "RARE" },
  { value: "desert", label: "RED DESERT", motion: "HEAT RIPPLE", tier: "EPIC" },
  { value: "ice", label: "FROZEN LAKE", motion: "ICE GLINT", tier: "EPIC" },
  { value: "snow", label: "SNOW CABIN", motion: "SNOWFALL", tier: "EPIC" },
  { value: "lab", label: "COMPUTER LAB", motion: "SIGNAL SCAN", tier: "EPIC" },
  { value: "rooftop", label: "NIGHT ROOFTOP", motion: "ANTENNA SIGNAL", tier: "MYTHIC" },
  { value: "moon", label: "MOON PASTURE", motion: "STAR GLINT", tier: "MYTHIC" },
  { value: "mountain", label: "MOUNTAIN PASS", motion: "CLOUD DRIFT", tier: "COMMON" },
  { value: "blue", label: "BLUE HOUR", motion: "TIDAL GLINT", tier: "COMMON" },
  { value: "horizon", label: "CLEAN HORIZON", motion: "LOW WIND", tier: "UNCOMMON" },
  { value: "sunset", label: "CORAL SUNSET", motion: "WATER GLINT", tier: "UNCOMMON" },
  { value: "oasis", label: "OASIS SIGNAL", motion: "PALM SWAY", tier: "RARE" },
  { value: "volcano", label: "VOLCANIC RIDGE", motion: "LAVA PULSE", tier: "RARE" },
  { value: "aurora", label: "AURORA RANGE", motion: "FOLDED LIGHT", tier: "EPIC" },
  { value: "cityrain", label: "NEON ALLEY", motion: "NEON RAIN", tier: "EPIC" }
];
const habitatMotion = Object.fromEntries(habitatSystem.map(({ value, motion }) => [value, motion]));
const habitatByValue = Object.fromEntries(habitatSystem.map((habitat, index) => [habitat.value, { ...habitat, index }]));

const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
const collection = generateCollection(COLLECTION_SIZE);
const rackIds = [9963, 22, 231, 588, 5, 24, 64, 43];
let specimen = collection[tokenFromSearch(window.location.search)];
let frame = 0;
let lastFrameAt = 0;
let reactingUntil = 0;
let audioContext;
let soundOn = false;
let habitatPreviews = [];
let backgroundViewIndex = habitatByValue[specimen.traits.backdrop.value].index;
const explorer = {
  search: document.querySelector("#creature-search"), side: document.querySelector("#spectrum-filter"),
  form: document.querySelector("#form-filter"), saved: document.querySelector("#saved-filter"),
  trait: document.querySelector("#trait-filter"),
  favorite: document.querySelector("#favorite-button"), share: document.querySelector("#share-button"),
  status: document.querySelector("#collector-status"), count: document.querySelector("#creature-count"),
  page: document.querySelector("#creature-page"), previous: document.querySelector("#previous-page"),
  next: document.querySelector("#next-page"), empty: document.querySelector("#creature-empty")
};
let favorites = new Set();
try { favorites = readFavorites(localStorage.getItem("bearbulls:favorites:v1")); } catch {}
let explorerPage = 0;
let savedOnly = false;
const pageSize = 12;
function updateCollector() {
  if (!explorer.favorite) return;
  const saved = favorites.has(specimen.id);
  explorer.favorite.setAttribute("aria-pressed", String(saved));
  explorer.favorite.textContent = saved ? "SAVED FAVOURITE ★" : "SAVE FAVOURITE ☆";
  document.querySelector("#specimen-lineage").textContent = `${specimen.traits.bearKind.label} × ${specimen.traits.bullKind.label} / ${specimen.traits.form.label}`;
}
function specimenUrl() {
  const url = new URL(window.location.href);
  url.searchParams.set("token", String(specimen.id).padStart(4, "0"));
  url.hash = "top";
  return url;
}

function rect(target, color, x, y, w, h) {
  target.fillStyle = color;
  target.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function pixelEllipse(target, color, centerX, centerY, radiusX, radiusY) {
  const cx = Math.round(centerX);
  const cy = Math.round(centerY);
  const rx = Math.max(0, Math.round(radiusX));
  const ry = Math.max(0, Math.round(radiusY));
  if (rx === 0 || ry === 0) {
    rect(target, color, cx - rx, cy - ry, rx * 2 + 1, ry * 2 + 1);
    return;
  }
  for (let offset = -ry; offset <= ry; offset += 1) {
    const normalizedY = offset / (ry + 0.45);
    const span = Math.floor(rx * Math.sqrt(Math.max(0, 1 - normalizedY * normalizedY)));
    rect(target, color, cx - span, cy + offset, span * 2 + 1, 1);
  }
}

function pixelRoundRect(target, color, x, y, width, height, radius = 3) {
  const left = Math.round(x);
  const top = Math.round(y);
  const w = Math.max(1, Math.round(width));
  const h = Math.max(1, Math.round(height));
  const r = Math.max(0, Math.min(Math.round(radius), Math.floor(w / 2), Math.floor(h / 2)));
  for (let row = 0; row < h; row += 1) {
    const edge = Math.min(row, h - 1 - row);
    const distance = Math.max(0, r - edge - 0.5);
    const inset = edge >= r ? 0 : Math.round(r - Math.sqrt(Math.max(0, r * r - distance * distance)));
    rect(target, color, left + inset, top + row, Math.max(1, w - inset * 2), 1);
  }
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function mixHex(from, to, amount) {
  const parse = (value) => {
    const match = /^#([0-9a-f]{6})$/i.exec(value);
    if (!match) return null;
    return [0, 2, 4].map((offset) => Number.parseInt(match[1].slice(offset, offset + 2), 16));
  };
  const start = parse(from);
  const end = parse(to);
  if (!start || !end) return from;
  return `#${start.map((channel, index) => Math.round(channel + (end[index] - channel) * amount)
    .toString(16)
    .padStart(2, "0")).join("")}`;
}

function polygon(target, color, points) {
  // Scan-convert to whole pixels. Canvas path fills anti-alias diagonals even
  // when image smoothing is off, introducing muddy colors at avatar scale.
  const top = Math.floor(Math.min(...points.map(([, y]) => y)));
  const bottom = Math.ceil(Math.max(...points.map(([, y]) => y)));
  for (let y = top; y < bottom; y += 1) {
    const intersections = [];
    for (let i = 0; i < points.length; i += 1) {
      const [ax, ay] = points[i];
      const [bx, by] = points[(i + 1) % points.length];
      if ((ay <= y + 0.5 && by > y + 0.5) || (by <= y + 0.5 && ay > y + 0.5)) {
        intersections.push(ax + (y + 0.5 - ay) * (bx - ax) / (by - ay));
      }
    }
    intersections.sort((a, b) => a - b);
    for (let i = 0; i + 1 < intersections.length; i += 2) {
      const x = Math.ceil(intersections[i] - 0.5);
      rect(target, color, x, y, Math.ceil(intersections[i + 1] - 0.5) - x, 1);
    }
  }
}

function cloud(target, x, y, color = colors.bone) {
  rect(target, color, x, y + 2, 12, 3);
  rect(target, color, x + 3, y, 5, 5);
}

function drawBackdrop(target, item, f) {
  const scene = item.traits.backdrop.value;
  if (scene === "forest") {
    rect(target, "#79b89a", 0, 0, 64, 64);
    cloud(target, 5, 7);
    rect(target, "#315436", 0, 41, 64, 23);
    [4, 14, 48, 58].forEach((x, i) => {
      rect(target, "#563c2e", x + 3, 23 + i % 2, 3, 27);
      polygon(target, i % 2 ? "#234b38" : "#173b2f", [[x, 8], [x - 5, 24], [x + 10, 24]]);
      polygon(target, "#285c3c", [[x + 4, 15], [x - 4, 34], [x + 12, 34]]);
    });
  } else if (scene === "sky") {
    rect(target, colors.sky, 0, 0, 64, 64);
    cloud(target, 5, 8);
    cloud(target, 45, 17);
    rect(target, "#397f49", 0, 50, 64, 14);
    rect(target, "#6fac4b", 0, 47, 64, 5);
  } else if (scene === "grass") {
    rect(target, "#e3c86d", 0, 0, 64, 64);
    rect(target, "#78aa4b", 0, 30, 64, 34);
    rect(target, "#4c813d", 0, 45, 64, 19);
    for (let x = 2; x < 64; x += 7) {
      rect(target, "#315f37", x, 39 + (x % 3), 1, 8);
      rect(target, x % 2 ? colors.bone : colors.orange, x - 1, 38 + (x % 3), 3, 2);
    }
  } else if (scene === "mud") {
    rect(target, "#b99a6d", 0, 0, 64, 64);
    cloud(target, 42, 8, "#ddd0b5");
    rect(target, "#65422f", 0, 34, 64, 30);
    [[3, 41, 17], [30, 47, 25], [15, 57, 13]].forEach(([x, y, w]) => {
      rect(target, colors.ink, x - 1, y - 1, w + 2, 5);
      rect(target, "#4d7081", x, y, w, 3);
    });
  } else if (scene === "bamboo") {
    rect(target, "#5c8f45", 0, 0, 64, 64);
    [3, 12, 22, 45, 56].forEach((x, i) => {
      rect(target, i % 2 ? "#1d4f33" : "#2e6738", x, 0, 4, 64);
      for (let y = 6 + i; y < 60; y += 12) rect(target, "#9bab45", x - 1, y, 6, 2);
    });
    polygon(target, "#173a2d", [[0, 50], [12, 35], [20, 55], [32, 39], [44, 57], [64, 40], [64, 64], [0, 64]]);
  } else if (scene === "cave") {
    rect(target, "#3c3230", 0, 0, 64, 64);
    [[3, 6], [45, 3], [9, 45], [50, 39]].forEach(([x, y]) => rect(target, "#68564c", x, y, 10, 5));
    polygon(target, "#151315", [[9, 64], [10, 28], [16, 15], [25, 9], [39, 9], [49, 17], [55, 31], [56, 64]]);
  } else if (scene === "storm") {
    rect(target, "#303b67", 0, 0, 64, 64);
    rect(target, "#171c37", 0, 9, 64, 10);
    polygon(target, colors.honey, [[49, 4], [43, 18], [48, 18], [41, 34], [54, 15], [49, 15]]);
    rect(target, "#405637", 0, 45, 64, 19);
    for (let x = 3 + (f % 3); x < 64; x += 9) rect(target, colors.blue, x, 24, 1, 8);
  } else if (scene === "desert") {
    rect(target, "#d95136", 0, 0, 64, 64);
    rect(target, colors.orange, 0, 27, 64, 37);
    polygon(target, "#82342b", [[0, 42], [10, 31], [17, 41], [29, 25], [40, 44], [52, 30], [64, 39], [64, 64], [0, 64]]);
    rect(target, "#313528", 7, 34, 2, 15);
    rect(target, "#313528", 4, 38, 5, 2);
  } else if (scene === "ice") {
    rect(target, "#75b9d0", 0, 0, 64, 64);
    polygon(target, colors.bone, [[0, 35], [11, 17], [20, 34], [32, 13], [48, 35], [57, 21], [64, 34], [64, 50], [0, 50]]);
    rect(target, "#90d4d3", 0, 47, 64, 17);
    rect(target, "#d8eee4", 5, 53, 25, 2);
  } else {
    rect(target, colors.soot, 0, 0, 64, 64);
    rect(target, colors.bone, 45, 5, 10, 10);
    rect(target, colors.honey, 48, 8, 7, 7);
    rect(target, "#263d34", 0, 44, 64, 20);
    for (let x = 3; x < 64; x += 8) rect(target, colors.mint, x, 38 + (x % 4), 1, 10);
  }
  rect(target, "rgba(9,8,7,.12)", 0, 58, 64, 6);
}

function drawWeather(target, item, f) {
  const weather = item.traits.weather.value;
  if (weather === "dusk") {
    rect(target, "rgba(255,84,46,.24)", 0, 0, 64, 17);
    rect(target, "rgba(9,8,7,.18)", 0, 17, 64, 6);
  } else if (weather === "pollen") {
    [[5, 9], [14, 25], [52, 14], [58, 39], [8, 49], [45, 33]].forEach(([x, y], index) => {
      rect(target, colors.honey, (x + f + index * 2) % 64, y, 1 + (index % 2), 1 + (index % 2));
    });
  } else if (weather === "snow") {
    for (let index = 0; index < 11; index += 1) {
      rect(target, colors.bone, (index * 19 + f) % 64, (index * 11 + f * 2) % 58, index % 3 === 0 ? 2 : 1, 2);
    }
  } else if (weather === "smog") {
    rect(target, "rgba(23,19,16,.45)", 0, 10, 64, 7);
    rect(target, "rgba(243,230,203,.24)", 0, 17, 47, 4);
    rect(target, "rgba(23,19,16,.36)", 18, 22, 46, 6);
  } else if (weather === "redsun") {
    rect(target, colors.ink, 46, 6, 12, 12);
    rect(target, colors.orange, 48, 8, 8, 8);
    rect(target, colors.honey, 50, 10, 4, 4);
  } else if (weather === "ticker") {
    for (let x = 3; x < 61; x += 7) {
      const up = ((x + f) / 7) % 2 < 1;
      const color = up ? colors.mint : colors.orange;
      rect(target, color, x, 5 + (x % 11), 1, 9);
      rect(target, color, x - 1, up ? 7 + (x % 11) : 11 + (x % 11), 3, 4);
    }
  } else if (weather === "blackout") {
    rect(target, "rgba(9,8,7,.62)", 0, 0, 64, 9);
    rect(target, colors.ink, 0, 9, 8, 55);
    rect(target, colors.ink, 56, 9, 8, 55);
    rect(target, colors.orange, 3, 3, 2, 2);
    rect(target, colors.blue, 59, 3, 2, 2);
  }
}

function drawAura(target, item, f) {
  const aura = item.traits.aura.value;
  if (aura === "flies") {
    [[8, 17], [54, 28], [11, 42], [50, 12]].forEach(([x, y], i) => rect(target, colors.ink, x + ((f + i) % 2), y, 2, 1));
  } else if (aura === "dust") {
    [[7, 18], [55, 29], [11, 45], [50, 11]].forEach(([x, y], i) => rect(target, colors.bone, x + ((f + i) % 2), y, 2, 2));
  } else if (aura === "static") {
    for (let i = 0; i < 10; i += 1) rect(target, i % 2 ? colors.orange : colors.bone, (i * 17 + f * 3) % 62, (i * 11 + f) % 50, 2, 1);
  } else if (aura === "stink") {
    [[8, 48], [52, 43], [5, 31]].forEach(([x, y], i) => {
      rect(target, colors.mint, x + ((f + i) % 3), y - 6, 2, 7);
      rect(target, colors.ink, x + 2 + ((f + i) % 3), y - 8, 2, 2);
    });
  } else if (aura === "flame") {
    const jump = f % 3;
    polygon(target, colors.blue, [[3, 58], [6, 37 + jump], [11, 43], [15, 23 - jump], [21, 42], [25, 31], [28, 60]]);
    polygon(target, colors.blue, [[36, 60], [40, 30], [45, 42], [50, 20 + jump], [54, 42], [59, 32 - jump], [62, 58]]);
  } else if (aura === "rain") {
    for (let x = 3 + (f % 4); x < 64; x += 10) {
      rect(target, colors.orange, x, 5 + (x % 4), 2, 7);
      rect(target, colors.ink, x, 5 + (x % 4), 2, 2);
    }
  } else if (aura === "moon") {
    rect(target, colors.honey, 8, 5, 48, 3);
    rect(target, colors.honey, 5, 8, 3, 43);
    rect(target, colors.honey, 56, 8, 3, 43);
    rect(target, colors.honey, 8, 51, 48, 3);
  } else if (aura === "charts") {
    const rise = f % 4;
    polygon(target, colors.mint, [[3, 35], [8, 29], [12, 32], [17, 20 - rise]]);
    polygon(target, colors.orange, [[47, 18 + rise], [52, 24], [57, 20], [62, 34]]);
  }
}

function drawNeck(target, item, breathe) {
  const { coat, shade } = item.palette;
  const neck = item.traits.neck.value;
  const outfit = item.traits.outfit.value;
  const bodyX = Math.round(item.traits.pose.x / 2);
  const shoulder = item.traits.pose.shoulder;
  const y = 47 + breathe;
  rect(target, colors.ink, 5 + bodyX, y - 1, 54, 18);
  if (outfit === "track") {
    rect(target, colors.blue, 7 + bodyX, y + shoulder / 2, 50, 17);
    polygon(target, colors.orange, [[7 + bodyX, y + 1], [19 + bodyX, y - 3 + shoulder], [25 + bodyX, 64], [8 + bodyX, 64]]);
    polygon(target, colors.orange, [[57 + bodyX, y + 1], [45 + bodyX, y - 3 - shoulder], [39 + bodyX, 64], [56 + bodyX, 64]]);
    rect(target, colors.bone, 30 + bodyX, y + 1, 4, 16);
  } else if (outfit === "puffer") {
    rect(target, colors.mud, 6 + bodyX, y, 52, 17);
    [y + 4, y + 9, y + 14].forEach((line) => rect(target, colors.ink, 7 + bodyX, line, 50, 2));
    rect(target, colors.honey, 30 + bodyX, y, 4, 17);
  } else if (outfit === "poncho") {
    polygon(target, colors.ink, [[32 + bodyX, y - 4], [62 + bodyX, 64], [2 + bodyX, 64]]);
    polygon(target, colors.grass, [[32 + bodyX, y - 1], [58 + bodyX, 64], [6 + bodyX, 64]]);
    polygon(target, colors.mint, [[32 + bodyX, y + 2], [42 + bodyX, 64], [36 + bodyX, 64]]);
    polygon(target, colors.mint, [[22 + bodyX, 64], [29 + bodyX, y + 3], [15 + bodyX, 64]]);
  } else if (outfit === "overalls") {
    rect(target, coat, 8 + bodyX, y, 48, 17);
    rect(target, colors.blue, 18 + bodyX, y + 3, 28, 14);
    rect(target, colors.blue, 15 + bodyX, y - 2, 5, 12);
    rect(target, colors.blue, 44 + bodyX, y - 2, 5, 12);
    rect(target, colors.honey, 17 + bodyX, y + 1, 3, 3);
    rect(target, colors.honey, 44 + bodyX, y + 1, 3, 3);
  } else if (outfit === "suit") {
    rect(target, colors.soot, 7 + bodyX, y, 50, 17);
    polygon(target, colors.bone, [[23 + bodyX, y], [32 + bodyX, y + 10], [41 + bodyX, y], [39 + bodyX, 64], [25 + bodyX, 64]]);
    polygon(target, colors.orange, [[32 + bodyX, y + 5], [36 + bodyX, y + 10], [33 + bodyX, 64], [29 + bodyX, y + 10]]);
  } else if (outfit === "varsity") {
    rect(target, colors.orange, 6 + bodyX, y, 52, 17);
    rect(target, colors.blue, 15 + bodyX, y, 34, 17);
    rect(target, colors.bone, 30 + bodyX, y, 4, 17);
    rect(target, colors.bone, 8 + bodyX, y + 4, 6, 2);
    rect(target, colors.bone, 50 + bodyX, y + 4, 6, 2);
  } else if (outfit === "bonebib") {
    rect(target, shade, 8 + bodyX, y, 48, 17);
    rect(target, colors.bone, 20 + bodyX, y - 1, 24, 17);
    rect(target, colors.ink, 30 + bodyX, y, 4, 17);
    [y + 3, y + 8, y + 13].forEach((line) => {
      rect(target, colors.ink, 22 + bodyX, line, 8, 2);
      rect(target, colors.ink, 34 + bodyX, line, 8, 2);
    });
  } else if (outfit === "space") {
    rect(target, "#61777c", 6 + bodyX, y + 3, 52, 14);
    rect(target, colors.bone, 10 + bodyX, y - 3, 44, 8);
    rect(target, colors.ink, 13 + bodyX, y - 1, 38, 5);
    rect(target, colors.mint, 11 + bodyX, y + 8, 4, 4);
    rect(target, colors.orange, 49 + bodyX, y + 8, 4, 4);
  } else if (outfit === "cult") {
    polygon(target, colors.ink, [[8 + bodyX, 64], [15 + bodyX, y - 3], [32 + bodyX, y + 6], [49 + bodyX, y - 3], [56 + bodyX, 64]]);
    polygon(target, colors.blue, [[12 + bodyX, 64], [18 + bodyX, y], [32 + bodyX, y + 10], [46 + bodyX, y], [52 + bodyX, 64]]);
    rect(target, colors.orange, 30 + bodyX, y + 8, 4, 7);
  } else if (outfit === "wings") {
    polygon(target, colors.ink, [[31, 64], [4 + bodyX, 62], [1 + bodyX, 49], [13 + bodyX, 53], [9 + bodyX, 42], [25 + bodyX, y + 5]]);
    polygon(target, colors.blue, [[29, 64], [7 + bodyX, 60], [5 + bodyX, 51], [16 + bodyX, 55], [13 + bodyX, 47], [27 + bodyX, y + 7]]);
    polygon(target, colors.ink, [[33, 64], [60 + bodyX, 62], [63 + bodyX, 49], [51 + bodyX, 53], [55 + bodyX, 42], [39 + bodyX, y + 5]]);
    polygon(target, colors.orange, [[35, 64], [57 + bodyX, 60], [59 + bodyX, 51], [48 + bodyX, 55], [51 + bodyX, 47], [37 + bodyX, y + 7]]);
  } else if (outfit === "hazard") {
    rect(target, colors.honey, 6 + bodyX, y, 52, 17);
    polygon(target, colors.ink, [[7 + bodyX, y + 4], [14 + bodyX, y], [21 + bodyX, y], [11 + bodyX, y + 10]]);
    polygon(target, colors.ink, [[24 + bodyX, 64], [39 + bodyX, y], [47 + bodyX, y], [32 + bodyX, 64]]);
    polygon(target, colors.ink, [[46 + bodyX, 64], [57 + bodyX, y + 5], [57 + bodyX, y + 14], [53 + bodyX, 64]]);
  } else {
    rect(target, shade, 8 + bodyX, y, 48, 17);
    rect(target, coat, 16 + bodyX, y - 1, 32, 18);
  }
  if (neck === "hoodie") {
    rect(target, "#253b35", 11 + bodyX, y - 2, 8, 13);
    rect(target, "#253b35", 45 + bodyX, y - 2, 8, 13);
  } else if (neck === "cape") {
    polygon(target, colors.orange, [[9 + bodyX, y + 1], [20 + bodyX, y - 4], [32 + bodyX, y + 9], [44 + bodyX, y - 4], [55 + bodyX, y + 1], [52 + bodyX, 64], [12 + bodyX, 64]]);
  }
  const stance = item.traits.pose.value;
  if (stance === "left") {
    rect(target, colors.bone, 13, y + 2, 9, 2);
  } else if (stance === "right") {
    rect(target, colors.bone, 42, y + 2, 9, 2);
  } else if (stance === "high") {
    rect(target, colors.ink, 23, y - 2, 18, 3);
  } else if (stance === "low") {
    rect(target, colors.ink, 23, y + 8, 18, 2);
  } else if (stance === "check") {
    rect(target, colors.ink, 9, y + 4, 7, 8);
    rect(target, colors.ink, 48, y + 4, 7, 8);
  } else if (stance === "crooked") {
    polygon(target, colors.honey, [[18, y], [32, y + 7], [46, y], [32, y + 4]]);
  } else if (stance === "close") {
    rect(target, colors.orange, 19, y - 1, 26, 3);
  }
  if (item.traits.bearKind.value === "sun") {
    polygon(target, colors.honey, [[24, 50], [32, 57], [40, 50], [37, 62], [27, 62]]);
  }
  if (["chain", "wallet", "seed", "medal", "bell"].includes(neck)) {
    const chainColor = neck === "seed" ? colors.bone : colors.honey;
    rect(target, chainColor, 19, 53, 4, 2);
    rect(target, chainColor, 41, 53, 4, 2);
    rect(target, chainColor, 22, 55, 4, 2);
    rect(target, chainColor, 38, 55, 4, 2);
    rect(target, colors.ink, 27, 55, 10, 9);
    rect(target, neck === "wallet" ? colors.mint : neck === "medal" ? colors.orange : chainColor, 29, 57, 6, 5);
    if (neck === "bell") rect(target, colors.ink, 31, 61, 2, 2);
  }
  if (neck === "earring") {
    rect(target, colors.ink, 51, 31, 4, 12);
    rect(target, colors.mint, 52, 33, 2, 8);
    rect(target, colors.orange, 51, 31, 4, 3);
  }
}

function drawEars(target, item, headX, headY, headW) {
  const ratio = item.balance / 100;
  const bear = item.traits.bearKind;
  const bull = item.traits.bullKind;
  const form = item.traits.form.value;
  const earSize = form === "skull" ? 5 : form === "robot" ? 6 : bear.ear === "fluffy" ? 11 : bear.ear === "small" ? 6 : 8;
  const earColor = form === "robot" ? item.palette.shade : bear.value === "panda" ? colors.ink : item.palette.coat;
  const inner = form === "robot" ? colors.mint : bear.value === "koala" ? colors.bone : item.palette.mark;
  const left = headX - earSize + 4;
  const right = headX + headW - 4;
  if (form !== "zombie") {
    rect(target, colors.ink, left - 1, headY + 5, earSize + 2, earSize + 2);
    rect(target, earColor, left, headY + 6, earSize, earSize);
    rect(target, inner, left + 2, headY + 8, Math.max(2, earSize - 4), Math.max(2, earSize - 4));
  } else {
    rect(target, colors.ink, left + 2, headY + 10, 3, 5);
    rect(target, colors.orange, left + 3, headY + 11, 2, 3);
  }
  rect(target, colors.ink, right - 1, headY + 5, earSize + 2, earSize + 2);
  rect(target, earColor, right, headY + 6, earSize, earSize);
  rect(target, inner, right + 2, headY + 8, Math.max(2, earSize - 4), Math.max(2, earSize - 4));
  if (bear.ear === "fluffy") {
    rect(target, earColor, left - 2, headY + 9, 3, 3);
    rect(target, earColor, right + earSize - 1, headY + 9, 3, 3);
  }
  if (ratio > 0.38 && bull.ears === "droop") {
    polygon(target, colors.ink, [[headX + 1, headY + 13], [headX - 10, headY + 17], [headX - 5, headY + 24], [headX + 4, headY + 18]]);
    polygon(target, item.palette.coat, [[headX, headY + 14], [headX - 8, headY + 18], [headX - 4, headY + 22], [headX + 3, headY + 17]]);
    polygon(target, colors.ink, [[headX + headW - 1, headY + 13], [headX + headW + 10, headY + 17], [headX + headW + 5, headY + 24], [headX + headW - 4, headY + 18]]);
    polygon(target, item.palette.coat, [[headX + headW, headY + 14], [headX + headW + 8, headY + 18], [headX + headW + 4, headY + 22], [headX + headW - 3, headY + 17]]);
  }
}

function drawHornPair(target, item, headX, headY, headW, lift = 0) {
  if (item.traits.horns.value === "none") return;
  const ratio = item.balance / 100;
  const breed = item.traits.bullKind;
  const wide = breed.value === "longhorn";
  const tall = breed.value === "watusi";
  let size = Math.round((4 + ratio * 6) * breed.hornScale);
  if (item.traits.horns.value === "sawed") size = Math.min(4, size);
  const hornColor = item.traits.form.value === "robot" ? "#9fb2b3" : item.traits.horns.value === "diamond" ? "#a8e8e4" : colors.bone;
  const left = headX + 6;
  const right = headX + headW - 6;
  const rise = tall ? size + 3 : Math.max(3, size - (wide ? 3 : 0));
  const reach = wide ? size + 5 : size;
  polygon(target, colors.ink, [[left + 2, headY + 4 + lift], [left - reach - 2, headY + 2 - rise + lift], [left - reach, headY + 7 + lift], [left, headY + 8 + lift]]);
  polygon(target, hornColor, [[left + 1, headY + 3 + lift], [left - reach, headY + 3 - rise + lift], [left - reach + 1, headY + 5 + lift], [left, headY + 6 + lift]]);
  polygon(target, colors.ink, [[right - 2, headY + 4 + lift], [right + reach + 2, headY + 2 - rise + lift], [right + reach, headY + 7 + lift], [right, headY + 8 + lift]]);
  polygon(target, hornColor, [[right - 1, headY + 3 + lift], [right + reach, headY + 3 - rise + lift], [right + reach - 1, headY + 5 + lift], [right, headY + 6 + lift]]);
  rect(target, colors.orange, left - 1, headY + 3 + lift, 3, 4);
  rect(target, colors.orange, right - 2, headY + 3 + lift, 3, 4);
  const ornament = item.traits.horns.value;
  const tipColor = ornament === "goldtips" ? colors.honey : ornament === "antenna" ? colors.orange : ornament === "flowers" ? colors.mint : null;
  if (tipColor) {
    rect(target, tipColor, left - reach - 2, headY + 1 - rise + lift, 3, 3);
    rect(target, tipColor, right + reach - 1, headY + 1 - rise + lift, 3, 3);
  }
  if (ornament === "candles") {
    rect(target, colors.orange, left - reach - 1, headY - rise - 3 + lift, 2, 4);
    rect(target, colors.honey, left - reach - 1, headY - rise - 5 + lift, 2, 2);
    rect(target, colors.orange, right + reach - 1, headY - rise - 3 + lift, 2, 4);
    rect(target, colors.honey, right + reach - 1, headY - rise - 5 + lift, 2, 2);
  }
}

function drawHorns(target, item, headX, headY, headW) {
  drawHornPair(target, item, headX, headY, headW, 0);
  if (item.traits.horns.value === "double") drawHornPair(target, item, headX + 2, headY + 2, headW - 4, -5);
}

function drawSpeciesMarks(target, item, headX, headY, headW) {
  if (["robot", "skull", "hollow"].includes(item.traits.form.value)) return;
  const kind = item.traits.bearKind.value;
  const center = headX + Math.floor(headW / 2);
  if (kind === "panda") {
    polygon(target, item.palette.mark, [[headX + 7, headY + 12], [headX + 15, headY + 10], [headX + 18, headY + 20], [headX + 10, headY + 23]]);
    polygon(target, item.palette.mark, [[headX + headW - 7, headY + 12], [headX + headW - 15, headY + 10], [headX + headW - 18, headY + 20], [headX + headW - 10, headY + 23]]);
  } else if (kind === "koala") {
    rect(target, item.palette.mark, center - 5, headY + 12, 10, 13);
    rect(target, colors.ink, center - 3, headY + 13, 6, 12);
  } else if (kind === "sun") {
    polygon(target, item.palette.mark, [[center - 8, headY + 22], [center, headY + 18], [center + 8, headY + 22], [center + 5, headY + 31], [center - 5, headY + 31]]);
  } else if (kind === "spectacled") {
    rect(target, item.palette.mark, headX + 7, headY + 11, 10, 9);
    rect(target, item.palette.mark, headX + headW - 17, headY + 11, 10, 9);
    rect(target, item.palette.mark, headX + 13, headY + 9, headW - 26, 3);
  } else if (kind === "sloth") {
    polygon(target, item.palette.mark, [[center - 5, headY + 8], [center + 5, headY + 8], [center + 8, headY + 27], [center, headY + 33], [center - 8, headY + 27]]);
  } else if (kind === "grizzly") {
    rect(target, item.palette.mark, headX + 5, headY + 8, headW - 10, 3);
  } else if (kind === "polar") {
    rect(target, item.palette.mark, center - 3, headY + 8, 6, 4);
  }
  if (item.traits.coat.value === "mud") {
    rect(target, item.traits.coat.overlay, headX + 2, headY + 24, 7, 5);
    rect(target, item.traits.coat.overlay, headX + headW - 11, headY + 12, 6, 4);
    rect(target, item.traits.coat.overlay, center + 3, headY + 4, 5, 3);
  }
}

function drawCollectionMarking(target, item, headX, headY, headW, headH) {
  const marking = item.traits.marking.value;
  const center = headX + Math.floor(headW / 2);
  if (marking === "clean" || item.traits.form.value === "hollow") return;
  if (marking === "split") {
    rect(target, item.palette.shade, center, headY + 5, Math.floor(headW / 2), headH - 9);
    rect(target, item.palette.mark, center, headY + 9, 2, headH - 16);
  } else if (marking === "blaze") {
    polygon(target, item.palette.mark, [[center - 3, headY + 2], [center + 4, headY + 2], [center + 2, headY + 17], [center + 5, headY + 27], [center - 4, headY + 27], [center - 1, headY + 15]]);
  } else if (marking === "bars") {
    rect(target, item.palette.shade, headX + 5, headY + 14, 13, 4);
    rect(target, item.palette.shade, headX + headW - 18, headY + 14, 13, 4);
    rect(target, colors.orange, headX + 7, headY + 19, 8, 2);
    rect(target, colors.orange, headX + headW - 15, headY + 19, 8, 2);
  } else if (marking === "freckles") {
    [[-11, 23], [-6, 26], [7, 24], [12, 27], [-14, 29], [14, 21]].forEach(([dx, dy]) => rect(target, colors.mud, center + dx, headY + dy, 2, 2));
  } else if (marking === "checker") {
    [[5, 20], [9, 24], [13, 20], [headW - 15, 22], [headW - 11, 26], [headW - 7, 22]].forEach(([dx, dy], index) => {
      rect(target, index % 2 ? colors.bone : item.palette.shade, headX + dx, headY + dy, 4, 4);
    });
  } else if (marking === "scar") {
    polygon(target, colors.ink, [[headX + 8, headY + 4], [headX + 15, headY + 13], [headX + 12, headY + 18], [headX + 21, headY + 29]]);
    rect(target, colors.orange, headX + 12, headY + 12, 4, 2);
    rect(target, colors.orange, headX + 15, headY + 21, 4, 2);
  } else if (marking === "halfmud") {
    polygon(target, colors.mud, [[headX, headY + 7], [center - 2, headY + 5], [center + 3, headY + 14], [center - 1, headY + 22], [center + 2, headY + headH - 4], [headX, headY + headH - 4]]);
  } else if (marking === "eclipse") {
    rect(target, colors.ink, headX + 3, headY + 11, headW - 6, 13);
    rect(target, item.palette.mark, center - 2, headY + 13, 4, 9);
  } else if (marking === "barcode") {
    for (let x = headX + 5; x < headX + headW - 4; x += 4) {
      rect(target, x % 3 ? colors.ink : item.palette.mark, x, headY + 5, x % 8 ? 1 : 2, 10 + (x % 6));
    }
  } else if (marking === "warpaint") {
    polygon(target, colors.blue, [[headX + 2, headY + 12], [center - 2, headY + 17], [headX + 3, headY + 23]]);
    polygon(target, colors.orange, [[headX + headW - 2, headY + 10], [center + 2, headY + 17], [headX + headW - 3, headY + 26]]);
  } else if (marking === "mosaic") {
    [[4, 5], [11, 10], [19, 4], [27, 12], [headW - 9, 6], [headW - 17, 25], [7, 29], [headW - 8, 31]].forEach(([dx, dy], index) => {
      const palette = [colors.orange, colors.blue, colors.mint, colors.bone];
      rect(target, palette[index % palette.length], headX + dx, headY + dy, 3 + (index % 2), 3);
    });
  }
}

function drawHeadBase(target, item, headX, headY, headW, headH) {
  const jaw = item.traits.silhouette.jaw;
  if (jaw === "wedge") {
    polygon(target, colors.ink, [[headX + 2, headY], [headX + headW - 2, headY], [headX + headW + 1, headY + 15], [headX + headW - 5, headY + headH + 1], [headX + 5, headY + headH + 1], [headX - 1, headY + 15]]);
    polygon(target, item.palette.coat, [[headX + 4, headY + 3], [headX + headW - 4, headY + 3], [headX + headW - 1, headY + 15], [headX + headW - 7, headY + headH - 2], [headX + 7, headY + headH - 2], [headX + 1, headY + 15]]);
  } else if (jaw === "totem") {
    rect(target, colors.ink, headX - 2, headY + 4, headW + 4, headH - 3);
    rect(target, colors.ink, headX + 1, headY, headW - 2, headH + 2);
    rect(target, item.palette.coat, headX, headY + 5, headW, headH - 8);
    rect(target, item.palette.coat, headX + 3, headY + 2, headW - 6, headH - 2);
    rect(target, item.palette.shade, headX + Math.floor(headW / 2) - 2, headY + 3, 4, 11);
  } else {
    rect(target, colors.ink, headX - 2, headY + 4, headW + 4, headH - 3);
    rect(target, colors.ink, headX + 1, headY, headW - 2, headH + 2);
    rect(target, item.palette.coat, headX, headY + 5, headW, headH - 8);
    rect(target, item.palette.coat, headX + 3, headY + 2, headW - 6, headH - 2);
  }
  if (jaw === "soft") {
    rect(target, item.palette.coat, headX - 1, headY + 14, 3, 11);
    rect(target, item.palette.coat, headX + headW - 2, headY + 14, 3, 11);
  } else if (jaw === "cheeks") {
    rect(target, colors.ink, headX - 3, headY + 19, 6, 11);
    rect(target, item.palette.coat, headX - 1, headY + 20, 4, 8);
    rect(target, colors.ink, headX + headW - 3, headY + 19, 6, 11);
    rect(target, item.palette.coat, headX + headW - 3, headY + 20, 4, 8);
  } else if (jaw === "hammer") {
    rect(target, colors.ink, headX - 2, headY + 9, headW + 4, 8);
    rect(target, item.palette.coat, headX, headY + 11, headW, 4);
  } else if (jaw === "low") {
    rect(target, item.palette.shade, headX + 2, headY + 5, headW - 4, 6);
  } else if (jaw === "tiny") {
    rect(target, colors.ink, headX - 2, headY + headH - 6, headW + 4, 7);
    rect(target, item.palette.coat, headX, headY + headH - 5, headW, 4);
  } else if (jaw === "long") {
    rect(target, item.palette.shade, headX + 2, headY + headH - 7, headW - 4, 6);
  }
  rect(target, item.palette.shade, headX + 3, headY + headH - 5, headW - 6, 4);
}

function drawMarketTicks(target, item, headX, headY, headW) {
  const y = headY + 24;
  const rareDark = ["hollow", "possessed"].includes(item.traits.form.value);
  rect(target, rareDark ? colors.honey : colors.orange, headX + 4, y, 2, 5);
  rect(target, rareDark ? colors.mint : colors.blue, headX + headW - 6, y, 2, 5);
}

function drawFormDetails(target, item, headX, headY, headW, f) {
  const form = item.traits.form.value;
  const center = headX + Math.floor(headW / 2);
  if (form === "degen") {
    rect(target, colors.orange, headX + 4, headY + 25, 3, 7);
    rect(target, colors.honey, headX + 7, headY + 25, 2, 2);
  } else if (form === "robot") {
    rect(target, item.palette.shade, center - 1, headY + 2, 2, 31);
    rect(target, colors.ink, headX + 4, headY + 9, 4, 4);
    rect(target, colors.mint, headX + 5, headY + 10, 2, 2);
    rect(target, colors.ink, headX + headW - 8, headY + 9, 4, 4);
    rect(target, colors.orange, headX + headW - 7, headY + 10, 2, 2);
    rect(target, colors.ink, center - 2, headY - 4, 4, 6);
    rect(target, colors.blue, center - 1, headY - 8 - (f % 2), 2, 5);
    rect(target, colors.orange, center - 2, headY - 10 - (f % 2), 4, 3);
  } else if (form === "zombie") {
    rect(target, colors.mud, headX + 3, headY + 8, 5, 4);
    rect(target, colors.ink, headX + headW - 6, headY + 2, 6, 5);
    rect(target, colors.orange, headX + headW - 5, headY + 4, 3, 2);
    polygon(target, colors.ink, [[center - 2, headY + 2], [center + 1, headY + 8], [center - 1, headY + 12], [center + 3, headY + 17]]);
  } else if (form === "skull") {
    rect(target, colors.ink, headX + 2, headY + 28, 5, 5);
    rect(target, colors.ink, headX + headW - 7, headY + 28, 5, 5);
    polygon(target, item.palette.shade, [[center, headY + 2], [center - 2, headY + 8], [center + 2, headY + 13], [center - 1, headY + 18]]);
  } else if (form === "mad") {
    polygon(target, colors.orange, [[center - 1, headY + 1], [center + 2, headY + 7], [center, headY + 11], [center + 4, headY + 16]]);
    rect(target, colors.ink, headX + 4, headY + 10, 10, 2);
    rect(target, colors.ink, headX + headW - 14, headY + 14, 10, 2);
  } else if (form === "hollow") {
    rect(target, colors.ink, headX + 5, headY + 7, headW - 10, 27);
    rect(target, item.palette.mark, center - 10, headY + 18, 3, 3);
    rect(target, item.palette.mark, center + 7, headY + 18, 3, 3);
  } else if (form === "possessed") {
    rect(target, colors.blue, headX + 4, headY + 11, 3, 13);
    rect(target, colors.blue, headX + headW - 7, headY + 11, 3, 13);
    rect(target, colors.ink, center - 5, headY + 5, 10, 7);
    rect(target, colors.orange, center - 3, headY + 6, 6, 5);
    rect(target, colors.ink, center - 1, headY + 7, 2, 3);
  }
}

function drawEyes(target, item, headX, headY, headW, blink) {
  const kind = item.traits.eyes.value;
  const form = item.traits.form.value;
  const layout = item.traits.faceLayout;
  const spread = layout.spread / 2;
  const left = Math.round(headX + 10 - spread);
  const right = Math.round(headX + headW - 15 + spread);
  const leftY = headY + 17 + layout.y;
  const rightY = leftY + layout.skew;
  if (form === "robot") {
    rect(target, colors.ink, left - 2, leftY - 3, 12, 10);
    rect(target, colors.ink, right - 2, rightY - 3, 12, 10);
    rect(target, colors.mint, left + 1, leftY, 5, 3);
    rect(target, colors.orange, right + 1, rightY - 1, 5, 5);
    return;
  }
  if (form === "zombie") {
    rect(target, colors.ink, left, leftY, 7, 7);
    rect(target, colors.ink, right, rightY, 7, 7);
    rect(target, colors.orange, left + 2, leftY + 2, 3, 3);
    rect(target, item.palette.mark, right + 1, rightY + 1, 2, 2);
    rect(target, item.palette.mark, right + 4, rightY + 4, 2, 2);
    return;
  }
  if (form === "skull") {
    rect(target, colors.ink, left - 2, leftY - 3, 12, 12);
    rect(target, colors.ink, right - 2, rightY - 3, 12, 12);
    return;
  }
  if (form === "mad") {
    rect(target, colors.ink, left - 1, leftY - 4, 9, 10);
    rect(target, colors.ink, right, rightY, 8, 7);
    rect(target, colors.orange, left + 2, leftY - 1, 3, 4);
    rect(target, colors.honey, right + 2, rightY + 2, 3, 2);
    return;
  }
  if (form === "hollow") return;
  if (kind === "shades") {
    rect(target, colors.ink, left - 3, leftY - 2, 14, 8);
    rect(target, colors.ink, right - 2, rightY - 2, 14, 8);
    rect(target, colors.ink, left + 9, Math.min(leftY, rightY), right - left - 7, 2);
    rect(target, colors.blue, left - 1, leftY, 9, 3);
    rect(target, colors.blue, right, rightY, 9, 3);
    return;
  }
  const closed = blink || kind === "drowsy";
  if (closed) {
    rect(target, colors.ink, left, leftY + 2, 7, 2);
    rect(target, colors.ink, right, rightY + 2, 7, 2);
  } else {
    rect(target, colors.ink, left, leftY, 7, 6);
    rect(target, colors.ink, right, rightY, 7, 6);
    const pupil = kind === "green" ? colors.mint : kind === "red" ? colors.orange : colors.bone;
    const side = kind === "side" ? 1 : 3;
    rect(target, pupil, left + side, leftY + 1, 2, 3);
    rect(target, pupil, right + side, rightY + 1, 2, 3);
  }
  if (kind === "laser") {
    rect(target, colors.orange, left - 5, leftY + 2, 12, 2);
    rect(target, colors.orange, right, rightY + 2, 12, 2);
  }
  if (kind === "third") {
    rect(target, colors.ink, headX + Math.floor(headW / 2) - 5, headY + 6, 10, 7);
    rect(target, colors.orange, headX + Math.floor(headW / 2) - 3, headY + 7, 6, 5);
    rect(target, colors.ink, headX + Math.floor(headW / 2) - 1, headY + 8, 2, 3);
  }
  if (kind === "void") {
    rect(target, colors.ink, left - 1, leftY - 1, 9, 8);
    rect(target, colors.ink, right - 1, rightY - 1, 9, 8);
  }
}

function drawHeadwear(target, item, headX, headY, headW, f) {
  const type = item.traits.headwear.value;
  const center = headX + Math.floor(headW / 2);
  if (type === "papercrown") {
    // Folded takeaway-bag crown, not the gold crown's three prongs.
    polygon(target,colors.ink,[[center-10,headY+1],[center-12,headY-8],[center-5,headY-4],[center,headY-10],[center+6,headY-3],[center+10,headY-6],[center+9,headY+1]]);
    polygon(target,'#c99d68',[[center-8,headY],[center-10,headY-5],[center-4,headY-2],[center,headY-7],[center+5,headY-1],[center+8,headY-3],[center+7,headY]]);
    rect(target,colors.bone,center-4,headY-1,7,2);rect(target,colors.ink,center-1,headY-1,1,2);
  } else if (type === "cap") {
    rect(target, colors.ink, center - 12, headY - 5, 22, 7);
    rect(target, colors.mint, center - 10, headY - 6, 17, 6);
    rect(target, colors.bone, center - 2, headY - 5, 7, 4);
    rect(target, colors.mint, center + 6, headY, 9, 2);
  } else if (type === "beanie") {
    rect(target, colors.ink, center - 12, headY - 6, 24, 8);
    rect(target, colors.orange, center - 10, headY - 6, 20, 6);
    rect(target, colors.honey, center - 2, headY - 10, 4, 4);
  } else if (type === "visor") {
    rect(target, colors.ink, headX + 4, headY + 14, headW - 8, 9);
    rect(target, colors.blue, headX + 6, headY + 16, headW - 12, 4);
    rect(target, colors.bone, headX + 7 + (f % Math.max(1, headW - 17)), headY + 16, 2, 4);
  } else if (type === "grass") {
    for (let x = center - 7; x <= center + 7; x += 4) rect(target, colors.mint, x, headY - 7 - (x % 3), 2, 9);
  } else if (type === "bucket") {
    rect(target, colors.ink, center - 12, headY - 8, 24, 10);
    rect(target, colors.mud, center - 10, headY - 7, 20, 8);
    rect(target, colors.bone, center - 13, headY, 26, 3);
  } else if (type === "foil") {
    polygon(target, colors.ink, [[center - 9, headY + 1], [center, headY - 12], [center + 9, headY + 1]]);
    polygon(target, "#a8c8ca", [[center - 6, headY], [center, headY - 9], [center + 6, headY]]);
  } else if (type === "crown") {
    polygon(target, colors.ink, [[center - 12, headY + 2], [center - 12, headY - 8], [center - 5, headY - 3], [center, headY - 11], [center + 6, headY - 3], [center + 12, headY - 8], [center + 12, headY + 2]]);
    polygon(target, colors.honey, [[center - 10, headY], [center - 10, headY - 5], [center - 4, headY - 1], [center, headY - 8], [center + 5, headY - 1], [center + 10, headY - 5], [center + 10, headY]]);
  } else if (type === "halo") {
    rect(target, colors.honey, center - 14, headY - 9, 28, 3);
    rect(target, colors.orange, center - 8, headY - 11, 16, 2);
  } else if (type === "tiny") {
    rect(target, colors.ink, center - 5, headY - 9, 10, 10);
    rect(target, colors.orange, center - 3, headY - 7, 6, 6);
    rect(target, colors.ink, center - 2, headY - 5, 4, 2);
  }
}

function drawForelock(target, item, headX, headY, headW) {
  if (!item.traits.bullKind.forelock) return;
  const center = headX + Math.floor(headW / 2);
  const shag = item.traits.bullKind.value === "highland";
  polygon(target, item.palette.shade, [[center - 12, headY + 1], [center - 8, headY + (shag ? 12 : 6)], [center - 3, headY + 5], [center, headY + (shag ? 14 : 7)], [center + 5, headY + 5], [center + 10, headY + (shag ? 11 : 6)], [center + 12, headY + 1]]);
}

function drawMuzzle(target, item, headX, headY, headW, active) {
  const ratio = item.balance / 100;
  const kind = item.traits.bearKind.value;
  const form = item.traits.form.value;
  const muzzle = item.traits.muzzle;
  const center = Math.round(headX + headW / 2);
  const muzzleW = clamp(Math.round(23 + ratio * 5 + muzzle.width), 22, 34);
  const muzzleH = clamp(Math.round(13 + ratio * 4 + muzzle.height), 12, 19);
  const x = Math.round(center - muzzleW / 2);
  const y = clamp(headY + 24 + muzzle.y, headY + 19, 49);
  const muzzleColor = form === "hollow" ? colors.ink : form === "robot" ? "#aab7b5" : colors.bone;
  rect(target, colors.ink, x - 2, y - 1, muzzleW + 4, muzzleH + 3);
  rect(target, muzzleColor, x, y, muzzleW, muzzleH);
  if (muzzle.value === "droop") {
    rect(target, item.palette.shade, x + 1, y + muzzleH - 5, 5, 5);
    rect(target, item.palette.shade, x + muzzleW - 6, y + muzzleH - 5, 5, 5);
  } else if (muzzle.value === "split") {
    rect(target, item.palette.shade, center - 1, y + 1, 2, muzzleH - 2);
  } else if (muzzle.value === "hammer") {
    rect(target, colors.ink, x - 3, y + 3, 5, 7);
    rect(target, colors.ink, x + muzzleW - 2, y + 3, 5, 7);
  } else if (muzzle.value === "long") {
    rect(target, muzzleColor, center - 5, y - 5, 10, 7);
  }
  const noseW = muzzle.value === "button" || kind === "koala" ? 10 : muzzle.value === "hammer" ? 18 : clamp(Math.round(11 + ratio * 4), 10, muzzleW - 5);
  const noseH = muzzle.value === "button" || kind === "koala" ? 10 : 7;
  const noseX = center - Math.floor(noseW / 2);
  rect(target, colors.ink, noseX, y + 1, noseW, noseH);
  rect(target, item.palette.shade, center - 2, y + 2, 4, 2);
  const mouth = item.traits.mouth.value;
  const open = active || mouth === "portal" ? 6 : 2;
  const mouthY = y + clamp(muzzleH - 6, 8, 14);
  rect(target, colors.ink, center - 2, mouthY, 4, open);
  if (mouth === "tongue") rect(target, colors.orange, center - 2, mouthY + 3, 5, 4);
  if (mouth === "tooth") rect(target, colors.honey, center + 1, mouthY + 1, 3, 3);
  if (mouth === "gum") {
    rect(target, "#e76fab", center + 4, mouthY - 1, 7, 7);
    rect(target, colors.bone, center + 6, mouthY, 2, 2);
  }
  if (mouth === "grass") {
    rect(target, colors.mint, center + 2, mouthY + 1, 11, 2);
    rect(target, colors.mint, center + 9, mouthY - 2, 2, 5);
  }
  if (mouth === "cigar") {
    rect(target, colors.mud, center + 3, mouthY + 1, 11, 3);
    rect(target, colors.orange, center + 12, mouthY, 2, 4);
  }
  if (mouth === "drool") rect(target, colors.blue, center + 1, mouthY + 3, 3, 7);
  if (mouth === "portal") rect(target, colors.orange, center - 1, mouthY + 1, 3, 5);
  if (form === "robot") {
    rect(target, item.palette.shade, x + 3, mouthY + 1, muzzleW - 6, 2);
    for (let gx = x + 5; gx < x + muzzleW - 3; gx += 4) rect(target, colors.ink, gx, mouthY + 1, 1, 2);
  } else if (form === "zombie") {
    rect(target, item.palette.mark, x + 4, mouthY, 3, 3);
    rect(target, colors.mint, x + muzzleW - 6, mouthY + 2, 3, 6);
  } else if (form === "skull") {
    rect(target, colors.ink, x + 3, mouthY, muzzleW - 6, 6);
    for (let tx = x + 5; tx < x + muzzleW - 4; tx += 4) rect(target, colors.bone, tx, mouthY + 1, 2, 4);
  } else if (form === "mad") {
    rect(target, colors.orange, x + 4, mouthY + 2, muzzleW - 8, 2);
    rect(target, colors.blue, x + 8, mouthY, 2, 4);
  } else if (form === "possessed") {
    rect(target, colors.blue, x + 5, mouthY + 1, muzzleW - 10, 2);
  }
  const ringY = y + 5;
  const ringHalf = 4;
  rect(target, colors.honey, center - ringHalf - 1, ringY, 2, 6);
  rect(target, colors.honey, center + ringHalf - 1, ringY, 2, 6);
  rect(target, colors.honey, center - ringHalf + 1, ringY + 5, ringHalf * 2 - 2, 2);
}

// V8 icon renderer: every visible edge is made from integer rectangles. The
// larger project still carries a deep trait system, but the portrait spends
// those traits with the economy of a 24–32 px sprite.
function snapEven(value) {
  return Math.round(value / 2) * 2;
}

function iconCloud(target, x, y) {
  rect(target, colors.bone, x, y + 2, 8, 2);
  rect(target, colors.bone, x + 2, y, 4, 4);
}

function iconPine(target, x, y) {
  rect(target, colors.ink, x + 4, y + 16, 4, 16);
  rect(target, "#244a36", x + 2, y + 6, 8, 18);
  rect(target, "#244a36", x, y + 12, 12, 12);
}

function colorLuminance(value) {
  const match = /^#([0-9a-f]{6})$/i.exec(value);
  if (!match) return 0;
  const channels = [0, 2, 4].map((offset) => Number.parseInt(match[1].slice(offset, offset + 2), 16) / 255);
  const linear = channels.map((channel) => channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  return linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
}

function iconSceneField(target, item, outer, edge, middle, glow) {
  // Reference-aligned lo-fi field: one uninterrupted atmosphere with a quiet
  // top plane and one ground band. Contrast changes the whole field slightly;
  // it never creates a framed spotlight behind the character.
  const darkCoat = colorLuminance(item.palette.coat) < 0.16;
  const atmosphere = darkCoat
    ? mixHex(middle, glow, 0.62)
    : mixHex(middle, glow, 0.28);
  rect(target, atmosphere, 0, 0, 64, 64);
  rect(target, mixHex(atmosphere, glow, 0.18), 0, 0, 64, 8);
  rect(target, mixHex(atmosphere, outer, 0.28), 0, 52, 64, 12);
  rect(target, mixHex(edge, atmosphere, 0.62), 0, 50, 64, 2);
}

function iconBackdropPine(target, x, baseY, height, dark, light) {
  rect(target, dark, x + 4, baseY - height + 8, 3, height - 8);
  for (let layer = 0; layer < 3; layer += 1) {
    const y = baseY - height + 4 + layer * 7;
    const spread = 4 + layer * 3;
    rect(target, dark, x + 5 - spread, y + 4, spread * 2, 5);
    rect(target, light, x + 5 - Math.max(2, spread - 2), y + 2, Math.max(4, spread * 2 - 4), 3);
  }
}

function iconBackdropMountain(target, centerX, baseY, peakY, dark, light, cap = null) {
  const layers = Math.max(2, Math.floor((baseY - peakY) / 4));
  for (let layer = 0; layer < layers; layer += 1) {
    const width = 6 + layer * 6;
    const x = centerX - Math.floor(width / 2);
    const y = peakY + layer * 4;
    rect(target, dark, x, y, width, 5);
    if (layer > 1) rect(target, light, x + 3, y, Math.max(3, Math.floor(width * 0.38)), 3);
  }
  if (cap) {
    rect(target, cap, centerX - 3, peakY, 6, 4);
    rect(target, cap, centerX - 6, peakY + 4, 6, 3);
  }
}

function iconBackdropFlame(target, x, baseY, height, flicker = 0) {
  const tipY = baseY - height - flicker;
  const sideLift = Math.max(2, Math.floor(height * 0.28));
  rect(target, colors.ink, x, tipY + 6, 10, height + flicker - 6);
  rect(target, colors.ink, x + 2, tipY + 2, 6, 8);
  rect(target, colors.ink, x + 4, tipY, 3, 4);
  rect(target, colors.ink, x - 2, tipY + sideLift + 4, 5, height - sideLift - 4);
  rect(target, colors.ink, x + 8, tipY + sideLift + 7, 4, height - sideLift - 7);
  rect(target, colors.orange, x + 2, tipY + 7, 6, height + flicker - 9);
  rect(target, colors.orange, x + 4, tipY + 3, 3, 8);
  rect(target, colors.orange, x, tipY + sideLift + 7, 3, height - sideLift - 8);
  rect(target, colors.orange, x + 8, tipY + sideLift + 10, 2, height - sideLift - 11);
  rect(target, colors.honey, x + 4, tipY + 12, 3, Math.max(5, height - 15));
  rect(target, "#fff0a8", x + 5, tipY + Math.max(16, Math.floor(height * 0.58)), 2, Math.max(3, Math.floor(height * 0.22)));
}

function habitatStep(item, f, speed, span) {
  return Math.floor((f + item.phase) / speed) % span;
}

function habitatVariant(item, salt, span) {
  const value = Math.imul(item.id + 1, 1103515245) + Math.imul(item.phase + salt, 12345);
  return Math.abs(value >>> 0) % span;
}

function currentBackdrop() {
  return habitatSystem[backgroundViewIndex] ?? habitatByValue[specimen.traits.backdrop.value];
}

function iconRain(target, item, f, color, heavy = false) {
  const travel = (f * 2 + item.phase * 3) % 64;
  const drops = heavy ? [2, 10, 18, 44, 52, 60] : [4, 14, 48, 58];
  const length = heavy ? 10 : 6;
  drops.forEach((x, index) => {
    const y = (travel + index * 15) % 64 - 10;
    rect(target, color, x, y, 2, length);
    rect(target, color, x + 2, y + length - 2, 2, 2);
  });
}

function iconLineageAccent(item) {
  const form = item.traits.form.value;
  if (form === "robot") return colors.mint;
  if (form === "zombie") return colors.orange;
  if (form === "skull") return colors.bone;
  if (["hollow", "possessed"].includes(form)) return colors.blue;
  if (form === "mad") return colors.orange;

  const bearAccents = {
    grizzly: colors.honey,
    black: colors.blue,
    panda: colors.bone,
    polar: colors.bone,
    koala: colors.mint,
    sun: colors.honey,
    spectacled: colors.orange,
    sloth: colors.blue
  };
  const bullAccents = {
    highland: colors.orange,
    angus: colors.honey,
    brahman: colors.bone,
    longhorn: colors.orange,
    zebu: colors.mint,
    fighting: colors.orange,
    watusi: colors.blue
  };
  return item.balance < 50
    ? bearAccents[item.traits.bearKind.value]
    : bullAccents[item.traits.bullKind.value];
}

function iconRarityAtmosphere(target, item, f = 0) {
  const tier = item.rarity;
  if (tier === "COMMON") return;

  const accent = mixHex(iconLineageAccent(item), colors.soot, 0.34);
  const step = habitatStep(item, f, 4, 6) * 2;
  if (tier === "UNCOMMON") {
    rect(target, accent, item.balance < 50 ? 5 : 57, 14 + step, 2, 2);
    return;
  }

  if (tier === "RARE") {
    rect(target, accent, 4, 18 + step, 2, 3);
    rect(target, accent, 58, 38 - step, 2, 3);
    return;
  }

  if (tier === "EPIC") {
    rect(target, colors.ink, 51, 6, 6, 6);
    rect(target, accent, 53, 8, 2, 2);
    return;
  }

  const pulse = habitatStep(item, f, 5, 2) * 2;
  rect(target, accent, 4, 42 - pulse, 2, 4);
  rect(target, accent, 58, 18 + pulse, 2, 4);
}

// Six colors per world: sky, air, ground, silhouette, light and one accent.
// Keep landmarks in the upper band and outer edges where the portrait leaves room.
const iconicHabitatPalettes = {
  jetrunway: ['#968da9','#d3bbab','#777b86','#353d55','#f2e6c9','#db9c53'],
  ratecut: ['#c8c6a7','#d8d6bd','#8b9b89','#455e55','#eee7cc','#c46e52'],
  chargeyard: ['#8b9dac','#c5c9bc','#6d7c74','#293d45','#e9e5ca','#df7952'],
  datacenter: ['#233a4a','#3d5960','#29434b','#152c36','#b6cfba','#a9d46a'],
  cactusgarden: ['#ebc98e','#dca574','#b4755a','#486951','#f4e7be','#db775e'],
  cloudnine: ['#5d88b4','#98b8c5','#798fa1','#3b5474','#f1e5ce','#e2af74'],
  forest: ['#b4cc91','#73a580','#315f4d','#183f38','#e9e2b5','#e6ad4e'],
  sky: ['#366cbe','#8bc7d0','#376e80','#204465','#f5e8c7','#e6b85f'],
  sunny: ['#f6ce6b','#99c5b3','#4a8a66','#285a4a','#fff0be','#f58b42'],
  grass: ['#d3d7a1','#9cb876','#588052','#315346','#f4e9bd','#dbb148'],
  mud: ['#c99070','#baaa87','#83513e','#4a3735','#efd0a0','#83b9ad'],
  rainwindow: ['#294a70','#7097a5','#293c59','#192f48','#c3d8cf','#f4a253'],
  bamboo: ['#dbe2a5','#9cbe88','#527b58','#2c5747','#f2e9b8','#cf8e4e'],
  cave: ['#514655','#a89172','#625145','#343441','#dfcca1','#7ec8c2'],
  fire: ['#552e40','#9d6858','#482d37','#2b2330','#f3cd78','#ef7746'],
  storm: ['#3e4673','#7e92b0','#39476c','#262d50','#f5e4b6','#b6c8ce'],
  desert: ['#f0b074','#da835c','#a65b48','#713f41','#f6d397','#ed6148'],
  ice: ['#83b6d7','#c1ddd7','#6fabc4','#396383','#f5efcf','#9be0df'],
  snow: ['#456b99','#b3cdd4','#e5e7d4','#294966','#f7eed0','#e99c53'],
  lab: ['#305c56','#80a993','#274b48','#173936','#d7e8ae','#b9dc6d'],
  rooftop: ['#344d84','#7b8bab','#354368','#222d50','#f0d89d','#ed825a'],
  moon: ['#514578','#9386aa','#645d8a','#37314f','#eee3bb','#c3b2d0'],
  mountain: ['#789bb5','#b9cdca','#4a657d','#304b66','#efe9d2','#dbaa62'],
  blue: ['#304d9a','#7298bb','#355983','#263d6b','#e9dfbc','#98cece'],
  horizon: ['#ead6ab','#bfd0b2','#4e8372','#31584e','#f3e7bb','#e7754b'],
  sunset: ['#b96b79','#e8a07e','#75516f','#4a3c5d','#f8d886','#d87970'],
  oasis: ['#61abb4','#b7d2b9','#d6a57d','#35645b','#eee1a9','#e58276'],
  volcano: ['#ad6668','#d49b80','#63464e','#3c3040','#f4bf69','#ef724d'],
  aurora: ['#344d72','#789caa','#456176','#293e5c','#d7e1c4','#8fc6a0'],
  cityrain: ['#354568','#708b9f','#303e60','#242b49','#a5ded0','#e79ab9']
};

function habitatPalette(scene) {
  const [sky, air, land, ink, light, accent] = iconicHabitatPalettes[scene] ?? iconicHabitatPalettes.sky;
  return {sky, air, land, ink, light, accent};
}

function habitatDisc(target, color, x, y, radius) {
  pixelEllipse(target, color, x, y, radius, radius);
}

function habitatStar(target, color, x, y, size = 2) {
  rect(target, color, x, y - size, 2, size * 2 + 2);
  rect(target, color, x - size, y, size * 2 + 2, 2);
}

function habitatCloud(target, color, x, y, width = 22) {
  rect(target, color, x + 6, y, width - 12, 2);
  rect(target, color, x + 2, y + 2, width - 4, 3);
  rect(target, color, x, y + 5, width, 3);
}

function habitatPeak(target, p, x, top, width, base, snow = true) {
  polygon(target, p.ink, [[x, top], [x - width, base], [x + width, base]]);
  polygon(target, p.land, [[x, top + 3], [x + width - 3, base], [x, base]]);
  if (snow) polygon(target, p.light, [[x, top], [x - 6, top + 11], [x - 2, top + 8], [x + 1, top + 12], [x + 5, top + 9]]);
}

function habitatPine(target, p, x, y, height) {
  rect(target, p.ink, x - 1, y + 4, 3, height);
  [0, 1, 2].forEach(i => {
    const span = 4 + i * 3;
    polygon(target, p.ink, [[x, y + i * 8], [x - span, y + 12 + i * 8], [x + span, y + 12 + i * 8]]);
    rect(target, p.land, x + 1, y + 8 + i * 8, span - 1, 2);
  });
}

function iconBackdrop(target, item, f = 0, sceneOverride = null) {
  if (reducedMotion) f = 0;
  const scene = sceneOverride ?? item.traits.backdrop.value;
  const p = habitatPalette(scene);
  const step = habitatStep(item, f, 8, 4);
  const drift = habitatStep(item, f, 10, 5) - 2;
  rect(target, p.sky, 0, 0, 64, 64);
  rect(target, p.air, 0, 18, 64, 30);
  rect(target, p.land, 0, 48, 64, 16);

  if (scene === 'jetrunway') {
    // A private jet in the narrow strip over the horns; its runway never ends.
    rect(target,p.light,5,6,33,3);rect(target,p.light,35,7,5,1);
    polygon(target,p.light,[[7,7],[7,0],[10,0],[15,7]]);
    polygon(target,p.light,[[20,7],[26,1],[29,1],[25,7]]);
    rect(target,p.ink,17,6,3,1);rect(target,p.ink,23,6,3,1);rect(target,p.ink,29,6,3,1);
    rect(target,p.ink,13,9,2,3);rect(target,p.ink,31,9,2,3);
    rect(target,p.land,0,12,64,52);
    [2,59].forEach(x=>{for(let y=18;y<64;y+=10){rect(target,p.light,x,y,2,4);rect(target,p.accent,x,y+(step%2),2,1);}});
    rect(target,p.ink,52,2,7,15);rect(target,p.light,53,3,5,3);
  } else if (scene === 'ratecut') {
    rect(target,p.sky,0,0,64,45);rect(target,p.land,0,45,64,19);
    // An oversized clock with a hand that moves but never arrives.
    pixelRoundRect(target,p.ink,25,0,14,14,3);pixelRoundRect(target,p.light,27,2,10,10,2);
    rect(target,p.ink,31,4,1,5);rect(target,p.ink,31,7,4,1);rect(target,p.accent,32,8,1,2+step%2);
    [0,56].forEach(x=>{rect(target,p.ink,x,31,8,15);rect(target,p.accent,x+1,33,6,10);rect(target,p.ink,x,46,10,3);rect(target,p.ink,x+1,49,2,13);});
    rect(target,p.ink,3,3,12,8);rect(target,p.light,4,4,10,6);rect(target,p.accent,6,6,6,2);
  } else if (scene === 'chargeyard') {
    // Angular stainless EV above the portrait's horn line; no badge or logo.
    rect(target,p.land,0,11,64,5);
    polygon(target,p.ink,[[2,8],[10,2],[24,2],[35,7],[36,12],[2,12]]);
    polygon(target,p.light,[[4,8],[11,3],[23,3],[32,7],[33,10],[4,10]]);
    polygon(target,p.sky,[[12,4],[22,4],[28,7],[9,7]]);
    rect(target,p.air,4,9,28,1);rect(target,p.ink,7,10,5,4);rect(target,p.ink,26,10,5,4);
    rect(target,p.ink,51,3,7,26);rect(target,p.light,52,4,5,9);rect(target,p.accent,53,6,3,step%2+2);
    rect(target,p.ink,48,13,2,15);rect(target,p.ink,48,27,6,2);
    [3,60].forEach(x=>{rect(target,p.ink,x,35,2,29);rect(target,p.light,x,39,2,6);});
  } else if (scene === 'datacenter') {
    [0,13,46,59].forEach((x,i)=>{rect(target,p.ink,x,0,11,64);rect(target,p.land,x+1,2,9,61);
      for(let y=4;y<62;y+=7){rect(target,p.ink,x+2,y,7,5);rect(target,p.light,x+3,y+1,3,1);rect(target,(y+i+step)%3?p.accent:p.air,x+8,y+2,1,1);}});
    rect(target,p.light,27,2,10,2);rect(target,p.accent,29,5,6,1);
  } else if (scene === 'cactusgarden') {
    habitatCloud(target,p.light,32+drift,1,27);habitatDisc(target,p.accent,14,7,6);
    [4,58].forEach((x,i)=>{const y=17+i*9;rect(target,p.ink,x,y,4,46-y);rect(target,p.ink,x-4,y+8,4,3);rect(target,p.ink,x-5,y+3,2,8);rect(target,p.ink,x+4,y+13,4,3);rect(target,p.ink,x+7,y+7,2,9);rect(target,p.light,x+1,y+3,1,21);});
    rect(target,p.accent,1,53,8,2);rect(target,p.ink,54,59,8,2);
  } else if (scene === 'cloudnine') {
    habitatCloud(target,p.light,-4+drift,1,36);habitatCloud(target,p.light,38-drift,8,32);
    habitatCloud(target,p.light,-12-drift,37,26);habitatCloud(target,p.light,53+drift,46,23);
    rect(target,p.accent,50,3,2,3);rect(target,p.accent,48,4,6,1);
  } else if (scene === 'forest') {
    // A pale moon caught between two black-green firs.
    habitatDisc(target, p.light, 34, 11, 9);
    habitatPine(target, p, 4, 2, 58);
    habitatPine(target, p, 59, 7, 53);
    rect(target, p.land, 0, 43, 64, 5);
    [[3,28],[59,37],[9,43]].forEach(([x,y],i) => rect(target, p.accent, x, y - (step + i) % 3, 2, 2));
  } else if (scene === 'sky') {
    rect(target, p.air, 0, 12, 64, 36);
    habitatCloud(target, p.light, -6 + drift, 3, 29);
    habitatCloud(target, p.light, 42 + drift, 10, 30);
    habitatCloud(target, p.light, 4 - drift, 34, 15);
    polygon(target, p.land, [[0,51],[19,44],[35,51],[53,43],[64,47],[64,64],[0,64]]);
    // A tiny paper kite and its taut string.
    polygon(target, p.accent, [[42,2],[46,6],[42,11],[38,6]]);
    rect(target, p.ink, 42, 11, 1, 6);
  } else if (scene === 'sunny') {
    habitatDisc(target, p.accent, 49, 11, 13);
    habitatDisc(target, p.light, 49, 11, 9);
    [[31,10],[48,27],[29,23]].forEach(([x,y]) => rect(target, p.accent, x, y, 3, 3));
    habitatCloud(target, p.light, -4 + drift, 6, 24);
    polygon(target, p.land, [[0,40],[13,35],[37,44],[59,36],[64,40],[64,64],[0,64]]);
    [3,59].forEach(x => {rect(target,p.ink,x,41,2,15);habitatStar(target,p.light,x,41,2);rect(target,p.accent,x,41,2,2);});
  } else if (scene === 'grass') {
    // A western fence, wheat and the long sweep of pasture.
    polygon(target,p.land,[[0,26],[18,34],[45,28],[64,35],[64,64],[0,64]]);
    rect(target,p.light,0,8,64,2);
    [4,58].forEach(x => {
      rect(target,p.ink,x,27,3,29);
      rect(target,p.accent,x-3,35,9,3);
      rect(target,p.accent,x-3,43,9,3);
      rect(target,p.light,x-1,16,1,12);
      rect(target,p.light,x-3+drift,17,5,2);
      rect(target,p.light,x-3+drift,21,5,2);
    });
    habitatCloud(target,p.light,22+drift,4,22);
  } else if (scene === 'mud') {
    // Copper marsh, bleached reeds and turquoise puddle rings.
    habitatDisc(target,p.light,15,8,8);
    polygon(target,p.land,[[0,30],[12,34],[45,27],[64,31],[64,64],[0,64]]);
    [3,58].forEach((x,i) => {
      rect(target,p.ink,x,16+i*3,2,27);
      rect(target,p.light,x-2,15+i*3,6,9);
      rect(target,p.ink,x-2,17+i*3,6,5);
      pixelEllipse(target,p.ink,x+2,48,11,4);
      pixelEllipse(target,p.accent,x+2,48,8-step,2);
      rect(target,p.land,x-1,48,5,1);
    });
  } else if (scene === 'rainwindow') {
    // Four panes, distant amber windows, long vertical rain streaks.
    rect(target,p.air,0,0,64,48);
    [2,53].forEach(x => {rect(target,p.sky,x,23,9,24);[27,34,41].forEach(y=>rect(target,p.accent,x+2,y,3,3));});
    [9,53].forEach((x,i)=>rect(target,p.light,x,3+(step*5+i*9)%27,1,10));
    rect(target,p.ink,0,0,64,3);
    rect(target,p.ink,0,0,4,64);rect(target,p.ink,60,0,4,64);
    rect(target,p.ink,30,0,4,64);rect(target,p.ink,0,13,64,3);
    rect(target,p.light,4,16,1,28);rect(target,p.land,0,50,64,14);
  } else if (scene === 'bamboo') {
    habitatDisc(target,p.light,35,10,11);
    [2,9,54,61].forEach((x,i) => {
      rect(target,p.ink,x-1,0,5,64);rect(target,p.land,x,0,2,64);
      [8,22,36,50].forEach(y=>rect(target,p.light,x,y+i*2,3,2));
      polygon(target,p.ink,[[x,20],[x+(i%2?-9:9),12],[x+(i%2?-6:6),22]]);
    });
    polygon(target,p.accent,[[37+drift,3+step],[43+drift,1+step],[40+drift,6+step]]);
  } else if (scene === 'cave') {
    // Monumental stepped stone arch with cyan crystal clusters at the edges.
    rect(target,p.ink,0,0,64,64);
    polygon(target,p.air,[[17,9],[47,9],[55,17],[60,36],[60,64],[4,64],[4,36],[9,17]]);
    polygon(target,p.sky,[[24,15],[40,15],[50,27],[54,64],[10,64],[14,27]]);
    [[3,4,15,4],[21,2,20,4],[45,5,15,4],[1,16,8,9],[56,20,8,11]].forEach(([x,y,w,h])=>rect(target,p.land,x,y,w,h));
    [4,58].forEach((x,i)=>{
      polygon(target,p.accent,[[x,31],[x+4,40],[x+2,54],[x-3,42]]);
      rect(target,p.light,x,37,1,9);
      if(step===i) habitatStar(target,p.light,x,31,1);
    });
  } else if (scene === 'fire') {
    rect(target,p.ink,0,0,64,64);
    rect(target,p.air,4,7,56,49);rect(target,p.sky,8,11,48,41);
    rect(target,p.light,0,5,64,3);rect(target,p.land,0,8,64,3);
    [2,58].forEach(x=>{rect(target,p.land,x,14,4,38);[20,31,42].forEach(y=>rect(target,p.accent,x,y,4,2));});
    [6,56].forEach((x,i)=>{
      polygon(target,p.accent,[[x-5,58],[x-4,40],[x,27-step+i*2],[x+3,42],[x+6,48],[x+5,59]]);
      polygon(target,p.light,[[x-2,57],[x,41+step],[x+3,53],[x+2,58]]);
      rect(target,p.accent,x+1,18+step*2,2,3);
    });
  } else if (scene === 'storm') {
    habitatCloud(target,p.ink,-5,0,40);habitatCloud(target,p.ink,28,3,40);
    polygon(target,p.light,[[49,8],[43,18],[48,18],[42,31],[57,14],[51,14],[56,8]]);
    polygon(target,p.land,[[0,45],[8,33],[19,45],[43,40],[57,29],[64,40],[64,64],[0,64]]);
    [3,8,56,61].forEach((x,i)=>rect(target,p.accent,x,20+(step*5+i*7)%24,1,7));
  } else if (scene === 'desert') {
    // Huge cut-paper sun, flat mesa silhouettes and a lone cactus.
    habitatDisc(target,p.light,34,14,15);
    rect(target,p.accent,0,32,64,16);
    polygon(target,p.ink,[[0,24],[10,24],[13,31],[17,31],[20,51],[0,56]]);
    polygon(target,p.land,[[46,31],[51,21],[60,21],[64,27],[64,64],[45,64]]);
    rect(target,p.light,0,24,10,2);rect(target,p.light,51,21,9,2);
    rect(target,p.ink,57,32,3,24);rect(target,p.ink,53,37,5,3);rect(target,p.ink,52,32,2,7);
    rect(target,p.accent,3+step,52,8,1);
  } else if (scene === 'ice') {
    rect(target,p.light,0,7,64,2);rect(target,p.air,0,9,64,34);
    [2,56].forEach((x,i)=>{
      polygon(target,p.ink,[[x-3,53],[x+1,19-i*4],[x+8,33],[x+10,54]]);
      polygon(target,p.light,[[x-1,49],[x+2,23-i*4],[x+4,37],[x+4,51]]);
      polygon(target,p.accent,[[x+4,35],[x+7,33],[x+8,51],[x+4,51]]);
    });
    rect(target,p.sky,0,52,64,12);
    [[3,57,9],[51,55,11],[22,61,17]].forEach(([x,y,w])=>rect(target,p.light,x+drift,y,w,1));
    habitatStar(target,p.light,46,6,2);
  } else if (scene === 'snow') {
    habitatPeak(target,p,38,1,28,43,true);
    // Cabin roof and its lit window occupy the exposed left edge.
    rect(target,p.land,0,40,64,24);
    rect(target,p.ink,0,24,12,26);polygon(target,p.ink,[[0,24],[7,13],[18,26]]);
    polygon(target,p.light,[[0,23],[7,13],[18,26],[13,25],[7,18],[3,24]]);
    rect(target,p.accent,3,29,5,7);rect(target,p.ink,5,29,1,7);
    habitatPine(target,p,59,15,37);
    [[4,4],[17,7],[51,3],[59,34]].forEach(([x,y],i)=>rect(target,p.light,x,(y+step*3+i)%43,2,2));
  } else if (scene === 'lab') {
    rect(target,p.ink,0,0,64,64);
    rect(target,p.air,12,12,40,42);
    // Amber-green CRTs: big frames, one waveform, no microtext.
    [[2,3],[43,3]].forEach(([x,y],i)=>{
      pixelRoundRect(target,p.land,x,y,19,14,2);rect(target,p.accent,x+2,y+2,15,10);
      rect(target,p.ink,x+3,y+6,4,1);rect(target,p.ink,x+7,y+4+(i+step)%2,2,5);
      rect(target,p.ink,x+9,y+7,7,1);rect(target,p.light,x+3,y+3,4,1);
    });
    [3,56].forEach(x=>{rect(target,p.land,x,22,5,29);[26,34,42].forEach((y,i)=>rect(target,i===step%3?p.light:p.accent,x+1,y,2,3));});
    rect(target,p.land,0,54,64,10);
  } else if (scene === 'rooftop') {
    habitatDisc(target,p.light,42,9,8);habitatDisc(target,p.sky,46,6,7);
    [[0,26,11],[54,19,10],[7,35,10],[44,38,9]].forEach(([x,y,w])=>{
      rect(target,p.ink,x,y,w,64-y);rect(target,p.land,x+2,y+3,w-4,64-y);
      [y+6,y+14,y+22].forEach(yy=>rect(target,p.light,x+3,yy,2,3));
    });
    rect(target,p.ink,58,5,1,15);rect(target,p.accent,57,5+step%2,3,2);
    rect(target,p.ink,0,51,64,3);
    habitatStar(target,p.light,15,5,1);
  } else if (scene === 'moon') {
    habitatDisc(target,p.light,33,16,20);
    habitatDisc(target,p.accent,27,5,4);habitatDisc(target,p.accent,43,11,3);
    habitatDisc(target,p.air,24,13,2);habitatDisc(target,p.accent,36,23,5);
    polygon(target,p.land,[[0,42],[18,36],[35,45],[56,36],[64,40],[64,64],[0,64]]);
    [[5,9],[59,3],[4,31],[59,38]].forEach(([x,y],i)=>habitatStar(target,i===step?p.light:p.accent,x,y,1));
    pixelEllipse(target,p.ink,7,52,9,2);pixelEllipse(target,p.accent,57,48,8,2);
  } else if (scene === 'mountain') {
    habitatDisc(target,p.accent,34,8,8);
    habitatPeak(target,p,9,5,25,56,true);habitatPeak(target,p,54,0,27,57,true);
    habitatCloud(target,p.light,22+drift,4,19);
    rect(target,p.air,0,43,64,3);rect(target,p.land,0,53,64,11);
  } else if (scene === 'blue') {
    habitatDisc(target,p.light,12,9,7);habitatDisc(target,p.sky,15,6,6);
    rect(target,p.light,0,39,64,1);rect(target,p.land,0,40,64,24);
    // A lighthouse stripe reads even behind the portrait crop.
    rect(target,p.ink,55,18,7,29);rect(target,p.light,57,21,3,23);
    rect(target,p.accent,54,17,9,3);rect(target,p.light,57,13,3,4);
    polygon(target,p.accent,[[54,16],[42,11],[42,20]]);
    [44,50,57].forEach((y,i)=>rect(target,p.accent,2+((step+i)%3)*2,y,10-i*2,1));
  } else if (scene === 'horizon') {
    habitatDisc(target,p.accent,32,13,15);
    rect(target,p.air,0,20,64,28);
    rect(target,p.light,0,20,64,2);rect(target,p.land,0,43,64,21);
    rect(target,p.ink,0,47,64,2);
    [5,58].forEach(x=>{rect(target,p.ink,x,32,2,21);rect(target,p.light,x-2,34,6,2);});
    rect(target,p.accent,3+step,53,8,1);
  } else if (scene === 'sunset') {
    habitatDisc(target,p.light,33,16,20);
    [14,19,25,32].forEach((y,i)=>rect(target,p.sky,9,y,48,1+i));
    rect(target,p.accent,0,36,64,12);rect(target,p.ink,0,48,64,16);
    polygon(target,p.land,[[0,33],[8,27],[17,41],[30,45],[52,32],[64,35],[64,49],[0,49]]);
    [51,57].forEach(y=>rect(target,p.light,2+drift,y,9,1));
  } else if (scene === 'oasis') {
    habitatDisc(target,p.accent,35,9,11);
    rect(target,p.land,0,42,64,22);pixelEllipse(target,p.sky,32,53,31,8);
    [4,59].forEach((x,i)=>{
      rect(target,p.ink,x,14,3,37);
      polygon(target,p.ink,[[x+1,12],[x-11+drift,7],[x-8,14],[x,17],[x+11,12],[x+10-drift,7]]);
      polygon(target,p.ink,[[x+1,12],[x-4,3],[x+1,5],[x+6,1],[x+6,9]]);
      rect(target,p.accent,x,19+i*3,2,3);
    });
    rect(target,p.light,0,49,10,2);rect(target,p.light,54,54,10,2);
  } else if (scene === 'volcano') {
    // Twin vents frame the creature; ember plumes stay behind the horn line.
    [4,59].forEach((x,i)=>{
      habitatCloud(target,p.ink,x-9,3+i*3,23);
      rect(target,p.accent,x-2,12,5,15);
      rect(target,p.light,x,15+step,2,5);
      habitatPeak(target,p,x,26,18,59,false);
      polygon(target,p.accent,[[x-2,26],[x+3,26],[x+1,34],[x+5,44],[x,47],[x-3,36]]);
      rect(target,p.light,x,27,2,6);
    });
    rect(target,p.ink,0,57,64,7);rect(target,p.accent,0,60,64,2);
  } else if (scene === 'aurora') {
    // A folded ribbon rather than many thin glowing lines.
    polygon(target,p.accent,[[0,4+drift],[13,9],[27,2],[41,8],[55,1],[64,4],[64,17],[53,12],[40,19],[26,12],[12,19],[0,13]]);
    polygon(target,p.light,[[0,4+drift],[13,9],[27,2],[41,8],[55,1],[64,4],[64,7],[55,4],[41,11],[27,5],[13,12],[0,7+drift]]);
    habitatPeak(target,p,3,31,18,61,true);habitatPeak(target,p,60,27,22,61,true);
    habitatStar(target,p.light,4,24,1);habitatStar(target,p.light,59,22,1);
  } else if (scene === 'cityrain') {
    rect(target,p.ink,0,0,12,64);rect(target,p.ink,52,0,12,64);
    // Two graphic neon sign glyphs with restrained, slow movement.
    rect(target,p.accent,2,6,8,23);rect(target,p.ink,3,7,6,21);
    [10,17,24].forEach(y=>{rect(target,p.accent,4,y,4,2);rect(target,p.accent,5,y-2,2,5);});
    rect(target,p.light,54,13,8,19);rect(target,p.ink,55,14,6,17);
    rect(target,p.light,57,17,2,11);rect(target,p.light,55,21,6,2);
    rect(target,p.accent,20,2,24,2);rect(target,p.ink,21,4,22,2);
    [3,59].forEach((x,i)=>rect(target,p.light,x,35+(step*3+i*5)%12,1,7));
    rect(target,p.accent,2,53,8,2);rect(target,p.light,54,57,8,2);
  }
  rect(target,p.ink,0,62,64,2);
}

function iconWeather(target, item, f) {
  const weather = item.traits.weather.value;
  if (weather === "dusk") {
    const duskX = -16 + habitatStep(item, f, 4, 6) * 16;
    rect(target, lofi.dusk, 0, 0, 64, 4);
    rect(target, lofi.ember, duskX, 0, 20, 4);
  } else if (weather === "pollen") {
    [[6, 10], [54, 18], [6, 38], [56, 44]].forEach(([x, y], index) => {
      const fall = (f + item.phase + index * 7) % 24;
      rect(target, colors.honey, x + (fall % 3) * 2, (y + fall * 2) % 54, 2, 2);
    });
  } else if (weather === "snow") {
    [[4, 8], [56, 12], [8, 34], [54, 40]].forEach(([x, y], index) => {
      const fall = (f + item.phase + index * 9) % 28;
      rect(target, colors.bone, x + (index % 2 ? fall % 4 : 0), (y + fall * 2) % 56, 2, 4);
    });
  } else if (weather === "smog") {
    const drift = habitatStep(item, f, 3, 8) * 4;
    rect(target, "#6d675e", -16 + drift, 8, 32, 4);
    rect(target, "#6d675e", 48 - drift, 18, 32, 4);
  } else if (weather === "redsun") {
    const pulse = habitatStep(item, f, 5, 2) * 2;
    rect(target, colors.orange, 50 - pulse / 2, 6 - pulse / 2, 10 + pulse, 10 + pulse);
    rect(target, colors.honey, 53 - pulse / 2, 9 - pulse / 2, 4 + pulse, 4 + pulse);
  } else if (weather === "ticker") {
    [4, 14, 48, 58].forEach((x, index) => {
      const up = (index + habitatStep(item, f, 3, 2)) % 2 === 0;
      const lift = habitatStep(item, f + index * 2, 2, 3) * 2;
      rect(target, up ? colors.mint : colors.orange, x, 8 + index * 4, 2, 10);
      rect(target, up ? colors.mint : colors.orange, x - 2, 12 + index * 4 - lift, 6, 2 + lift);
    });
  } else if (weather === "blackout") {
    const shutter = habitatStep(item, f, 4, 2) * 2;
    rect(target, colors.ink, 0, 0, 6 + shutter, 64);
    rect(target, colors.ink, 58 - shutter, 0, 6 + shutter, 64);
    rect(target, shutter ? colors.orange : colors.blue, 2, 2, 4, 4);
  }
}

function iconAura(target, item, f) {
  const aura = item.traits.aura.value;
  const pulse = (f % 2) * 2;
  if (aura === "flies" || aura === "dust" || aura === "static") {
    const color = aura === "flies" ? colors.ink : aura === "dust" ? colors.bone : colors.orange;
    [[6, 18], [56, 26], [8, 44], [52, 10]].forEach(([x, y], index) => {
      rect(target, color, x + ((index + f) % 2) * 2, y, 2, 2);
    });
  } else if (aura === "stink") {
    rect(target, colors.mint, 4 + pulse, 36, 4, 12);
    rect(target, colors.mint, 56 - pulse, 28, 4, 12);
  } else if (aura === "flame") {
    rect(target, colors.blue, 2, 42 - pulse, 6, 18 + pulse);
    rect(target, colors.blue, 56, 38 + pulse, 6, 22 - pulse);
  } else if (aura === "rain") {
    [4, 14, 50, 60].forEach((x, index) => rect(target, colors.orange, x, 8 + ((f + index) % 3) * 4, 2, 10));
  } else if (aura === "moon") {
    rect(target, colors.honey, 4, 4, 56, 2);
    rect(target, colors.honey, 4, 58, 56, 2);
    rect(target, colors.honey, 4, 4, 2, 56);
    rect(target, colors.honey, 58, 4, 2, 56);
  } else if (aura === "charts") {
    [[2, 34], [6, 30], [10, 32], [14, 24]].forEach(([x, y]) => rect(target, colors.mint, x, y - pulse, 4, 4));
    [[48, 20], [52, 24], [56, 22], [60, 30]].forEach(([x, y]) => rect(target, colors.orange, x, y + pulse, 4, 4));
  }
}

function iconFormAura(target, item, f) {
  if (item.traits.form.value !== "possessed") return;
  const lift = habitatStep(item, f, 3, 3) * 2;
  const glow = "#78a978";
  const darkGlow = "#3f6f55";
  [[0, 48, 6], [4, 34, 5], [8, 22, 4], [58, 46, 6], [54, 30, 5], [50, 18, 4]].forEach(([x, y, w], index) => {
    const sideLift = index < 3 ? lift : -lift;
    rect(target, darkGlow, x, y + sideLift, w, 18);
    rect(target, glow, index < 3 ? x + w - 2 : x, y - 4 + sideLift, 2, 12);
  });
}

function iconShoulders(target, item, breathe) {
  const form = item.traits.form.value;
  const formOverridesWardrobe = ["robot", "zombie", "possessed", "hollow", "skull"].includes(item.traits.form.value);
  const outfit = formOverridesWardrobe ? "bare" : item.traits.outfit.value;
  const pose = formOverridesWardrobe ? "front" : item.traits.pose.value;
  const bullness = item.balance / 100;
  const y = snapEven(46 - bullness * 2) + breathe;
  const fills = {
    track: "#285fc0",
    puffer: "#8a4b35",
    poncho: "#32865b",
    overalls: "#2f6fac",
    suit: "#303b42",
    varsity: "#b94c30",
    bonebib: "#706653",
    space: "#487f8b",
    cult: "#454fa0",
    wings: "#2c5ac4",
    hazard: "#b47725",
    tux: colors.soot,
    pinstripe: "#303b42",
    racing: colors.orange,
    bomber: "#52634b",
    kimono: "#304d8d",
    raincoat: colors.honey,
    shearling: "#805234",
    keynote: "#252b30",
    vcvest: "#597277",
    armor: "#637c86"
  };
  // One dark shoulder mass is the collection's icon base. Coat variation
  // belongs to the face; outfits can still replace this fill when present.
  // Even the bare bust carries a blue-black plush tone. It stays dark enough
  // to frame the face, but no longer collapses into a featureless black slab.
  const bullMantle = mixHex("#1b2830", "#2868cf", 0.22 + bullness * 0.58);
  const formBareFills = {
    degen: "#2458b8",
    mad: "#b84a2d",
    robot: "#3f6f78",
    zombie: "#527143",
    skull: "#c9572c",
    hollow: "#344b8e",
    possessed: "#2f58b3"
  };
  const bareFill = form === "normie" ? bullMantle : formBareFills[form] ?? colors.soot;
  const fill = fills[outfit] ?? bareFill;
  // Each shoulder grows as a stepped quarter-circle: inset at the top, broad
  // through the middle, then meeting the chest at the bottom. This preserves
  // the heavy cloak silhouette without reading as two square torso blocks.
  const topWidth = snapEven(10 + bullness * 2 + (pose === "check" ? 4 : pose === "close" ? 6 : 0));
  const bottomWidth = 32;
  const leftLift = pose === "left" || pose === "crooked" ? -2 : pose === "right" ? 2 : pose === "high" ? -2 : pose === "low" ? 2 : 0;
  const rightLift = pose === "right" ? -2 : pose === "left" || pose === "crooked" ? 2 : pose === "high" ? -2 : pose === "low" ? 2 : 0;
  const drawShoulder = (side, lift) => {
    const startY = y + lift;
    const rows = Math.max(1, Math.ceil((64 - startY) / 2));
    for (let row = 0; row < rows; row += 1) {
      const progress = row / Math.max(1, rows - 1);
      const arc = Math.sin(progress * Math.PI / 2);
      const width = snapEven(topWidth + (bottomWidth - topWidth) * arc);
      const edgeInset = snapEven(8 * (1 - arc));
      const x = side < 0 ? edgeInset : 64 - edgeInset - width;
      const rowY = startY + row * 2;
      rect(target, colors.ink, x, rowY, width, 2);
      const bodyTone = progress < 0.36 ? mixHex(fill, item.palette.coat, 0.1) : fill;
      if (width > 4) rect(target, bodyTone, x + 2, rowY, width - 4, 2);
    }
  };
  drawShoulder(-1, leftLift);
  drawShoulder(1, rightLift);
  const chestTop = Math.min(52, y + 4);
  const chestRows = Math.max(1, Math.ceil((64 - chestTop) / 2));
  for (let row = 0; row < chestRows; row += 1) {
    const progress = row / Math.max(1, chestRows - 1);
    const width = snapEven(8 + progress * 14);
    const rowY = chestTop + row * 2;
    rect(target, colors.ink, 32 - width / 2, rowY, width, 2);
    if (width > 4) rect(target, fill, 34 - width / 2, rowY, width - 4, 2);
  }
  rect(target, colors.ink, 30, 62, 4, 2);

  if (outfit === "bare" && ["degen", "mad"].includes(form)) {
    const edge = form === "degen" ? colors.orange : colors.blue;
    polygon(target, edge, [[2, 64], [7, y + 8], [19, y + 2], [25, 64]]);
    polygon(target, edge, [[62, 64], [57, y + 8], [45, y + 2], [39, 64]]);
    polygon(target, bareFill, [[4, 64], [9, y + 9], [19, y + 5], [23, 64]]);
    polygon(target, bareFill, [[60, 64], [55, y + 9], [45, y + 5], [41, 64]]);
  }

  if (outfit === "bare" && form === "normie" && bullness >= 0.65) {
    polygon(target, colors.orange, [[7, 64], [12, y + 11], [21, y + 5], [31, 58], [27, 64]]);
    polygon(target, colors.orange, [[57, 64], [52, y + 11], [43, y + 5], [33, 58], [37, 64]]);
    polygon(target, bullMantle, [[11, 64], [15, y + 12], [21, y + 9], [28, 59], [25, 64]]);
    polygon(target, bullMantle, [[53, 64], [49, y + 12], [43, y + 9], [36, 59], [39, 64]]);
  }

  if (outfit === "bare" && ["robot", "zombie", "skull", "hollow", "possessed"].includes(form)) {
    const formAccent = form === "possessed" || form === "skull" ? colors.orange : form === "hollow" ? colors.mint : colors.honey;
    polygon(target, formAccent, [[7, 64], [12, y + 11], [21, y + 5], [31, 58], [27, 64]]);
    polygon(target, formAccent, [[57, 64], [52, y + 11], [43, y + 5], [33, 58], [37, 64]]);
    polygon(target, bareFill, [[11, 64], [15, y + 12], [21, y + 9], [28, 59], [25, 64]]);
    polygon(target, bareFill, [[53, 64], [49, y + 12], [43, y + 9], [36, 59], [39, 64]]);
  }

  if (["track", "varsity", "overalls"].includes(outfit)) {
    rect(target, colors.bone, 26, y + 12, 2, 6);
    rect(target, colors.bone, 36, y + 12, 2, 6);
  } else if (outfit === "puffer") {
    rect(target, colors.ink, 4, y + 10, 16, 2);
    rect(target, colors.ink, 44, y + 10, 16, 2);
    rect(target, colors.ink, 8, y + 16, 16, 2);
    rect(target, colors.ink, 40, y + 16, 16, 2);
  } else if (outfit === "poncho") {
    rect(target, colors.mint, 10, y + 14, 14, 2);
    rect(target, colors.mint, 40, y + 14, 14, 2);
  } else if (outfit === "suit") {
    rect(target, colors.bone, 24, y + 10, 4, 8);
    rect(target, colors.bone, 36, y + 10, 4, 8);
    rect(target, colors.orange, 31, y + 14, 2, 4);
  } else if (outfit === "bonebib") {
    rect(target, colors.bone, 28, y + 12, 8, 4);
  } else if (outfit === "space") {
    rect(target, colors.mint, 8, y + 14, 4, 4);
    rect(target, colors.orange, 52, y + 14, 4, 4);
  } else if (outfit === "cult") {
    rect(target, colors.orange, 28, y + 14, 8, 2);
  } else if (outfit === "wings") {
    rect(target, colors.orange, 2, y + 10, 12, 10);
    rect(target, colors.blue, 50, y + 10, 12, 10);
  } else if (outfit === "hazard") {
    rect(target, colors.ink, 8, y + 12, 10, 4);
    rect(target, colors.ink, 46, y + 16, 10, 4);
  }

  // Broad collar shapes live outside the face, so each outfit reads at 64 px.
  if (["tux", "pinstripe", "suit"].includes(outfit)) {
    polygon(target, colors.bone, [[12, y + 3], [19, y + 6], [27, 64], [20, 64]]);
    polygon(target, colors.bone, [[52, y + 3], [45, y + 6], [37, 64], [44, 64]]);
    if (outfit === "pinstripe") {
      [5, 10, 15, 47, 52, 57].forEach((x) => rect(target, "#87918c", x, y + 10, 1, 18));
    } else if (outfit === "tux") {
      rect(target, colors.orange, 25, 59, 5, 4);
      rect(target, colors.orange, 34, 59, 5, 4);
      rect(target, colors.ink, 30, 59, 4, 4);
      rect(target, colors.bone, 7, y + 11, 6, 2);
    }
  } else if (outfit === "racing") {
    [7, 51].forEach((x) => {
      rect(target, colors.ink, x, y + 6, 6, 20);
      rect(target, colors.bone, x + 2, y + 6, 2, 20);
    });
    rect(target, colors.bone, 13, y + 10, 7, 5);
    rect(target, colors.ink, 15, y + 11, 3, 3);
  } else if (outfit === "bomber") {
    rect(target, colors.ink, 5, y + 9, 8, 2);
    rect(target, colors.orange, 8, y + 10, 2, 7);
    rect(target, colors.ink, 47, y + 10, 10, 6);
    rect(target, colors.bone, 49, y + 11, 6, 2);
    rect(target, colors.ink, 3, 62, 58, 2);
  } else if (outfit === "kimono") {
    polygon(target, colors.bone, [[12, y + 2], [17, y + 2], [34, 64], [29, 64]]);
    polygon(target, colors.blue, [[52, y + 2], [47, y + 2], [33, 64], [38, 64]]);
    rect(target, colors.bone, 5, y + 12, 7, 2);
    rect(target, colors.bone, 8, y + 9, 2, 8);
  } else if (outfit === "raincoat") {
    polygon(target, colors.bone, [[12, y], [20, y + 3], [21, 59], [14, 55], [8, 58]]);
    polygon(target, colors.bone, [[52, y], [44, y + 3], [43, 59], [50, 55], [56, 58]]);
    rect(target, colors.ink, 6, 60, 10, 2);
    rect(target, colors.ink, 48, 60, 10, 2);
  } else if (outfit === "shearling") {
    [-1, 1].forEach((side) => {
      const x = side < 0 ? 9 : 47;
      pixelRoundRect(target, colors.bone, x, y + 1, 8, 15, 3);
      rect(target, colors.bone, x - 2, y + 5, 12, 5);
      rect(target, colors.mud, side < 0 ? 5 : 53, 61, 6, 2);
    });
  } else if (outfit === "armor") {
    [4, 48].forEach((x) => {
      pixelRoundRect(target, colors.ink, x, y + 2, 12, 12, 3);
      pixelRoundRect(target, colors.bone, x + 2, y + 4, 8, 7, 2);
      rect(target, colors.aqua, x + 3, y + 6, 6, 2);
      rect(target, colors.ink, x, y + 16, 12, 2);
    });
  }

  if (outfit === 'keynote') {
    rect(target,colors.ink,18,y+1,28,18);rect(target,'#414b50',20,y+5,24,2);
    rect(target,'#75807c',25,y+9,14,1);rect(target,'#414b50',30,59,4,5);
  } else if (outfit === 'vcvest') {
    rect(target,colors.bone,3,y+8,10,18);rect(target,colors.bone,51,y+8,10,18);
    [14,37].forEach(x=>{rect(target,'#597277',x,y+3,13,20);rect(target,'#819392',x,y+13,13,1);});
    rect(target,colors.bone,30,y+5,4,21);rect(target,colors.ink,31,y+5,1,21);
    rect(target,colors.bone,40,56,7,4);rect(target,colors.orange,42,57,3,1);
  }
  const neck = formOverridesWardrobe ? "none" : item.traits.neck.value;
  if (["bell", "chain", "wallet", "seed", "medal"].includes(neck)) {
    const artifact = neck === "wallet" ? colors.mint : neck === "seed" ? colors.bone : neck === "medal" ? colors.orange : colors.honey;
    rect(target, colors.ink, 27, y + 12, 10, 8);
    rect(target, artifact, 29, y + 14, 6, 6);
  } else if (neck === "hoodie") {
    rect(target, colors.ink, 14, y + 8, 8, 8);
    rect(target, colors.ink, 42, y + 8, 8, 8);
  } else if (neck === "cape") {
    rect(target, colors.orange, 6, y + 10, 12, 10);
    rect(target, colors.orange, 46, y + 10, 12, 10);
  } else if (neck === "earring") {
    rect(target, colors.mint, 52, 42, 4, 10);
  }

}

function visibleHornStage(item) {
  const stage = spectrumAnatomy(item.balance).hornStage;
  return item.traits.form.value === "robot" ? Math.max(2, stage) : stage;
}

function hornTipColor(item) {
  const horn = item.traits.horns.value;
  if (["goldtips", "candles", "diamond"].includes(horn)) return colors.honey;
  if (horn === "antenna") return colors.blue;
  if (horn === "flowers") return colors.mint;
  return colors.honey;
}

function iconHornStroke(target, points, item) {
  const pixels = [];
  for (let index = 1; index < points.length; index += 1) {
    const from = points[index - 1];
    const to = points[index];
    const steps = Math.max(Math.abs(to.x - from.x), Math.abs(to.y - from.y));
    for (let step = 0; step <= steps; step += 1) {
      const progress = steps === 0 ? 0 : step / steps;
      const x = Math.round(from.x + (to.x - from.x) * progress);
      const y = Math.round(from.y + (to.y - from.y) * progress);
      if (!pixels.some((pixel) => pixel.x === x && pixel.y === y)) pixels.push({ x, y });
    }
  }
  pixels.forEach(({ x, y }, index) => {
    const radius = index < pixels.length * 0.55 ? 3 : index < pixels.length * 0.85 ? 2 : 1;
    pixelEllipse(target, colors.ink, x, y, radius, radius);
  });
  pixels.forEach(({ x, y }, index) => {
    const rootHalf = index < pixels.length * 0.55;
    const radius = rootHalf ? 2 : index < pixels.length * 0.85 ? 1 : 0;
    const horn = item.traits.horns.value;
    const fill = horn === "chrome" ? (rootHalf ? colors.blue : colors.bone)
      : horn === "crystal" ? (rootHalf ? colors.aqua : colors.bone)
        : rootHalf ? colors.orange : colors.honey;
    pixelEllipse(target, fill, x, y, radius, radius);
  });
}

function iconHornPoints(item, side, headX, headY, headW, inset = 0, stage = 3) {
  const anatomy = spectrumAnatomy(item.balance);
  const profiles = {
    highland: [[0, 0], [0, -3], [2, -7], [5, -10]],
    angus: [[0, 0], [0, -3], [2, -6]],
    brahman: [[0, 0], [1, -4], [3, -8], [6, -10]],
    longhorn: [[0, 0], [3, -2], [7, -4], [11, -4], [14, -8]],
    zebu: [[0, 0], [0, -4], [2, -8], [5, -11]],
    fighting: [[0, 0], [2, -3], [5, -7], [8, -9]],
    watusi: [[0, 0], [0, -4], [1, -8], [3, -12]]
  };
  let profile = profiles[item.traits.bullKind.value] ?? profiles.highland;
  if (stage === 1) profile = [[0, 0], [0, -4], [2, -9]];
  if (stage === 2) profile = [[0, 0], [0, -4], [2, -8], [4, -11]];
  const signatureProfiles = {
    crescent: [[0, 0], [4, -2], [7, -6], [7, -11], [4, -14]],
    ram: [[0, 0], [4, -5], [9, -5], [12, -1], [12, 3], [8, 5], [6, 2]],
    bolt: [[0, 0], [1, -4], [6, -4], [3, -8], [8, -13]],
    crystal: [[0, 0], [2, -5], [5, -12]],
    broken: side < 0 ? [[0, 0], [1, -4], [4, -6]] : [[0, 0], [2, -5], [5, -12]],
    chrome: [[0, 0], [3, -2], [8, -6], [10, -12]]
  };
  if (signatureProfiles[item.traits.horns.value]) {
    const scale = stage === 1 ? 0.68 : stage === 2 ? 0.84 : 1;
    profile = signatureProfiles[item.traits.horns.value].map(([x, y]) => [Math.round(x * scale), Math.round(y * scale)]);
  }
  if (item.traits.horns.value === "roots") profile = [[0, 0], [0, -4], [2, -8]];
  if (item.traits.horns.value === "sawed") profile = profile.slice(0, 2);
  const rootMargin = stage === 3 ? Math.round(10 - anatomy.bullness * 4) : 10;
  const outwardScale = stage === 3 ? 1 + Math.max(0, anatomy.bullness - 0.6) * 0.75 : 1;
  const rootX = side < 0 ? headX + rootMargin + inset : headX + headW - rootMargin - inset;
  const rootY = headY + 2 + inset / 2;
  return profile.map(([outward, rise]) => ({
    x: clamp(rootX + side * Math.round(outward * outwardScale), 4, 59),
    y: Math.max(6, Math.round(rootY + rise))
  }));
}

function iconHorn(target, item, side, headX, headY, headW, inset = 0, stage = 3) {
  const points = iconHornPoints(item, side, headX, headY, headW, inset, stage);
  iconHornStroke(target, points, item);

  const root = points[0];
  const tip = points.at(-1);
  pixelEllipse(target, colors.ink, root.x, root.y, 2, 2);
  pixelEllipse(target, colors.orange, root.x, root.y, 1, 1);
  if (["goldtips", "antenna", "flowers", "candles", "diamond"].includes(item.traits.horns.value)) {
    rect(target, hornTipColor(item), tip.x - 1, tip.y - 2, 2, 3);
  }

  if (item.traits.horns.value === "crystal" || item.traits.horns.value === "diamond") {
    polygon(target, colors.ink, [[tip.x, tip.y - 4], [tip.x + 4, tip.y], [tip.x, tip.y + 5], [tip.x - 4, tip.y]]);
    polygon(target, colors.aqua, [[tip.x, tip.y - 2], [tip.x + 2, tip.y], [tip.x, tip.y + 3], [tip.x - 2, tip.y]]);
    rect(target, colors.bone, tip.x, tip.y - 1, 1, 3);
  }

  if (stage === 3 && item.traits.horns.value === "candles") rect(target, colors.orange, tip.x - 1, tip.y - 6, 2, 4);
  if (stage === 3 && item.traits.horns.value === "flowers") {
    rect(target, colors.mint, tip.x - 4, tip.y - 2, 8, 4);
    rect(target, colors.mint, tip.x - 2, tip.y - 4, 4, 8);
    rect(target, colors.honey, tip.x - 1, tip.y - 1, 2, 2);
  }
}

function iconHorns(target, item, headX, headY, headW) {
  const stage = visibleHornStage(item);
  if (stage === 3 && item.traits.horns.value === "double") {
    iconHorn(target, item, -1, headX, headY + 2, headW, 8, stage);
    iconHorn(target, item, 1, headX, headY + 2, headW, 8, stage);
  }
  iconHorn(target, item, -1, headX, headY, headW, 0, stage);
  iconHorn(target, item, 1, headX, headY, headW, 0, stage);
}

function iconHornRoots(target, item, headX, headY, headW) {
  const stage = visibleHornStage(item);
  const roots = [-1, 1].map((side) => iconHornPoints(item, side, headX, headY, headW, 0, stage)[0].x);
  roots.forEach((x) => {
    const rootHeight = stage === 1 ? 2 : 4;
    rect(target, colors.ink, x - 3, headY, 6, rootHeight);
    const fill = item.traits.horns.value === "chrome" ? colors.blue : item.traits.horns.value === "crystal" ? colors.aqua : colors.orange;
    rect(target, fill, x - 2, headY, 4, Math.max(2, rootHeight - 1));
  });
  if (stage === 3 && item.traits.horns.value === "double") {
    rect(target, colors.orange, headX + 14, headY, 4, 4);
    rect(target, colors.orange, headX + headW - 18, headY, 4, 4);
  }
}

function iconEars(target, item, headX, headY, headW) {
  const anatomy = spectrumAnatomy(item.balance);
  const style = item.traits.ears.value;
  const bull = anatomy.earMode === "bull";
  const fluffy = ["koala", "sloth"].includes(item.traits.bearKind.value);
  const droop = ["brahman", "zebu"].includes(item.traits.bullKind.value);
  const coat = item.traits.bearKind.value === "panda" ? colors.soot : item.palette.coat;
  const rx = bull ? 8 : fluffy ? 7 : 6;
  const ry = bull ? (droop ? 6 : 4) : fluffy ? 7 : 6;
  [-1, 1].forEach((side) => {
    const cx = side < 0 ? headX - 3 : headX + headW + 2;
    const cy = headY + (bull ? 8 : 3);
    const folded = style === "folded" && side < 0;
    if (style === "pointed") {
      const tip = cx + side * (bull ? 7 : 3);
      polygon(target, colors.ink, [[cx - rx, cy + 3], [tip, cy - ry - 4], [cx + rx, cy + 3], [cx, cy + ry]]);
      polygon(target, coat, [[cx - rx + 2, cy + 2], [tip, cy - ry], [cx + rx - 2, cy + 2], [cx, cy + ry - 2]]);
      rect(target, item.palette.shade, cx - 1, cy - 2, 3, 5);
    } else if (folded) {
      pixelRoundRect(target, colors.ink, cx - rx, cy - 2, rx * 2, ry + 5, 3);
      pixelRoundRect(target, coat, cx - rx + 2, cy, rx * 2 - 4, ry + 1, 2);
      rect(target, item.palette.shade, cx - rx + 2, cy, rx * 2 - 4, 2);
    } else {
      pixelEllipse(target, colors.ink, cx, cy, rx, ry);
      pixelEllipse(target, coat, cx, cy, rx - 2, ry - 2);
      pixelEllipse(target, item.palette.shade, cx + side, cy + 1, bull ? 4 : 2, bull ? 1 : 3);
    }
    if (style === "tufted") {
      rect(target, colors.ink, cx - 4, cy - ry - 2, 3, 5);
      rect(target, colors.ink, cx + 1, cy - ry - 3, 3, 5);
      rect(target, item.palette.mark, cx - 3, cy - ry, 2, 3);
      rect(target, item.palette.mark, cx + 1, cy - ry - 1, 2, 3);
    } else if (style === "notched" && side > 0) {
      polygon(target, colors.ink, [[cx + rx, cy - 4], [cx + 1, cy - 1], [cx + rx, cy + 1]]);
      rect(target, item.palette.mark, cx + 1, cy + 2, 3, 2);
    } else if (style === "hoops") {
      pixelRoundRect(target, colors.ink, cx - 4, cy + ry - 2, 8, 10, 3);
      pixelRoundRect(target, colors.honey, cx - 3, cy + ry - 1, 6, 8, 2);
      rect(target, colors.ink, cx - 1, cy + ry + 1, 2, 4);
    } else if (style === "gauges") {
      pixelEllipse(target, colors.ink, cx, cy + 1, 5, 5);
      pixelEllipse(target, colors.aqua, cx, cy + 1, 3, 3);
      pixelEllipse(target, colors.ink, cx, cy + 1, 2, 2);
    } else if (style === "tagged" && side > 0) {
      rect(target, colors.ink, cx - 3, cy + 2, 7, 10);
      rect(target, colors.honey, cx - 2, cy + 3, 5, 8);
      rect(target, colors.ink, cx, cy + 4, 1, 2);
      rect(target, colors.ink, cx - 1, cy + 8, 3, 1);
    } else if (style === "earbuds" || (style === "onebud" && side > 0)) {
      pixelRoundRect(target, colors.ink, cx - 3, cy, 7, 7, 2);
      rect(target, colors.bone, cx - 2, cy + 1, 5, 4);
      rect(target, colors.bone, cx, cy + 4, 3, 9);
      rect(target, "#a6b5b2", cx + 1, cy + 10, 2, 2);
    } else if (style === "cuffs") {
      pixelRoundRect(target, colors.ink, cx - 5, cy - 5, 10, 12, 3);
      rect(target, colors.blue, cx - 3, cy - 3, 6, 8);
      rect(target, colors.bone, cx - 2, cy - 2, 2, 6);
    }
  });
}

function iconHeadBase(target, item, headX, headY, headW, headH) {
  const jaw = item.traits.silhouette.jaw;
  const anatomy = spectrumAnatomy(item.balance);
  const coat = item.palette.coat;
  const coatDark = mixHex(coat, colors.ink, 0.22);
  const center = snapEven(headX + headW / 2);
  const rowCount = Math.round(headH);
  const bullFace = anatomy.earMode === "bull";

  // Keep the face broad through the eyes and muzzle. The references read as
  // rounded masks because the silhouette only closes during the final third.
  for (let row = 0; row < rowCount; row += 1) {
    const progress = row / Math.max(1, rowCount - 1);
    const taper = anatomy.lowerFaceTaper;
    const topCurve = bullFace ? [3, 1] : [7, 5, 3, 2, 1];
    const topInset = topCurve[row] ?? 0;
    const lowerProgress = clamp((progress - 0.7) / 0.3, 0, 1);
    const bullLowerInset = progress < 0.6
      ? 0
      : progress < 0.82
        ? 2
        : Math.round(2 + clamp((progress - 0.82) / 0.18, 0, 1) * (3 + taper * 0.25));
    const lowerInset = bullFace
      ? bullLowerInset
      : Math.round(Math.pow(lowerProgress, 1.25) * (5 + taper * 0.45));
    const inset = Math.max(topInset, lowerInset);

    const left = headX + inset;
    const right = headX + headW - inset;
    const y = headY + row;
    rect(target, colors.ink, left, y, right - left, 1);

    if (row === 0 || row === rowCount - 1 || right - left <= 6) continue;
    rect(target, coat, left + 2, y, right - left - 4, 1);
  }

  if (jaw === "soft" && !bullFace) {
    // A subtle cheek swell, not a long diagonal taper.
    pixelEllipse(target, colors.ink, headX, headY + 23, 2, 4);
    pixelEllipse(target, colors.ink, headX + headW - 1, headY + 23, 2, 4);
    pixelEllipse(target, coat, headX, headY + 23, 1, 3);
    pixelEllipse(target, coat, headX + headW - 1, headY + 23, 1, 3);
  } else if (jaw === "cheeks") {
    pixelEllipse(target, colors.ink, headX - 1, headY + 24, 3, 5);
    pixelEllipse(target, colors.ink, headX + headW, headY + 24, 3, 5);
    pixelEllipse(target, coat, headX - 1, headY + 24, 2, 4);
    pixelEllipse(target, coat, headX + headW, headY + 24, 2, 4);
  } else if (jaw === "hammer") {
    pixelEllipse(target, colors.ink, headX - 1, headY + 17, 3, 3);
    pixelEllipse(target, colors.ink, headX + headW, headY + 17, 3, 3);
    pixelEllipse(target, coat, headX - 1, headY + 17, 2, 2);
    pixelEllipse(target, coat, headX + headW, headY + 17, 2, 2);
  } else if (jaw === "long") {
    rect(target, coatDark, headX + 8, headY + headH - 10, headW - 16, 4);
  } else if (jaw === "tiny") {
    rect(target, colors.ink, headX + 6, headY + headH - 8, headW - 12, 6);
    rect(target, coat, headX + 10, headY + headH - 8, headW - 20, 4);
  } else if (jaw === "wedge") {
    rect(target, colors.ink, headX, headY + headH - 8, 4, 8);
    rect(target, colors.ink, headX + headW - 4, headY + headH - 8, 4, 8);
  }

  const neckHeight = Math.max(0, Math.min(8, 64 - (headY + headH)));
  rect(target, colors.ink, center - 4, headY + headH, 8, neckHeight);
  const chin = ["hollow", "possessed"].includes(item.traits.form.value) ? coat : colors.bone;
  rect(target, chin, center - 2, headY + headH, 4, 2);
}

function iconMarking(target, item, headX, headY, headW, headH) {
  if (["possessed", "hollow", "skull"].includes(item.traits.form.value)) return;
  const marking = item.traits.marking.value;
  const center = headX + headW / 2;
  if (marking === "split") {
    rect(target, item.palette.shade, headX + 2, headY + 4, headW / 2 - 2, headH - 10);
  } else if (marking === "blaze") {
    rect(target, item.palette.mark, center - 3, headY + 2, 6, 20);
  } else if (marking === "bars") {
    rect(target, item.palette.shade, headX + 5, headY + 13, 11, 4);
    rect(target, item.palette.shade, headX + headW - 16, headY + 13, 11, 4);
    rect(target, colors.blue, headX + 7, headY + 19, 2, 8);
    rect(target, colors.orange, headX + headW - 9, headY + 19, 2, 6);
  } else if (marking === "freckles") {
    rect(target, item.palette.mark, headX + 6, headY + 26, 2, 2);
    rect(target, item.palette.mark, headX + 10, headY + 28, 2, 2);
    rect(target, item.palette.mark, headX + headW - 10, headY + 26, 2, 2);
  } else if (marking === "checker") {
    rect(target, item.palette.mark, headX + 4, headY + 22, 6, 6);
    rect(target, item.palette.mark, headX + 10, headY + 28, 6, 6);
  } else if (marking === "scar") {
    [[-4, 2], [-2, 6], [0, 10], [2, 14], [4, 18], [6, 22]].forEach(([offset, drop]) => {
      rect(target, colors.orange, center + offset, headY + drop, 2, 5);
    });
  } else if (marking === "halfmud") {
    polygon(target, item.palette.shade, [[headX + 2, headY + 24], [headX + 11, headY + 18], [center - 4, headY + 34], [headX + 4, headY + 36]]);
    polygon(target, item.palette.shade, [[headX + headW - 2, headY + 24], [headX + headW - 11, headY + 18], [center + 4, headY + 34], [headX + headW - 4, headY + 36]]);
  } else if (marking === "eclipse") {
    const socket = item.traits.bearKind.value === "panda" ? colors.bone : colors.ink;
    rect(target, socket, headX + 4, headY + 11, 12, 2);
    rect(target, socket, headX + 2, headY + 13, 16, 8);
    rect(target, socket, headX + 4, headY + 21, 12, 2);
    rect(target, socket, headX + headW - 16, headY + 11, 12, 2);
    rect(target, socket, headX + headW - 18, headY + 13, 16, 8);
    rect(target, socket, headX + headW - 16, headY + 21, 12, 2);
  } else if (marking === "barcode") {
    rect(target, item.palette.shade, center - 8, headY + 4, 4, 14);
    rect(target, item.palette.shade, center - 2, headY + 4, 2, 10);
    rect(target, item.palette.shade, center + 4, headY + 4, 4, 14);
  } else if (marking === "warpaint") {
    [[-9, 3], [-7, 7], [-5, 11], [-3, 15], [-1, 19], [1, 23]].forEach(([offset, drop]) => {
      rect(target, colors.orange, center + offset, headY + drop, 4, 6);
    });
    rect(target, colors.blue, center + 5, headY + 8, 2, 16);
  } else if (marking === "mosaic") {
    rect(target, colors.blue, headX + 4, headY + 10, 8, 4);
    rect(target, colors.blue, headX + 7, headY + 14, 3, 14);
    rect(target, colors.orange, headX + headW - 12, headY + 10, 8, 4);
    rect(target, colors.orange, headX + headW - 10, headY + 14, 3, 10);
    rect(target, item.palette.mark, center - 2, headY + 6, 4, 4);
  }
}

function iconSpecies(target, item, headX, headY, headW) {
  if (["possessed", "hollow", "skull"].includes(item.traits.form.value)) return;
  if (item.balance >= 70) return;
  const kind = item.traits.bearKind.value;
  const center = headX + headW / 2;
  if (kind === "panda") {
    const patches = [headX + 5, headX + headW - 16];
    patches.forEach((x) => {
      rect(target, colors.ink, x + 2, headY + 11, 7, 2);
      rect(target, colors.ink, x, headY + 13, 11, 8);
      rect(target, colors.ink, x + 2, headY + 21, 7, 2);
    });
  } else if (kind === "sun") {
    rect(target, colors.honey, center - 8, headY + 6, 16, 5);
    rect(target, item.palette.coat, center - 3, headY + 6, 6, 2);
  } else if (kind === "spectacled") {
    const patches = [headX + 6, headX + headW - 16];
    patches.forEach((x) => {
      rect(target, colors.bone, x + 2, headY + 11, 6, 2);
      rect(target, colors.bone, x, headY + 13, 10, 6);
      rect(target, colors.bone, x + 2, headY + 19, 6, 2);
      rect(target, item.palette.coat, x + 3, headY + 14, 4, 4);
    });
  } else if (kind === "sloth") {
    rect(target, item.palette.mark, center - 4, headY + 3, 8, 22);
    rect(target, item.palette.shade, center - 2, headY + 8, 4, 8);
  } else if (kind === "grizzly") {
    rect(target, item.palette.shade, center - 4, headY + 4, 8, 2);
    rect(target, item.palette.shade, center - 2, headY + 6, 4, 2);
    rect(target, mixHex(item.palette.coat, colors.bone, 0.12), headX + 4, headY + 14, 2, 6);
  } else if (kind === "black") {
    rect(target, item.palette.mark, headX + 4, headY + 22, 8, 5);
    rect(target, item.palette.mark, headX + headW - 12, headY + 22, 8, 5);
  } else if (kind === "koala") {
    rect(target, item.palette.mark, center - 6, headY + 5, 12, 3);
    rect(target, item.palette.shade, center - 4, headY + 8, 8, 9);
    rect(target, colors.ink, center - 2, headY + 12, 4, 8);
  } else if (kind === "polar") {
    rect(target, mixHex(item.palette.coat, "#9ed9d6", 0.24), center - 5, headY + 5, 10, 2);
  }
}

function iconBullDNA(target, item, headX, headY, headW) {
  if (["possessed", "hollow", "skull"].includes(item.traits.form.value)) return;
  if (item.balance < 40 && item.traits.form.value !== "robot") return;
  const breed = item.traits.bullKind.value;
  const center = headX + headW / 2;
  if (item.balance >= 65) {
    rect(target, item.palette.shade, center - 6, headY + 3, 12, 2);
    rect(target, item.palette.shade, center - 4, headY + 5, 8, 2);
  }
  if (breed === "angus") {
    rect(target, item.palette.shade, center - 6, headY + 10, 4, 2);
    rect(target, item.palette.shade, center + 2, headY + 10, 4, 2);
  } else if (breed === "brahman") {
    rect(target, item.palette.shade, center - 3, headY + 4, 6, 2);
  } else if (breed === "longhorn") {
    rect(target, item.palette.shade, headX + 5, headY + 9, 7, 3);
    rect(target, item.palette.shade, headX + headW - 12, headY + 9, 7, 3);
  } else if (breed === "zebu") {
    rect(target, item.palette.mark, center - 4, headY + 3, 8, 8);
    rect(target, colors.ink, center - 1, headY + 5, 2, 4);
  } else if (breed === "fighting") {
    rect(target, item.palette.shade, headX + 6, headY + 11, 6, 2);
    rect(target, item.palette.shade, headX + headW - 12, headY + 11, 6, 2);
  } else if (breed === "watusi") {
    rect(target, item.palette.mark, center - 2, headY + 3, 4, 10);
  }
}

function iconForm(target, item, headX, headY, headW, headH, f) {
  const form = item.traits.form.value;
  const center = headX + headW / 2;
  if (form === "degen") {
    rect(target, colors.orange, headX + 4, headY + 26, 4, 8);
  } else if (form === "robot") {
    rect(target, item.palette.shade, center - 1, headY + 3, 2, 8);
    rect(target, colors.ink, center - 2, headY - 2, 4, 4);
    rect(target, colors.orange, center - 1, headY - 4 - (f % 2) * 2, 2, 4);
  } else if (form === "zombie") {
    rect(target, colors.ink, headX + headW - 8, headY + 2, 8, 8);
    rect(target, colors.orange, headX + headW - 6, headY + 4, 4, 4);
    rect(target, colors.mud, headX + 4, headY + 10, 6, 6);
  } else if (form === "mad") {
    rect(target, colors.orange, center - 2, headY + 2, 4, 6);
    rect(target, colors.orange, center, headY + 8, 4, 6);
  } else if (form === "skull") {
    rect(target, item.palette.shade, center - 2, headY + 4, 4, 14);
  } else if (form === "hollow") {
    rect(target, colors.ink, headX + 6, headY + 8, headW - 12, 24);
  } else if (form === "possessed") {
    // A compact market sigil gives the rare mask one ceremonial focal point:
    // orange momentum around a blue signal, contained by the collection ink.
    pixelRoundRect(target, colors.ink, center - 4, headY + 3, 8, 7, 2);
    pixelRoundRect(target, colors.orange, center - 2, headY + 4, 4, 4, 1);
    rect(target, colors.blue, center - 1, headY + 5, 2, 2);
    rect(target, colors.blue, center - 1, headY + 8, 2, 3);
  }
}

function iconForelock(target, item, headX, headY, headW) {
  if (!item.traits.bullKind.forelock) return;
  if (item.balance < 40) return;
  if (["robot", "skull", "hollow", "possessed"].includes(item.traits.form.value)) return;
  const center = headX + headW / 2;
  const highland = item.traits.bullKind.value === "highland";
  if (highland) {
    const highlight = mixHex(item.palette.shade, item.palette.coat, 0.28);
    rect(target, item.palette.shade, center - 9, headY + 2, 18, 2);
    [[center - 8, 7], [center - 2, 12], [center + 4, 8]].forEach(([x, height]) => {
      rect(target, item.palette.shade, x, headY + 4, 4, height);
      rect(target, item.palette.shade, x + 1, headY + 4 + height, 2, 2);
      rect(target, highlight, x + 1, headY + 5, 1, Math.max(3, height - 3));
    });
    return;
  }
  rect(target, item.palette.shade, center - 7, headY + 2, 14, 2);
  rect(target, item.palette.shade, center - 5, headY + 4, 10, 2);
  rect(target, item.palette.shade, center - 3, headY + 6, 6, 2);
  rect(target, item.palette.shade, center - 1, headY + 8, 2, 3);
}

function iconHeadwear(target, item, headX, headY, headW, f) {
  const type = item.traits.headwear.value;
  const center = headX + headW / 2;
  if (type === "papercrown") {
    // Folded takeaway-bag crown, not the gold crown's three prongs.
    polygon(target,colors.ink,[[center-10,headY+1],[center-12,headY-8],[center-5,headY-4],[center,headY-10],[center+6,headY-3],[center+10,headY-6],[center+9,headY+1]]);
    polygon(target,'#c99d68',[[center-8,headY],[center-10,headY-5],[center-4,headY-2],[center,headY-7],[center+5,headY-1],[center+8,headY-3],[center+7,headY]]);
    rect(target,colors.bone,center-4,headY-1,7,2);rect(target,colors.ink,center-1,headY-1,1,2);
  } else if (type === "cap") {
    rect(target, colors.ink, center - 12, headY - 4, 24, 8);
    rect(target, colors.mint, center - 10, headY - 4, 18, 6);
    rect(target, colors.mint, center + 8, headY + 2, 8, 2);
  } else if (type === "beanie") {
    rect(target, colors.ink, center - 12, headY - 6, 24, 10);
    rect(target, colors.orange, center - 10, headY - 4, 20, 6);
  } else if (type === "visor") {
    rect(target, colors.ink, headX + 4, headY + 14, headW - 8, 8);
    rect(target, colors.blue, headX + 6, headY + 16, headW - 12, 4);
    rect(target, colors.mint, headX + 8, headY + 17, 5, 2);
    rect(target, colors.orange, headX + headW - 13, headY + 17, 5, 2);
    rect(target, colors.ink, center - 1, headY + 16, 2, 4);
    rect(target, colors.bone, headX + 7 + (f % 4) * 4, headY + 16, 2, 1);
  } else if (type === "grass") {
    rect(target, colors.mint, center - 8, headY - 6, 4, 8);
    rect(target, colors.mint, center - 2, headY - 8, 4, 10);
    rect(target, colors.mint, center + 4, headY - 4, 4, 6);
  } else if (type === "bucket") {
    rect(target, colors.ink, center - 12, headY - 6, 24, 10);
    rect(target, colors.mud, center - 10, headY - 4, 20, 6);
    rect(target, colors.bone, center - 14, headY + 2, 28, 2);
  } else if (type === "foil") {
    rect(target, colors.ink, center - 6, headY - 10, 12, 12);
    rect(target, "#a8c8ca", center - 4, headY - 8, 8, 10);
  } else if (type === "crown") {
    rect(target, colors.ink, center - 12, headY - 8, 24, 12);
    rect(target, colors.honey, center - 10, headY - 6, 4, 8);
    rect(target, colors.honey, center - 2, headY - 8, 4, 10);
    rect(target, colors.honey, center + 6, headY - 6, 4, 8);
  } else if (type === "halo") {
    rect(target, colors.honey, center - 14, headY - 8, 28, 4);
    rect(target, colors.ink, center - 8, headY - 7, 16, 2);
  } else if (type === "tiny") {
    rect(target, colors.ink, center - 6, headY - 8, 12, 10);
    rect(target, colors.orange, center - 4, headY - 6, 8, 6);
  }
}

function iconEyes(target, item, headX, headY, headW, blink) {
  const form = item.traits.form.value;
  const kind = item.traits.eyes.value;
  const layout = item.traits.faceLayout;
  const anatomy = spectrumAnatomy(item.balance);
  const bullEyeSpread = anatomy.earMode === "bull" ? 2 : anatomy.earMode === "hybrid" ? 1 : 0;
  const bullEyeLift = anatomy.earMode === "bull" ? 2 : 0;
  const left = snapEven(headX + 10 - layout.spread / 2 - bullEyeSpread);
  const right = snapEven(headX + headW - 16 + layout.spread / 2 + bullEyeSpread);
  const leftY = snapEven(headY + 15 + layout.y - bullEyeLift);
  const rightY = snapEven(leftY + layout.skew);

  if (item.traits.headwear.value === "visor") return;

  if (['prerevenue','pricedin'].includes(kind)) {
    [[left,leftY],[right,rightY]].forEach(([x,y],i)=>{
      if(kind==='prerevenue'){
        const size=i?4:8;rect(target,colors.ink,x-1,y-1,size+2,size+2);rect(target,colors.bone,x,y,size,size);rect(target,colors.ink,x+(i?0:5),y+2,2,3);
      } else {
        rect(target,colors.ink,x-1,y+1,8,5);rect(target,colors.bone,x,y+3,6,2);rect(target,colors.ink,x+4,y+2,2,3);
        rect(target,colors.ink,x-1,y-3+(i?2:0),7,1);
      }
      if(blink)rect(target,colors.ink,x,y+2,6,3);
    });return;
  }
  if (["buffering", "deadpan", "intern"].includes(kind)) {
    [[left,leftY],[right,rightY]].forEach(([x,y],i)=>{
      rect(target,colors.ink,x-1,y,8,7);
      rect(target,colors.bone,x,y+1,6,5);
      const pupil = kind === 'buffering' ? (i ? 4 : 0) : kind === 'intern' ? (i ? 0 : 4) : 2;
      rect(target,colors.ink,x+pupil,y+2,2,3);
      if(kind === 'deadpan')rect(target,item.palette.coat,x-1,y,8,4);
      if(kind === 'intern')rect(target,colors.ink,x-1,y-3+(i?2:0),8,1);
      if(blink)rect(target,colors.ink,x,y+2,6,3);
    });
    return;
  }
  if (["halfmoon", "cross", "star", "odd", "monocle", "goggles", "lashes"].includes(kind)) {
    const eyes = [[left, leftY], [right, rightY]];
    eyes.forEach(([x, y], index) => {
      const iris = kind === "odd" ? (index === 0 ? colors.aqua : colors.orange) : colors.bone;
      pixelRoundRect(target, colors.ink, x - 1, y - 1, 8, 8, 2);
      if (kind === "halfmoon") {
        rect(target, colors.bone, x, y + 3, 6, 2);
        rect(target, colors.ink, x + (index ? 1 : 3), y + 2, 2, 3);
      } else if (kind === "cross") {
        rect(target, colors.bone, x, y + 1, 6, 4);
        rect(target, colors.ink, x + (index ? 0 : 4), y + 1, 2, 4);
      } else if (kind === "star") {
        rect(target, colors.honey, x + 2, y, 2, 6);
        rect(target, colors.honey, x, y + 2, 6, 2);
      } else if (kind === "goggles") {
        pixelRoundRect(target, colors.bone, x - 2, y - 2, 10, 9, 2);
        rect(target, colors.ink, x, y, 6, 5);
        rect(target, colors.aqua, x, y + 1, 6, 2);
        rect(target, colors.bone, x + 1, y, 1, 2);
      } else {
        rect(target, iris, x + 1, y + 1, 4, 4);
        rect(target, colors.ink, x + 3, y + 2, 2, 3);
      }
      if (kind === "lashes") {
        rect(target, colors.ink, x - 2, y - 3, 2, 3);
        rect(target, colors.ink, x + 2, y - 4, 2, 4);
        rect(target, colors.ink, x + 6, y - 3, 2, 3);
      }
      if (blink && kind !== "goggles") rect(target, colors.ink, x, y + 1, 6, 4);
    });
    if (kind === "goggles") rect(target, colors.bone, left + 7, leftY, Math.max(1, right - left - 9), 2);
    if (kind === "monocle") {
      rect(target, colors.honey, left - 2, leftY - 2, 10, 1);
      rect(target, colors.honey, left - 2, leftY + 7, 10, 1);
      rect(target, colors.honey, left - 2, leftY - 1, 1, 8);
      rect(target, colors.honey, left + 7, leftY - 1, 1, 8);
      rect(target, colors.honey, left - 3, leftY + 7, 1, 8);
    }
    return;
  }

  if (form === "skull") {
    pixelEllipse(target, colors.ink, left + 3, leftY + 3, 4, 4);
    pixelEllipse(target, colors.ink, right + 3, rightY + 3, 4, 4);
    return;
  }
  if (form === "hollow") {
    rect(target, colors.blue, left, leftY, 4, 4);
    rect(target, colors.orange, right + 2, rightY, 4, 4);
    return;
  }
  if (form === "possessed") {
    const glow = "#69d58d";
    const glowLight = "#c9ebc7";
    rect(target, colors.ink, left - 1, leftY, 8, 4);
    rect(target, colors.ink, right - 1, rightY, 8, 4);
    rect(target, glow, left, leftY + 1, 6, 2);
    rect(target, glow, right, rightY + 1, 6, 2);
    rect(target, glowLight, left + 2, leftY + 1, 2, 2);
    rect(target, glowLight, right + 2, rightY + 1, 2, 2);
    return;
  }
  if (form === "robot") {
    pixelRoundRect(target, colors.ink, left, leftY, 6, 6, 2);
    pixelRoundRect(target, colors.ink, right, rightY, 6, 6, 2);
    rect(target, colors.bone, left + 2, leftY + 2, 2, 2);
    rect(target, colors.bone, right + 2, rightY + 2, 2, 2);
    rect(target, colors.orange, left - 2, leftY + 4, 2, 2);
    rect(target, colors.blue, right + 6, rightY + 4, 2, 2);
    return;
  }
  if (form === "zombie") {
    rect(target, colors.ink, left, leftY, 6, 6);
    rect(target, colors.orange, left + 2, leftY + 2, 2, 2);
    rect(target, colors.ink, right, rightY + 1, 6, 4);
    return;
  }
  if (form === "mad") {
    rect(target, colors.ink, left, leftY - 2, 8, 8);
    rect(target, colors.orange, left + 2, leftY, 4, 4);
    rect(target, colors.ink, right, rightY + 2, 8, 4);
    return;
  }
  if (kind === "drowsy") {
    rect(target, colors.ink, left - 1, leftY, 8, 4);
    rect(target, colors.ink, right - 1, rightY, 8, 4);
    rect(target, colors.bone, left + 1, leftY + 2, 3, 2);
    rect(target, colors.bone, right + 2, rightY + 2, 3, 2);
    return;
  }
  if (kind === "shades") {
    const lens = mixHex(colors.blue, colors.ink, 0.34);
    rect(target, colors.ink, left - 1, leftY, 8, 6);
    rect(target, colors.ink, right - 1, rightY, 8, 6);
    rect(target, colors.ink, left + 6, leftY + 2, Math.max(2, right - left - 6), 2);
    rect(target, lens, left + 1, leftY + 2, 4, 2);
    rect(target, lens, right + 1, rightY + 2, 4, 2);
    rect(target, colors.bone, left + 1, leftY + 1, 2, 2);
    rect(target, colors.bone, right + 1, rightY + 1, 2, 2);
    return;
  }
  const closed = blink;
  // A heavy upper lid and off-centre glint survive the small avatar crop.
  pixelRoundRect(target, colors.ink, left - 1, leftY, 7, 6, 2);
  pixelRoundRect(target, colors.ink, right - 1, rightY, 7, 6, 2);
  const pupil = kind === "green" ? colors.mint : ["red", "laser"].includes(kind) ? colors.orange : colors.bone;
  const offset = kind === "side" ? 0 : 2;
  const pupilOffset = closed ? 2 : Math.min(offset, 2);
  rect(target, pupil, left + pupilOffset, leftY + (closed ? 3 : 2), 2, closed ? 1 : 2);
  rect(target, pupil, right + pupilOffset, rightY + (closed ? 3 : 2), 2, closed ? 1 : 2);
  if (kind === "laser") {
    rect(target, colors.orange, left - 2, leftY + 2, 2, 2);
    rect(target, colors.orange, right + 6, rightY + 2, 2, 2);
  }
  if (kind === "third") {
    const center = headX + headW / 2;
    rect(target, colors.ink, center - 6, headY + 5, 12, 2);
    rect(target, colors.ink, center - 8, headY + 7, 16, 6);
    rect(target, colors.ink, center - 6, headY + 13, 12, 2);
    rect(target, colors.orange, center - 5, headY + 7, 10, 6);
    rect(target, colors.honey, center - 1, headY + 8, 2, 4);
  }
  if (kind === "void") {
    pixelEllipse(target, colors.ink, left + 3, leftY + 3, 4, 4);
    pixelEllipse(target, colors.ink, right + 3, rightY + 3, 4, 4);
  }
}

function iconSeptum(target, septum, center, ringY) {
  if (septum === "ring") {
    rect(target, colors.honey, center - 5, ringY, 2, 5);
    rect(target, colors.honey, center + 3, ringY, 2, 5);
    rect(target, colors.honey, center - 4, ringY + 4, 2, 2);
    rect(target, colors.honey, center - 3, ringY + 5, 6, 2);
    rect(target, colors.honey, center + 2, ringY + 4, 2, 2);
  } else if (septum === "studs") {
    rect(target, colors.honey, center - 6, ringY + 1, 3, 3);
    rect(target, colors.honey, center + 3, ringY + 1, 3, 3);
  }
}

function iconMuzzle(target, item, headX, headY, headW, active) {
  const center = snapEven(headX + headW / 2);
  const muzzle = item.traits.muzzle;
  const anatomy = spectrumAnatomy(item.balance);
  const form = item.traits.form.value;
  const robot = form === "robot";
  const bovine = anatomy.earMode === "bull";
  // The muzzle is a squat plush plaque, not a tall tunnel. Its width carries
  // bull weight while the compressed height keeps every face toy-like.
  const width = snapEven(clamp(anatomy.muzzleWidth + muzzle.width / 2 + 6 + (robot ? 2 : 0) + (bovine ? 2 : 0), 24, 32));
  const height = snapEven(clamp(anatomy.muzzleHeight + muzzle.height / 2 - 4, 14, 16));
  const x = center - width / 2;
  const y = snapEven(headY + 22 + anatomy.bullness * 2 + muzzle.y / 2);
  const ringY = y + 6;
  if (form === "skull") {
    rect(target, colors.ink, center - 4, y + 2, 8, 6);
    rect(target, colors.bone, x + 4, y + 10, width - 8, 8);
    rect(target, colors.ink, x + 4, y + 10, 2, 4);
    rect(target, colors.ink, x + width - 6, y + 10, 2, 4);
    rect(target, colors.ink, center - 1, y + 10, 2, 8);
    rect(target, colors.ink, x + 8, y + 16, 2, 4);
    rect(target, colors.ink, x + width - 10, y + 16, 2, 4);
    return;
  }
  if (["hollow", "possessed"].includes(form)) {
    const rareNoseW = bovine ? 14 : 12;
    pixelRoundRect(target, colors.ink, center - rareNoseW / 2, y + 2, rareNoseW, 10, bovine ? 2 : 3);
    if (form === "possessed") rect(target, mixHex(colors.ink, colors.bone, 0.18), center - 3, y + 3, 6, 1);
    iconSeptum(target, item.traits.septum.value, center, ringY);
    return;
  }
  const muzzleFill = bovine ? mixHex(item.palette.coat, colors.bone, 0.72) : colors.bone;
  pixelRoundRect(target, colors.ink, x, y - 2, width, height + 2, bovine ? 3 : 5);
  pixelRoundRect(target, muzzleFill, x + 2, y, width - 4, height - 2, bovine ? 2 : 3);

  if (muzzle.value === "split") rect(target, item.palette.shade, center - 1, y, 2, height);
  if (muzzle.value === "droop") {
    rect(target, item.palette.shade, x + 2, y + height - 4, 4, 4);
    rect(target, item.palette.shade, x + width - 6, y + height - 4, 4, 4);
  }

  const koala = item.traits.bearKind.value === "koala" && item.balance < 45;
  const button = muzzle.value === "button" && item.balance < 45;
  const noseW = koala ? 10 : snapEven(clamp(14 + anatomy.bullness * 4 + (muzzle.value === "hammer" ? 2 : 0) - (button ? 4 : 0), 10, 20));
  const noseH = koala ? 10 : button ? 8 : 6;
  pixelRoundRect(target, colors.ink, center - noseW / 2, y + 2, noseW, noseH, bovine ? 2 : 3);
  if (!robot && form !== "zombie") rect(target, mixHex(colors.ink, colors.bone, 0.18), center - 2, y + 3, 4, 1);
  if (bovine) {
    const nostril = mixHex(colors.ink, colors.bone, 0.18);
    rect(target, nostril, center - noseW / 2 + 2, y + 5, 2, 2);
    rect(target, nostril, center + noseW / 2 - 4, y + 5, 2, 2);
  }

  iconSeptum(target, item.traits.septum.value, center, ringY);

  const mouthY = y + height - 2;
  rect(target, colors.ink, center - 2, mouthY, 4, active ? 4 : 2);
  const mouth = item.traits.mouth.value;
  if (mouth === "grass") {
    rect(target, colors.mint, center + 2, mouthY, 12, 2);
    rect(target, colors.mint, center + 10, mouthY - 4, 2, 6);
  } else if (mouth === "tongue") {
    rect(target, colors.ink, center - 4, mouthY, 8, 10);
    rect(target, colors.coral, center - 2, mouthY + 2, 4, 8);
    rect(target, "#ff9a88", center, mouthY + 3, 2, 5);
  } else if (mouth === "tooth") {
    rect(target, colors.honey, center + 2, mouthY, 4, 4);
  } else if (mouth === "gum") {
    rect(target, "#e76fab", center + 4, mouthY - 4, 8, 8);
  } else if (mouth === "cigar") {
    rect(target, colors.mud, center + 2, mouthY, 12, 4);
    rect(target, colors.orange, center + 12, mouthY, 2, 4);
  } else if (mouth === "drool") {
    rect(target, colors.blue, center + 2, mouthY + 2, 4, 8);
  } else if (mouth === "portal") {
    rect(target, colors.orange, center - 2, mouthY, 4, 6);
  }

  if (form === "skull") {
    rect(target, colors.ink, x + 4, y + height - 4, 4, 4);
    rect(target, colors.ink, x + width - 8, y + height - 4, 4, 4);
  } else if (form === "robot") {
    rect(target, item.palette.shade, x + 4, y + height - 4, width - 8, 2);
  } else if (form === "zombie") {
    rect(target, colors.mint, x + width - 6, y + height - 2, 4, 6);
  } else if (form === "possessed") {
    rect(target, colors.blue, x + 6, y + height - 4, width - 12, 2);
  }
}

function iconMarketTicks(target, item, headX, headY, headW) {
  // The orange/blue market signature belongs to living faces. Robot, zombie,
  // skull, hollow, and possessed forms spend those colors in their anatomy.
  if (!["normie", "degen", "mad"].includes(item.traits.form.value)) return;
  rect(target, colors.orange, headX + 7, headY + 27, 2, 4);
  rect(target, colors.blue, headX + headW - 9, headY + 27, 2, 4);
}

function iconKeepsake(target,item,breathe) {
 const kind=item.traits.neck.value;
 if(!['laptop','phone','petcactus','gpu','espresso','pager','esc','banana'].includes(kind))return;
 const y=49+breathe;
 if(kind==='gpu') {
  rect(target,colors.ink,16,y+2,33,11);rect(target,'#50665b',18,y+3,29,8);
  [25,39].forEach(x=>{pixelEllipse(target,colors.ink,x,y+7,5,4);rect(target,'#9aad91',x-2,y+6,5,2);rect(target,'#9aad91',x,y+4,1,6);rect(target,colors.ink,x,y+7,1,1);});
  rect(target,colors.honey,20,y+11,19,2);rect(target,item.palette.mark,13,y+7,5,5);rect(target,item.palette.mark,47,y+7,5,5);
 } else if(kind==='espresso') {
  rect(target,colors.ink,42,y+1,13,11);rect(target,colors.bone,43,y+2,10,8);
  rect(target,colors.ink,54,y+3,5,6);rect(target,colors.bone,54,y+4,3,3);
  rect(target,colors.mud,44,y+2,8,2);rect(target,colors.bone,45,y-3,1,3);rect(target,colors.bone,49,y-5,1,4);
  rect(target,colors.ink,40,y+12,18,2);rect(target,item.palette.mark,38,y+8,5,4);
 } else if(kind==='pager') {
  rect(target,colors.ink,41,y,16,13);rect(target,'#687f76',43,y+2,12,8);
  rect(target,'#d4dda3',44,y+3,9,4);rect(target,colors.ink,46,y+4,1,2);rect(target,colors.ink,50,y+4,1,2);
  rect(target,colors.orange,50,y+9,3,2);rect(target,item.palette.mark,39,y+7,5,5);
 } else if(kind==='esc') {
  rect(target,colors.ink,17,y+1,29,13);rect(target,'#afb9ad',19,y+2,25,10);rect(target,colors.bone,20,y+3,23,8);
  // Three 3x5 glyphs remain legible at icon scale.
  const letters=['111100110100111','111100111001111','111100100100111'];
  letters.forEach((glyph,i)=>[...glyph].forEach((v,j)=>{if(v==='1')rect(target,colors.ink,24+i*5+j%3,y+5+Math.floor(j/3),1,1);}));
  rect(target,item.palette.mark,14,y+8,5,4);rect(target,item.palette.mark,44,y+8,5,4);
 } else if(kind==='banana') {
  polygon(target,colors.ink,[[42,y-6],[47,y-5],[48,y+2],[45,y+10],[39,y+13],[36,y+9],[40,y+4],[42,y]]);
  polygon(target,colors.honey,[[43,y-4],[46,y-3],[46,y+3],[43,y+9],[39,y+11],[39,y+8],[42,y+4]]);
  rect(target,colors.mud,43,y-7,3,3);rect(target,item.palette.mark,43,y+7,6,5);
 } else if(kind==='laptop') {
  rect(target,colors.ink,17,y,30,14);rect(target,'#b4c1bd',19,y+1,26,11);
  rect(target,'#e1e5d6',20,y+2,24,1);rect(target,colors.ink,14,y+12,36,3);
  rect(target,'#d9dfd4',15,y+12,34,1);rect(target,colors.ink,30,y+5,4,3);
  rect(target,item.palette.mark,14,y+8,5,4);rect(target,item.palette.mark,45,y+8,5,4);
 } else if(kind==='phone') {
  rect(target,colors.ink,42,y-7,12,22);rect(target,'#aebfb8',43,y-6,10,19);
  rect(target,colors.ink,44,y-5,3,3);rect(target,colors.ink,48,y-5,3,3);rect(target,colors.ink,44,y-1,3,3);
  rect(target,'#dce5d5',48,y+1,2,2);rect(target,item.palette.mark,40,y+6,5,6);
 } else {
  rect(target,colors.ink,40,y+6,15,9);rect(target,colors.orange,42,y+7,11,7);
  rect(target,'#4a8064',46,y-6,4,13);rect(target,'#4a8064',42,y-2,5,3);rect(target,'#4a8064',41,y-6,2,7);
  rect(target,'#b9d697',47,y-4,1,9);rect(target,colors.coral,46,y-8,4,2);
  rect(target,item.palette.mark,38,y+8,5,4);
 }
}

function renderBearBull(target, item, f = 0, active = false, sceneOverride = null) {
  if (reducedMotion) { f = 0; active = false; }
  target.imageSmoothingEnabled = false;
  iconBackdrop(target, item, f, sceneOverride);
  iconRarityAtmosphere(target, item, f);
  iconWeather(target, item, f);
  iconAura(target, item, f);
  iconFormAura(target, item, f);
  const anatomy = spectrumAnatomy(item.balance);
  const pace = Math.max(4, 11 - item.personality.energy);
  const breathing = reducedMotion ? 0 : Math.floor((f + item.phase) / pace) % 2;
  const reactionPower = item.traits.form.value === "mad" ? 4 : 2;
  const reaction = active ? (f % 2 ? -reactionPower : reactionPower) : 0;
  iconShoulders(target, item, breathing);

  const silhouette = item.traits.silhouette;
  let headW = snapEven(clamp(anatomy.headWidth + silhouette.width / 4, 38, 42));
  if (item.traits.form.value === "skull") headW = Math.max(36, headW - 4);
  const headH = snapEven(clamp(anatomy.headHeight - 2 + silhouette.height / 4, 38, 42));
  const headX = snapEven((64 - headW) / 2) + reaction;
  const headY = snapEven(15 - (headH - 40) / 4) + breathing;
  iconHorns(target, item, headX, headY, headW);
  iconEars(target, item, headX, headY, headW);
  iconHeadBase(target, item, headX, headY, headW, headH);
  iconMarking(target, item, headX, headY, headW, headH);
  iconSpecies(target, item, headX, headY, headW);
  iconBullDNA(target, item, headX, headY, headW);
  iconForm(target, item, headX, headY, headW, headH, f);
  iconHornRoots(target, item, headX, headY, headW);
  iconMarketTicks(target, item, headX, headY, headW);
  iconForelock(target, item, headX, headY, headW);
  iconHeadwear(target, item, headX, headY, headW, f);
  const blink = !reducedMotion && (f + item.phase) % item.cadence === 0;
  iconEyes(target, item, headX, headY, headW, blink);
  iconMuzzle(target, item, headX, headY, headW, active);
  iconKeepsake(target, item, breathing);
}

function updatePanel() {
  updateCollector();
  const bull = specimen.balance;
  const bear = 100 - bull;
  const viewedBackdrop = currentBackdrop();
  els.id.textContent = `BB—${String(specimen.id).padStart(4, "0")}`;
  els.name.textContent = specimen.name.toUpperCase();
  els.rarity.textContent = specimen.rarity;
  els.points.textContent = `${specimen.points} RP`;
  els.bearPercent.textContent = `${bear}%`;
  els.bullPercent.textContent = `${bull}%`;
  els.spectrumValue.textContent = specimen.genotype.label.toUpperCase();
  els.spectrum.style.setProperty("--bear-share", `${bear}%`);
  els.spectrum.style.setProperty("--bull-share", `${bull}%`);
  els.spectrum.setAttribute("aria-valuenow", String(bull));
  els.spectrum.setAttribute("aria-valuetext", `${bear}% Bear, ${bull}% Bull`);
  els.ticker.textContent = `${100 - bull} / ${bull}`;
  els.personality.textContent = specimen.personality.title.toUpperCase();
  els.habit.textContent = `“${specimen.personality.habit} ${specimen.personality.weakness}”`;
  els.conviction.textContent = specimen.personality.conviction;
  els.tokenInput.value = String(specimen.id).padStart(4, "0");
  const traits = [
    ["FORM", specimen.traits.form.label],
    ["BEAR DNA", specimen.traits.bearKind.label],
    ["BULL DNA", specimen.traits.bullKind.label],
    ["GENOTYPE", specimen.genotype.label],
    ["SILHOUETTE", specimen.traits.silhouette.label],
    ["FACE LAYOUT", specimen.traits.faceLayout.label],
    ["MUZZLE", specimen.traits.muzzle.label],
    ["SEPTUM", specimen.traits.septum.label],
    ["MARKING", specimen.traits.marking.label],
    ["COAT", specimen.traits.coat.label],
    ["HORNS", hornExpressionFor(specimen)],
    ["EYES", specimen.traits.eyes.label],
    ["EARS", specimen.traits.ears.label],
    ["HEAD", specimen.traits.headwear.label],
    ["MOUTH", specimen.traits.mouth.label],
    ["OUTFIT", specimen.traits.outfit.label],
    ["ARTIFACT", specimen.traits.neck.label],
    ["POSE", specimen.traits.pose.label],
    ["AURA", specimen.traits.aura.label],
    ["HABITAT", specimen.traits.backdrop.label],
    ["VIEW BG", viewedBackdrop.label],
    ["BG RARITY", `${specimen.rarity} ATMOSPHERE`],
    ["BG LOOP", habitatMotion[viewedBackdrop.value]],
    ["WEATHER", specimen.traits.weather.label],
    ["VOICE", specimen.traits.voice.label],
    ["GLYPH", specimen.tokenGlyph.code]
  ];
  els.traitList.replaceChildren(...traits.map(([key, value]) => {
    const row = document.createElement("div");
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = key;
    dd.textContent = value;
    row.append(dt, dd);
    return row;
  }));
  updateBackgroundControl();
  if (soundOn) els.soundNote.textContent = `${specimen.traits.voice.label} is awake. Click the portrait or press Space.`;
}

function updateBackgroundControl() {
  const viewedBackdrop = currentBackdrop();
  els.background.textContent = `SCENE ${String(backgroundViewIndex + 1).padStart(2, "0")}/${habitatSystem.length} `;
  const key = document.createElement("kbd");
  key.textContent = "B";
  els.background.append(key);
  els.background.setAttribute("aria-label", `Current background: ${viewedBackdrop.label}. Show next background`);
  els.background.title = viewedBackdrop.label;
  els.habitatRack.querySelectorAll("[data-scene]").forEach(button => {
    button.setAttribute("aria-pressed", String(button.dataset.scene === viewedBackdrop.value));
  });
}

function cycleBackground() {
  backgroundViewIndex = (backgroundViewIndex + 1) % habitatSystem.length;
  updatePanel();
  renderBearBull(ctx, specimen, frame, false, currentBackdrop().value);
}

function loadSpecimen(tokenId) {
  const id = normalizeTokenId(tokenId);
  specimen = collection[id];
  history.replaceState(null, "", specimenUrl());
  if (explorer.status) explorer.status.textContent = "Favourites stay in this browser. No wallet needed.";
  backgroundViewIndex = habitatByValue[specimen.traits.backdrop.value].index;
  updatePanel();
  renderBearBull(ctx, specimen, frame, false, currentBackdrop().value);
}

function randomTokenId() {
  if (globalThis.crypto?.getRandomValues) {
    const value = new Uint32Array(1);
    globalThis.crypto.getRandomValues(value);
    return value[0] % COLLECTION_SIZE;
  }
  return Math.floor(Math.random() * COLLECTION_SIZE);
}

function setSound(next) {
  soundOn = next;
  els.sound.textContent = `${next ? "SOUND ON" : "SOUND OFF"} `;
  const key = document.createElement("kbd");
  key.textContent = "M";
  els.sound.append(key);
  els.sound.setAttribute("aria-pressed", String(next));
  els.soundNote.textContent = next ? `${specimen.traits.voice.label} is awake. Click the portrait or press Space.` : "Sound sleeps until you wake it.";
}

function audio() {
  if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  if (audioContext.state === "suspended") audioContext.resume();
  return audioContext;
}

function breathBurst(context, destination, start, duration, gain, frequency, seed) {
  const length = Math.max(1, Math.floor(context.sampleRate * duration));
  const buffer = context.createBuffer(1, length, context.sampleRate);
  const data = buffer.getChannelData(0);
  let state = (seed || 1) >>> 0;
  for (let index = 0; index < length; index += 1) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    data[index] = (state / 0xffffffff) * 2 - 1;
  }
  const source = context.createBufferSource();
  const filter = context.createBiquadFilter();
  const envelope = context.createGain();
  source.buffer = buffer;
  filter.type = "bandpass";
  filter.frequency.setValueAtTime(frequency, start);
  filter.Q.setValueAtTime(1.4, start);
  envelope.gain.setValueAtTime(0.0001, start);
  envelope.gain.exponentialRampToValueAtTime(gain, start + Math.min(0.025, duration * 0.2));
  envelope.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  source.connect(filter).connect(envelope).connect(destination);
  source.start(start);
  source.stop(start + duration + 0.01);
}

function softClipCurve(amount = 1.8) {
  const curve = new Float32Array(2048);
  for (let index = 0; index < curve.length; index += 1) {
    const x = index * 2 / (curve.length - 1) - 1;
    curve[index] = Math.tanh(x * amount) / Math.tanh(amount);
  }
  return curve;
}

function animalCall(context, start, item) {
  const profiles = {
    grunt: { duration: 0.72, pitch: 0.95, mid: 0.9, end: 0.74, wobble: 3.2, depth: 0.15, breath: 0.045 },
    snort: { duration: 0.56, pitch: 1.12, mid: 0.88, end: 0.7, wobble: 7.2, depth: 0.2, breath: 0.15 },
    click: { duration: 0.5, pitch: 1.42, mid: 1.14, end: 0.92, wobble: 8.6, depth: 0.14, breath: 0.09 },
    pop: { duration: 0.92, pitch: 1.16, hook: [1, 1.26, 1.5, 1.22], wobble: 5.8, depth: 0.18, breath: 0.045 },
    rumble: { duration: 1.05, pitch: 0.78, mid: 0.9, end: 0.68, wobble: 2.4, depth: 0.21, breath: 0.035 },
    chirp: { duration: 0.86, pitch: 1.38, hook: [1, 1.34, 1.68, 1.26], wobble: 6.8, depth: 0.15, breath: 0.04 },
    yodel: { duration: 1.08, pitch: 1.02, hook: [1, 1.5, 1.16, 1.64], wobble: 4.1, depth: 0.17, breath: 0.035 },
    moo: { duration: 1.24, pitch: 0.84, mid: 0.98, end: 0.8, wobble: 2.1, depth: 0.19, breath: 0.055 },
    bell: { duration: 1.02, pitch: 1.08, hook: [1, 1.5, 1.25, 1.76], wobble: 3.5, depth: 0.14, breath: 0.025 },
    glitch: { duration: 0.9, pitch: 0.96, hook: [0.72, 0.9, 1.22, 1.72], wobble: 10.5, depth: 0.23, breath: 0.065, pullup: true }
  };
  const voice = item.traits.voice.value;
  const profile = profiles[voice] ?? profiles.grunt;
  const bull = item.balance / 100;
  const bear = 1 - bull;
  const form = item.traits.form.value;
  const formDuration = form === "hollow" ? 0.18 : form === "mad" ? -0.08 : 0;
  const duration = profile.duration + bull * 0.14 + formDuration;
  const stop = start + duration;
  const fundamental = (82 + bull * 20 + item.personality.energy * 3.2) * profile.pitch;
  const formPitch = form === "zombie" ? 0.84 : form === "mad" ? 1.08 : form === "skull" ? 1.04 : 1;
  const startPitch = Math.max(24, fundamental * formPitch);
  const middlePitch = Math.max(22, startPitch * profile.mid * (0.96 + bull * 0.08));
  const endPitch = Math.max(20, startPitch * profile.end * (0.92 + bull * 0.14));

  const master = context.createGain();
  const output = context.createDynamicsCompressor();
  const body = context.createGain();
  const formantGain = context.createGain();
  const saturator = context.createWaveShaper();
  const lowpass = context.createBiquadFilter();
  const formant = context.createBiquadFilter();
  const wobbleGain = context.createGain();
  const wobble = context.createOscillator();
  const wobbleDepth = context.createGain();
  const vowelSweep = context.createGain();
  const detuneDepth = context.createGain();

  saturator.curve = softClipCurve(form === "robot" ? 2.25 : 1.65 + bear * 0.45);
  saturator.oversample = "2x";
  lowpass.type = "lowpass";
  lowpass.frequency.setValueAtTime(1180 + bull * 420, start);
  lowpass.Q.setValueAtTime(3.8 + bear * 2.1, start);
  formant.type = "bandpass";
  formant.frequency.setValueAtTime(620 + bull * 430, start);
  formant.Q.setValueAtTime(5.5 + (voice === "yodel" ? 3 : 0), start);
  body.gain.setValueAtTime(0.82, start);
  formantGain.gain.setValueAtTime(0.23 + bull * 0.1, start);
  wobbleGain.gain.setValueAtTime(0.78, start);
  master.gain.setValueAtTime(0.0001, start);
  master.gain.exponentialRampToValueAtTime(0.092 + bear * 0.012, start + Math.min(0.06, duration * 0.15));
  master.gain.setValueAtTime(0.092 + bear * 0.012, stop - Math.min(0.18, duration * 0.24));
  master.gain.exponentialRampToValueAtTime(0.0001, stop);
  output.threshold.setValueAtTime(-18, start);
  output.knee.setValueAtTime(18, start);
  output.ratio.setValueAtTime(3, start);
  output.attack.setValueAtTime(0.003, start);
  output.release.setValueAtTime(0.18, start);

  if (profile.pullup) {
    lowpass.frequency.exponentialRampToValueAtTime(2800, stop);
    formant.frequency.exponentialRampToValueAtTime(1650, stop);
  }
  if (profile.hook) {
    profile.hook.slice(1).forEach((_, index) => {
      const boundary = start + duration * ((index + 1) / (profile.hook.length - 1));
      body.gain.setValueAtTime(0.64, Math.max(start, boundary - 0.028));
      body.gain.linearRampToValueAtTime(0.86, Math.min(stop, boundary + 0.018));
    });
  }

  saturator.connect(lowpass).connect(body).connect(wobbleGain).connect(master);
  saturator.connect(formant).connect(formantGain).connect(master);
  master.connect(output).connect(context.destination);

  wobble.type = "sine";
  wobble.frequency.setValueAtTime(profile.wobble + item.personality.energy * 0.18, start);
  if (form === "robot") wobble.frequency.linearRampToValueAtTime(profile.wobble * 1.35, stop);
  wobbleDepth.gain.setValueAtTime(profile.depth + (form === "mad" ? 0.08 : 0), start);
  vowelSweep.gain.setValueAtTime(180 + profile.depth * 620 + bull * 120, start);
  detuneDepth.gain.setValueAtTime(7 + bear * 9 + (form === "possessed" ? 10 : 0), start);
  wobble.connect(wobbleDepth).connect(wobbleGain.gain);
  wobble.connect(vowelSweep).connect(formant.frequency);

  const carriers = [
    { type: "triangle", multiple: 1, gain: 0.76 },
    { type: "sine", multiple: 0.5, gain: 0.2 + bear * 0.06 },
    { type: "sawtooth", multiple: 2, gain: 0.07 + bull * 0.035 }
  ];
  wobble.connect(detuneDepth);
  carriers.forEach(({ type, multiple, gain }) => {
    const oscillator = context.createOscillator();
    const level = context.createGain();
    oscillator.type = type;
    if (profile.hook) {
      oscillator.frequency.setValueAtTime(Math.max(20, startPitch * multiple * profile.hook[0]), start);
      profile.hook.slice(1).forEach((ratio, index) => {
        const noteTime = start + duration * ((index + 1) / (profile.hook.length - 1));
        oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, startPitch * multiple * ratio), noteTime);
      });
    } else {
      oscillator.frequency.setValueAtTime(Math.max(20, startPitch * multiple), start);
      oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, middlePitch * multiple), start + duration * 0.43);
      oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, endPitch * multiple), stop);
    }
    level.gain.setValueAtTime(gain, start);
    detuneDepth.connect(oscillator.detune);
    oscillator.connect(level).connect(saturator);
    oscillator.start(start);
    oscillator.stop(stop + 0.04);
  });

  const breathGain = profile.breath * (0.72 + bear * 0.45 + (form === "skull" ? 0.5 : 0));
  breathBurst(context, master, start + 0.012, Math.min(0.24, duration * 0.34), breathGain, 780 + bull * 620, item.id + 1);
  wobble.start(start);
  wobble.stop(stop + 0.04);
  return duration;
}

function playVoice() {
  if (!soundOn) setSound(true);
  const context = audio();
  const duration = animalCall(context, context.currentTime + 0.025, specimen);
  reactingUntil = performance.now() + duration * 1000;
}

function savePng() {
  renderBearBull(ctx, specimen, 0, false, currentBackdrop().value);
  const output = document.createElement("canvas");
  output.width = 512; output.height = 512;
  const outputContext = output.getContext("2d");
  outputContext.imageSmoothingEnabled = false;
  outputContext.drawImage(canvas, 0, 0, 512, 512);
  output.toBlob((blob) => {
    if (!blob) return;
    const link = document.createElement("a");
    link.download = `bearbull-${String(specimen.id).padStart(4, "0")}-bg-${currentBackdrop().value}.png`;
    link.href = URL.createObjectURL(blob);
    link.click();
    URL.revokeObjectURL(link.href);
  }, "image/png");
}

function buildRack() {
  els.rack.replaceChildren();
  let selected = rackIds.map((id) => collection[id]);
  if (explorer.search) {
    const results = filterCollection(collection, { query: explorer.search.value,
      side: explorer.side.value, form: explorer.form.value, trait: explorer.trait?.value, savedOnly, favorites });
    const pages = Math.max(1, Math.ceil(results.length / pageSize));
    explorerPage = Math.min(explorerPage, pages - 1);
    selected = results.slice(explorerPage * pageSize, (explorerPage + 1) * pageSize);
    explorer.count.textContent = `${results.length.toLocaleString()} CREATURE${results.length === 1 ? "" : "S"} FOUND`;
    explorer.page.textContent = `${explorerPage + 1} / ${pages}`;
    explorer.previous.disabled = explorerPage === 0;
    explorer.next.disabled = explorerPage >= pages - 1;
    explorer.empty.hidden = results.length !== 0;
  }
  selected.forEach((item) => {
    const button = document.createElement("button");
    button.className = "rack-card";
    button.dataset.rarity = item.rarity.toLowerCase();
    button.type = "button";
    button.setAttribute("aria-label", `Load ${item.name}, ${item.traits.form.label} ${item.traits.bearKind.label} and ${item.traits.bullKind.label}`);
    const preview = document.createElement("canvas");
    preview.width = 64;
    preview.height = 64;
    renderBearBull(preview.getContext("2d", { alpha: false }), item, 0, false);
    const label = document.createElement("span");
    const name = document.createElement("b");
    const lineage = document.createElement("i");
    name.textContent = `#${String(item.id).padStart(4, "0")} ${item.name.toUpperCase()}`;
    lineage.textContent = `${item.rarity} · ${item.balance}% BULL · ${item.traits.form.label} · ${item.traits.bearKind.label} × ${item.traits.bullKind.label}`;
    label.append(name, lineage);
    button.append(preview, label);
    button.addEventListener("click", () => {
      loadSpecimen(item.id);
      document.querySelector(".lab-shell").scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "center" });
    });
    els.rack.append(button);
  });
}

function habitatSpecimenFor(value, tier) {
  return collection.find((item) => (
    item.traits.backdrop.value === value
    && item.rarity === tier
    && item.traits.form.value === "normie"
    && item.traits.weather.value === "clear"
  )) ?? collection.find((item) => (
    item.traits.backdrop.value === value
    && item.rarity === tier
  )) ?? collection.find((item) => item.traits.backdrop.value === value);
}

function buildHabitatRack() {
  habitatPreviews = [];
  els.habitatRack.replaceChildren();
  habitatSystem.forEach(({ value, label: habitatLabel, motion, tier }) => {
    const item = habitatSpecimenFor(value, tier);
    const button = document.createElement("button");
    button.className = "habitat-card";
    button.dataset.tier = tier.toLowerCase();
    button.type = "button";
    button.dataset.scene = value;
    button.setAttribute("aria-label", `Preview ${habitatLabel} with this creature`);
    button.setAttribute("aria-pressed", String(currentBackdrop().value === value));
    const preview = document.createElement("canvas");
    preview.width = 64;
    preview.height = 64;
    const previewContext = preview.getContext("2d", { alpha: false });
    previewContext.imageSmoothingEnabled = false;
    iconBackdrop(previewContext, item, 0);
    const label = document.createElement("span");
    const name = document.createElement("strong");
    const loop = document.createElement("i");
    name.textContent = habitatLabel;
    loop.textContent = `${tier} · ${motion}`;
    label.append(name, loop);
    button.append(preview, label);
    button.addEventListener("click", () => {
      backgroundViewIndex = habitatByValue[value].index;
      updatePanel();
      renderBearBull(ctx, specimen, frame, false, value);
      document.querySelector(".lab-shell").scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "center" });
    });
    habitatPreviews.push({ context: previewContext, item });
    els.habitatRack.append(button);
  });
}

function renderHabitatPreviews(f) {
  if (els.habitatRack.closest("details")?.open === false) return;
  habitatPreviews.forEach(({ context: previewContext, item }) => {
    iconBackdrop(previewContext, item, f);
  });
}

els.voiceTrigger.addEventListener("click", playVoice);
els.roll.addEventListener("click", () => loadSpecimen(randomTokenId()));
els.background.addEventListener("click", cycleBackground);
els.sound.addEventListener("click", () => setSound(!soundOn));
els.save.addEventListener("click", savePng);
els.tokenForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    loadSpecimen(Number(els.tokenInput.value));
    els.tokenInput.setCustomValidity("");
  } catch (error) {
    els.tokenInput.setCustomValidity(error.message);
    els.tokenInput.reportValidity();
  }
});
els.previous.addEventListener("click", () => loadSpecimen((specimen.id - 1 + COLLECTION_SIZE) % COLLECTION_SIZE));
els.next.addEventListener("click", () => loadSpecimen((specimen.id + 1) % COLLECTION_SIZE));

document.addEventListener("keydown", (event) => {
  if (event.ctrlKey || event.metaKey || event.altKey || event.repeat) return;
  if (event.target.closest?.("input, textarea, select, button, a, summary, [contenteditable=true]")) return;
  if (event.key.toLowerCase() === "r") loadSpecimen(randomTokenId());
  if (event.key.toLowerCase() === "b") cycleBackground();
  if (event.key.toLowerCase() === "m") setSound(!soundOn);
  if (event.key.toLowerCase() === "s") savePng();
  if (event.code === "Space") {
    event.preventDefault();
    playVoice();
  }
});

function animate(now) {
  if (!document.hidden && now - lastFrameAt >= 1000 / 12) {
    frame += 1;
    lastFrameAt = now;
    renderBearBull(ctx, specimen, frame, now < reactingUntil, currentBackdrop().value);
    renderHabitatPreviews(frame);
  }
  if (!reducedMotion) requestAnimationFrame(animate);
}

if (explorer.search) {
  const resetPage = () => { explorerPage = 0; buildRack(); };
  if (explorer.trait) {
    for (const [key, label] of [["ears", "Ears"], ["horns", "Horns"], ["eyes", "Eyes"], ["outfit", "Wardrobe"], ["neck", "Objects"], ["headwear", "Headwear"], ["backdrop", "Habitats"]]) {
      const group = document.createElement("optgroup");
      group.label = label;
      for (const trait of pools[key]) {
        const option = document.createElement("option");
        option.value = `${key}:${trait.value}`;
        option.textContent = trait.label;
        group.append(option);
      }
      explorer.trait.append(group);
    }
    explorer.trait.addEventListener("change", resetPage);
  }
  explorer.search.addEventListener("input", resetPage);
  explorer.side.addEventListener("change", resetPage);
  explorer.form.addEventListener("change", resetPage);
  explorer.saved.addEventListener("click", () => {
    savedOnly = !savedOnly;
    explorer.saved.setAttribute("aria-pressed", String(savedOnly));
    resetPage();
  });
  document.querySelector("#clear-filters").addEventListener("click", () => {
    explorer.search.value = ""; explorer.side.value = "all"; explorer.form.value = "all";
    if (explorer.trait) explorer.trait.value = "all";
    savedOnly = false; explorer.saved.setAttribute("aria-pressed", "false"); resetPage();
  });
  explorer.previous.addEventListener("click", () => { explorerPage -= 1; buildRack(); });
  explorer.next.addEventListener("click", () => { explorerPage += 1; buildRack(); });
  explorer.favorite.addEventListener("click", () => {
    if (favorites.has(specimen.id)) favorites.delete(specimen.id); else favorites.add(specimen.id);
    try {
      localStorage.setItem("bearbulls:favorites:v1", JSON.stringify([...favorites]));
      explorer.status.textContent = favorites.has(specimen.id) ? "Saved in this browser. This is not a mint reservation." : "Removed from your favourites.";
    } catch { explorer.status.textContent = "Browser storage is unavailable. This favourite lasts for this visit only."; }
    updateCollector(); if (savedOnly) resetPage();
  });
  explorer.share.addEventListener("click", async () => {
    const url = specimenUrl().href;
    try {
      await navigator.clipboard.writeText(url);
      explorer.status.textContent = "Specimen link copied. Share it wherever you like.";
    } catch { explorer.status.textContent = `Copy this specimen link: ${url}`; }
  });
  window.addEventListener("popstate", () => loadSpecimen(tokenFromSearch(window.location.search)));
}
updatePanel();
buildRack();
buildHabitatRack();
renderBearBull(ctx, specimen, 0, false);
if (!reducedMotion) requestAnimationFrame(animate);
