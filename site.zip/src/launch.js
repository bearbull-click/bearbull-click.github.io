import { ACTIVE_NETWORK, ROBINHOOD_MAINNET, LAUNCH_CONFIG, launchBlockers, selectNetwork } from "./launch-config.mjs";

const connect = document.querySelector("#connect-wallet");
const switchButton = document.querySelector("#switch-network");
const status = document.querySelector("#wallet-state");
const provider = window.ethereum?.request ? window.ethereum : null;
let account = null;
let chain = null;
let pending = false;

const checklist = document.querySelector("#launch-checklist");
for (const blocker of launchBlockers(LAUNCH_CONFIG, ROBINHOOD_MAINNET)) {
  const item = document.createElement("li");
  item.textContent = blocker === "Confirm the mint price"
    ? "Specify payment units for the $10 mint target" : blocker;
  checklist.append(item);
}
document.querySelector("#preview-network").textContent = ACTIVE_NETWORK.name;
// Display the approved offer target; this does not configure or enable payment.
document.querySelector("#mint-price").textContent = "$10 USD target";

function renderWallet() {
  connect.disabled = !provider || pending;
  connect.textContent = pending ? "Waiting for wallet…" : account ? "Wallet connected" : "Connect wallet";
  switchButton.hidden = !account || chain === ACTIVE_NETWORK.chainIdHex;
  switchButton.disabled = pending;
  status.textContent = !provider ? "Explore freely. To test a connection, open this page in an EVM wallet browser."
    : account ? `${account.slice(0, 6)}…${account.slice(-4)} · ${chain === ACTIVE_NETWORK.chainIdHex ? ACTIVE_NETWORK.name : "Different network"}`
      : "Optional connection. No mint or payment is available in this preview.";
}
function showError(error) {
  status.textContent = Number(error?.code) === 4001 ? "Request declined. You can keep exploring without a wallet."
    : `Wallet request failed: ${error?.message || "Please try again in your wallet."}`;
}
connect.addEventListener("click", async () => {
  if (!provider || pending) return;
  pending = true; renderWallet();
  let failure;
  try {
    const accounts = await provider.request({ method: "eth_requestAccounts" });
    account = accounts?.[0] ?? null;
    chain = String(await provider.request({ method: "eth_chainId" })).toLowerCase();
  } catch (error) { failure = error; }
  finally { pending = false; renderWallet(); if (failure) showError(failure); }
});
switchButton.addEventListener("click", async () => {
  if (!provider || pending) return;
  pending = true; renderWallet();
  let failure;
  try { chain = await selectNetwork(provider); }
  catch (error) { failure = error; }
  finally { pending = false; renderWallet(); if (failure) showError(failure); }
});
provider?.on?.("accountsChanged", (accounts) => { account = accounts?.[0] ?? null; renderWallet(); });
provider?.on?.("chainChanged", (value) => { chain = String(value).toLowerCase(); renderWallet(); });
provider?.on?.("disconnect", () => { account = null; chain = null; renderWallet(); });
// Deliberately no transaction sender. A reviewed adapter and onchain preflight
// must be implemented before any mint can be enabled, even with populated config.
renderWallet();
