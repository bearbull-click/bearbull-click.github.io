import * as ethers from '../vendor/ethers.min.js';
import {discoverWallets} from './wallet-provider.mjs';
import {ROBINHOOD_TESTNET,selectNetwork} from './launch-config.mjs';
import {COLLECTOR as C,selectedCreature,creatureIndex,creaturePage,mintBlocker,assertWallet} from './collector-config.mjs';
import {CODE_HASHES} from './collector-code.mjs';
import {generateCollection} from '../output/onchain/final-v025/source/core.mjs';
const $=id=>document.getElementById(id),rpc=new ethers.JsonRpcProvider(ROBINHOOD_TESTNET.rpcUrl);
const abi=['function paymentToken() view returns(address)','function treasury() view returns(address)','function PRICE() view returns(uint256)','function totalReleased() view returns(uint256)','function totalMinted() view returns(uint256)','function paused() view returns(bool)','function hasMinted(address) view returns(bool)','function ownerOf(uint256) view returns(address)','function assignments(uint256) view returns(address art,uint16 artIndex,uint16 releaseIndex)','function releases(uint256) view returns(address art,bytes32 provenance,uint64 startsAt,uint16 count,uint16 minted)','function mint(uint256)','error ERC721NonexistentToken(uint256)'];
const tokenAbi=['function decimals() view returns(uint8)','function balanceOf(address) view returns(uint256)','function allowance(address,address) view returns(uint256)','function approve(address,uint256) returns(bool)','function faucet()'];
const drop=new ethers.Contract(C.collection,abi,rpc),token=new ethers.Contract(C.payment,tokenAbi,rpc);
const allCreatures=generateCollection(),collection=C.specimenIds.map(id=>allCreatures[id]),byId=new Map(collection.map(item=>[item.id,item])),pageCount=Math.ceil(collection.length/12),storageKey='bearbulls:collector:46630:'+C.collection;
let selected=selectedCreature(location.search),page=creaturePage(selected),account=null,injected=null,signer=null,state=null,verified=false,busy=false,loading=false,revision=0,detach=()=>{},pending=null,storageError=null,discovery;
const message=text=>{$('mint-status').textContent=text;};
const short=a=>a.slice(0,6)+'…'+a.slice(-4);
function readPending(){try{const raw=localStorage.getItem(storageKey);pending=raw?JSON.parse(raw):null;if(pending&&(!/^0x[\da-f]{64}$/i.test(pending.hash)||!ethers.isAddress(pending.account)||!['mint','approve','faucet'].includes(pending.kind)||!Number.isInteger(pending.id)||creatureIndex(pending.id)<0))throw Error('Invalid saved transaction record.');}catch(e){storageError='Saved transaction state cannot be read. Resolve browser storage before sending transactions.';}}
readPending();
function render(){
 const locked=busy||loading||!!pending||!!storageError;
 $('connect').disabled=locked||!discovery?.list().length;
 $('connect').textContent=account?'Reconnect / switch wallet':'Connect wallet';
 for(const id of ['wallet-select','rescan','creature-select','previous','next'])$(id).disabled=busy||loading;
 $('previous').disabled=busy||loading||page===0;$('next').disabled=busy||loading||page===pageCount-1;
 $('refresh').disabled=busy||loading;
 $('account-state').textContent=account?short(account):'Not connected';
 $('balance-state').textContent=state?.account?ethers.formatUnits(state.balance,6)+' mock USDG':'—';
 $('supply-state').textContent=state?`${state.minted} / 100 minted · ${state.paused?'Paused':'Open'}`:'Not verified yet';
 $('availability').textContent=loading?'CHECKING…':!state?'NOT VERIFIED':state.sold?'ALREADY MINTED':state.paused?'SALE PAUSED':!state.started?'NOT OPEN YET':'AVAILABLE';
 $('mint-guidance').textContent=storageError||(pending?'Transaction saved. Check its receipt before continuing.':mintBlocker(state))||'Ready. Minting costs 100 mock USDG plus test ETH gas.';
 const eligible=verified&&state?.account&&!state.hasMinted&&!state.sold&&!state.paused&&state.started;
 $('faucet').disabled=locked||!eligible||state.balance>=C.price;
 $('approve').disabled=locked||!eligible||state.balance<C.price||state.allowance>=C.price;
 $('mint').disabled=locked||!verified||!!mintBlocker(state);
 $('mint').textContent='Mint #'+String(selected).padStart(4,'0');
 $('wallet-help').textContent=discovery?.list().length?'Choose your wallet. Every transaction needs your separate approval.':'No wallet detected. Open this page in your Rabby-enabled browser, then Rescan.';
 for(const button of $('mint-grid').querySelectorAll('button'))button.disabled=busy||loading;
}
function portrait(){const item=byId.get(selected);$('specimen-id').textContent='CREATURE #'+String(selected).padStart(4,'0');$('creature-name').textContent=item.name;$('mint-portrait').src=`${C.directory}previews/${String(selected).padStart(4,'0')}.png`;$('mint-portrait').alt=item.name+' — BEARBULLS #'+selected;$('explore-selected').href=`${C.directory}animations/${String(selected).padStart(4,'0')}.html`;$('creature-select').value=String(selected);for(const b of $('mint-grid').querySelectorAll('button'))b.setAttribute('aria-pressed',String(Number(b.dataset.id)===selected));}
function grid(){const nodes=collection.slice(page*12,page*12+12).map(item=>{const b=document.createElement('button');b.type='button';b.dataset.id=item.id;b.setAttribute('aria-label',`Choose ${item.name}, creature ${item.id}; check availability`);b.setAttribute('aria-pressed',String(item.id===selected));const image=document.createElement('img');image.src=`${C.directory}previews/${String(item.id).padStart(4,'0')}.png`;image.alt='';image.width=image.height=512;image.loading='lazy';const label=document.createElement('span');label.textContent=`#${String(item.id).padStart(4,'0')} · ${item.name}`;b.append(image,label);b.onclick=()=>choose(item.id);return b;});$('mint-grid').replaceChildren(...nodes);$('page-state').textContent=`${page+1} / ${pageCount}`;render();}
async function choose(id){if(busy||loading)return;selected=id;state=null;const url=new URL(location.href);url.searchParams.set('token',String(id));history.replaceState(null,'',url);portrait();await refresh();}
for(const item of collection){const o=document.createElement('option');o.value=item.id;o.textContent=`#${String(item.id).padStart(4,'0')} · ${item.name}`;$('creature-select').append(o);}
$('creature-select').onchange=async()=>{page=creaturePage(Number($('creature-select').value));grid();await choose(Number($('creature-select').value));};
$('previous').onclick=()=>{page--;grid();};$('next').onclick=()=>{page++;grid();};
function invalidate(){revision++;detach();detach=()=>{};account=injected=signer=null;state=null;render();message('Wallet changed. Reconnect to continue. Any submitted transaction remains saved.');}
discovery=discoverWallets(window,entries=>{const old=$('wallet-select').value;$('wallet-select').replaceChildren(...entries.map(w=>{const o=document.createElement('option');o.value=w.id;o.textContent=w.name;return o;}));if(!entries.length){const empty=document.createElement('option');empty.textContent='No wallet detected';empty.value='';$('wallet-select').append(empty);}if(entries.some(e=>e.id===old))$('wallet-select').value=old;render();});
$('rescan').onclick=()=>discovery.scan();$('wallet-select').onchange=invalidate;
async function environment(){
 verified=false;
 if((await rpc.getNetwork()).chainId!==46630n)throw Error('Unexpected RPC network.');
 await Promise.all(Object.keys(CODE_HASHES).map(async key=>{if(ethers.keccak256(await rpc.getCode(C[key]))!==CODE_HASHES[key])throw Error('Deployed contract does not match the verified rehearsal.');}));
 const [payment,treasury,price,decimals]=await Promise.all([drop.paymentToken(),drop.treasury(),drop.PRICE(),token.decimals()]);
 if(payment!==C.payment||treasury!==C.treasury||price!==C.price||decimals!==6n)throw Error('Collection payment configuration mismatch.');
 verified=true;
}
async function snapshot(){
 const id=selected,who=account,rev=revision;
 const block=await rpc.getBlock('latest');const overrides={blockTag:block.number};
 const [paused,minted,released,a,release]=await Promise.all([drop.paused(overrides),drop.totalMinted(overrides),drop.totalReleased(overrides),drop.assignments(id,overrides),drop.releases(0,overrides)]);
 if(released!==BigInt(C.supply)||a.art!==C.art||Number(a.artIndex)!==creatureIndex(id)||a.releaseIndex!==0n||release.art!==C.art||release.provenance!==C.provenance||release.count!==BigInt(C.supply))throw Error('Selected artwork does not match the verified batch.');
 let sold=false;
 try{await drop.ownerOf(id,overrides);sold=true;}catch(e){let decoded;try{decoded=drop.interface.parseError(e.data);}catch{}if(decoded?.name!=='ERC721NonexistentToken')throw e;}
 let hasMinted=false,balance=0n,allowance=0n;
 if(who)[hasMinted,balance,allowance]=await Promise.all([drop.hasMinted(who,overrides),token.balanceOf(who,overrides),token.allowance(who,C.collection,overrides)]);
 if(rev!==revision||id!==selected||who!==account)throw Error('Selection or wallet changed. Refresh to continue.');
 state={paused,minted,sold,started:BigInt(block.timestamp)>=release.startsAt,account:who,hasMinted,balance,allowance};
}
function txLink(hash){$('receipt').href=ROBINHOOD_TESTNET.explorerUrl+'/tx/'+hash;$('receipt').textContent='VIEW TRANSACTION ↗';$('receipt').hidden=false;}
async function recover(){
 if(!pending)return false;
 const saved=pending;txLink(saved.hash);
 const receipt=await rpc.getTransactionReceipt(saved.hash);if(!receipt){message('Transaction awaiting confirmation. Refresh to check again.');return true;}
 const tx=await rpc.getTransaction(saved.hash);
 const target=saved.kind==='mint'?C.collection:C.payment;
 const data=saved.kind==='mint'?drop.interface.encodeFunctionData('mint',[saved.id]):token.interface.encodeFunctionData(saved.kind,saved.kind==='approve'?[C.collection,C.price]:[]);
 if(!tx||tx.chainId!==46630n||tx.from.toLowerCase()!==saved.account.toLowerCase()||tx.to!==target||tx.data!==data||tx.value!==0n)throw Error('Saved transaction does not match this mint flow. Keep the receipt for review.');
 localStorage.removeItem(storageKey);pending=null;
 message(receipt.status===1?(saved.kind==='mint'?`Creature #${saved.id} minted successfully. Your onchain art is available immediately.`:saved.kind==='approve'?'100 mock USDG approved. You can now mint your chosen creature.':'Test funds received. Approve the mint price when ready.'):'Transaction reverted. No purchase completed; refresh before trying again.');
 return true;
}
async function refresh(){if(loading)return;loading=true;state=null;render();try{await environment();const recovered=await recover();await snapshot();if(!recovered)message('Live testnet state checked. Choose a creature and connect your wallet.');}catch(e){state=null;verified=false;message(e.shortMessage||e.message);}finally{loading=false;render();}}
async function locked(fn){if(busy||loading)return;busy=true;render();try{await fn();}catch(e){message(Number(e.code)===4001||e.code==='ACTION_REJECTED'?'Request declined. No further transaction was sent.':e.shortMessage||e.message);}finally{busy=false;render();}}
$('connect').onclick=()=>locked(async()=>{
 const entry=discovery.list().find(e=>e.id===$('wallet-select').value);if(!entry)throw Error('Select a detected wallet.');
 invalidate();const rev=revision;
 await entry.provider.request({method:'eth_requestAccounts'});await selectNetwork(entry.provider,ROBINHOOD_TESTNET);
 const nextSigner=await new ethers.BrowserProvider(entry.provider).getSigner();const nextAccount=await nextSigner.getAddress();await assertWallet(entry.provider,nextAccount);
 if(rev!==revision)throw Error('Wallet selection changed. Reconnect.');
 injected=entry.provider;signer=nextSigner;account=nextAccount;const bound=injected;
 for(const event of ['accountsChanged','chainChanged','disconnect'])bound.on?.(event,invalidate);
 detach=()=>{for(const event of ['accountsChanged','chainChanged','disconnect'])bound.removeListener?.(event,invalidate);};
 await refresh();
});
async function transact(kind){
 if(storageError)throw Error(storageError);if(pending)throw Error('Check the pending transaction first.');
 const who=account,provider=injected,writer=signer,id=selected,rev=revision;
 if(!writer)throw Error('Connect a wallet first.');await assertWallet(provider,who);await environment();await snapshot();
 if(kind==='mint'&&mintBlocker(state))throw Error(mintBlocker(state));
 if(kind!=='mint'&&(state.hasMinted||state.sold||state.paused||!state.started))throw Error(mintBlocker(state)||'This wallet or creature is not eligible.');
 if(kind==='approve'&&state.balance<C.price)throw Error('Get free mock USDG first.');
 // Check storage before any wallet request, so a sent hash can be retained.
 localStorage.setItem(storageKey+':check','1');localStorage.removeItem(storageKey+':check');
 const request={to:kind==='mint'?C.collection:C.payment,data:kind==='mint'?drop.interface.encodeFunctionData('mint',[id]):token.interface.encodeFunctionData(kind,kind==='approve'?[C.collection,C.price]:[]),value:0n,chainId:46630};
 await writer.estimateGas(request);await assertWallet(provider,who);
 if(rev!==revision||selected!==id)throw Error('Wallet or creature changed. Review again.');
 message(kind==='mint'?`Review mint #${id}: 100 mock USDG plus test ETH gas.`:kind==='approve'?'Review approval: exactly 100 mock USDG, only for this test collection.':'Review the free mock-USDG faucet request; test ETH gas is required.');
 const tx=await writer.sendTransaction(request);pending={kind,id,account:who,hash:tx.hash};
 try{localStorage.setItem(storageKey,JSON.stringify(pending));}catch{storageError='Transaction sent but browser storage failed. Keep the linked receipt; do not submit again.';}
 txLink(tx.hash);message('Transaction submitted. Waiting for confirmation…');render();
 try{await rpc.waitForTransaction(tx.hash,1,60000);}catch{message('Confirmation is taking longer. Your transaction is saved; refresh to check it.');return;}
 await refresh();
}
for(const id of ['faucet','approve','mint'])$(id).onclick=()=>locked(()=>transact(id));
$('refresh').onclick=refresh;
grid();portrait();await refresh();
