import { SALE_TERMS } from './sale-terms.mjs';
// Verified against https://docs.robinhood.com/chain/connecting/ on 2026-09-16.
export const ROBINHOOD_MAINNET = Object.freeze({
  chainId: 4663, chainIdHex: "0x1237", name: "Robinhood Chain",
  rpcUrl: "https://rpc.mainnet.chain.robinhood.com",
  explorerUrl: "https://robinhoodchain.blockscout.com", testnet: false
});
export const ROBINHOOD_TESTNET = Object.freeze({
  chainId: 46630, chainIdHex: "0xb626", name: "Robinhood Chain Testnet",
  rpcUrl: "https://rpc.testnet.chain.robinhood.com",
  explorerUrl: "https://explorer.testnet.chain.robinhood.com", testnet: true
});
// Preview connections default to testnet. Mainnet must be selected deliberately
// in a reviewed deployment configuration; URL parameters cannot change it.
export const ACTIVE_NETWORK = ROBINHOOD_TESTNET;
export const LAUNCH_CONFIG = Object.freeze({
  artworkCount: 10_000,
  candidateWaveCount: 0, // Ten-wave proposal is archived, not a launch requirement.
  mode: SALE_TERMS.launchFormat,
  supply: SALE_TERMS.supply,
  initialReleaseSupply: SALE_TERMS.initialReleaseSupply,
  maxReleaseSupply: SALE_TERMS.maxReleaseSupply,
  demandValidated: false,
  strategy: SALE_TERMS.strategy,
  pricingMode: 'usd',
  priceUsdCents: SALE_TERMS.priceUsdCents,
  paymentFamilies: SALE_TERMS.paymentFamilies,
  futurePaymentFamilies: SALE_TERMS.futurePaymentFamilies,
  collectionTokenRequired: false,
  liquidityRequired: false,
  paymentRoutesVerified: false,
  priceWei: null, // USD price is fixed; ETH/token amounts require a fresh quote.
  startsAt: null,
  contractAddress: null,
  deploymentChainId: null,
  metadataMode: "onchain",
  artAddress: null,
  onchainMediaVerified: false,
  metadataBaseUri: null, // legacy IPFS prototype only
  provenanceHash: null,
  snapshotSourceChainId: 1,
  snapshotBlock: null,
  merkleRoot: null,
  termsFinalized: false,
  transactionAdapterReady: false
});

const nonzeroAddress = (v) => typeof v === "string" && /^0x[\da-f]{40}$/i.test(v) && !/^0x0{40}$/i.test(v);
const hash = (v) => typeof v === "string" && /^0x[\da-f]{64}$/i.test(v) && !/^0x0{64}$/i.test(v);

export function launchBlockers(config = LAUNCH_CONFIG, network = ACTIVE_NETWORK) {
  const blockers = [];
  if (!["public", "community-waves"].includes(config.mode)) blockers.push("Choose the drop format");
  if (!Number.isInteger(config.supply) || config.supply < 1 || config.supply > 10_000) blockers.push("Confirm the drop supply");
  if (config.strategy === 'creature-first') {
    if (!Number.isInteger(config.initialReleaseSupply) || config.initialReleaseSupply < 1 || config.initialReleaseSupply > 100 || config.initialReleaseSupply > config.supply) blockers.push("Confirm the first release size (up to 100 creatures)");
    if (config.demandValidated !== true) blockers.push("Review independent collector interest before opening the pilot");
  }
  if (config.pricingMode === 'usd') {
    if (!Number.isSafeInteger(config.priceUsdCents) || config.priceUsdCents <= 0) blockers.push("Confirm the mint price");
    if (config.paymentRoutesVerified !== true) blockers.push("Verify the USDG payment route and dollar pricing policy");
  } else if (config.pricingMode === 'native') {
    if (typeof config.priceWei !== "string" || !/^\d+$/.test(config.priceWei)) blockers.push("Confirm the mint price");
  } else blockers.push("Confirm the mint price");
  if (!config.termsFinalized) blockers.push("Finalize the launch terms");
  if (!nonzeroAddress(config.contractAddress)) blockers.push("Deploy and verify the mint contract");
  if (config.deploymentChainId !== network.chainId) blockers.push("Verify the deployment network");
  if (!config.startsAt || !Number.isFinite(Date.parse(config.startsAt))) blockers.push("Set the launch date");
  if (config.metadataMode === "onchain") {
    if (!nonzeroAddress(config.artAddress)) blockers.push("Deploy the immutable artwork contracts");
    if (config.onchainMediaVerified !== true) blockers.push("Verify minted onchain metadata and media");
  } else if (config.metadataMode === "ipfs") {
    if (typeof config.metadataBaseUri !== "string" || !/^ipfs:\/\/[^/]+\//.test(config.metadataBaseUri) || /placeholder|replace|<|>/i.test(config.metadataBaseUri)) blockers.push("Publish permanent artwork and metadata");
  } else blockers.push("Choose the metadata storage mode");
  if (!hash(config.provenanceHash)) blockers.push("Publish the artwork provenance");
  if (config.mode === "community-waves") {
    if (config.snapshotSourceChainId !== 1 || !Number.isSafeInteger(config.snapshotBlock) || config.snapshotBlock < 1) blockers.push("Finalize the Ethereum ownership snapshot");
    if (!hash(config.merkleRoot)) blockers.push("Publish the selected-wallet proof root");
  }
  if (!config.transactionAdapterReady) blockers.push("Verify the mint transaction flow");
  return blockers;
}

export function walletChainParams(network) {
  if (![ROBINHOOD_MAINNET, ROBINHOOD_TESTNET].includes(network)) throw new Error("Unsupported network configuration");
  return {
    chainId: network.chainIdHex, chainName: network.name,
    nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
    rpcUrls: [network.rpcUrl], blockExplorerUrls: [network.explorerUrl]
  };
}

export async function selectNetwork(provider, network = ACTIVE_NETWORK) {
  try {
    await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: network.chainIdHex }] });
  } catch (error) {
    if (Number(error?.code) !== 4902) throw error;
    await provider.request({ method: "wallet_addEthereumChain", params: [walletChainParams(network)] });
    await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: network.chainIdHex }] });
  }
  const chainId = await provider.request({ method: "eth_chainId" });
  if (typeof chainId !== "string" || chainId.toLowerCase() !== network.chainIdHex) throw new Error("The wallet did not select the requested network.");
  return chainId;
}
