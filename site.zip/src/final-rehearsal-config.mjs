// Reviewed v0.25 rehearsal IDs: every finish/insider trait and all eight forms.
export const FINAL_IDS=Object.freeze([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,98,135,140,155,175,184,186,187,189,209,240]);
export const FINAL_DIRECTORY='output/onchain/final-v025/';
export const FINAL_SCHEMA='bearbulls-creature-final-v025';
export const FINAL_PROVENANCE='0xebf21d1a0c86678e70d8f9420d6c9ef04308d2b2bf1bf4db439e75d0e54e70d4';
