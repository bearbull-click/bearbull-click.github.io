export const RARITY_POINTS = { common: 0, uncommon: 1, rare: 3, epic: 6, mythic: 12 };
export const COLLECTION_SIZE = 10000;
export const COLLECTION_NAMESPACE = "bearbulls-genesis-v1";

const trait = (label, value, weight, rarity = "common", extra = {}) => ({ label, value, weight, rarity, ...extra });

export const pools = {
  bearKind: [
    trait("Grizzly", "grizzly", 20, "common", { coat: "#916341", shade: "#533825", mark: "#c58c56", ear: "round" }),
    trait("Black Bear", "black", 16, "common", { coat: "#293234", shade: "#11191a", mark: "#9b7650", ear: "round" }),
    trait("Giant Panda", "panda", 15, "uncommon", { coat: "#f5e7c9", shade: "#222426", mark: "#222426", ear: "round" }),
    trait("Polar Bear", "polar", 13, "uncommon", { coat: "#f4edde", shade: "#a7c5c3", mark: "#fff7e2", ear: "small" }),
    trait("Koala", "koala", 12, "uncommon", { coat: "#9ba6a5", shade: "#515c5b", mark: "#d7d0be", ear: "fluffy" }),
    trait("Sun Bear", "sun", 10, "rare", { coat: "#3b3531", shade: "#171c1b", mark: "#f0bd45", ear: "small" }),
    trait("Spectacled Bear", "spectacled", 8, "rare", { coat: "#684b3b", shade: "#31261f", mark: "#efd39b", ear: "round" }),
    trait("Sloth Bear", "sloth", 6, "epic", { coat: "#4c4144", shade: "#211b20", mark: "#e4d0a8", ear: "fluffy" })
  ],
  bullKind: [
    trait("Highland", "highland", 20, "common", { hornScale: 0.9, ears: "side", forelock: true }),
    trait("Black Angus", "angus", 18, "common", { hornScale: 0.48, ears: "side", forelock: false }),
    trait("Brahman", "brahman", 16, "uncommon", { hornScale: 0.68, ears: "droop", forelock: false }),
    trait("Texas Longhorn", "longhorn", 15, "uncommon", { hornScale: 1.45, ears: "side", forelock: false }),
    trait("Zebu", "zebu", 13, "rare", { hornScale: 0.82, ears: "droop", forelock: true }),
    trait("Spanish Fighting", "fighting", 11, "rare", { hornScale: 0.96, ears: "sharp", forelock: true }),
    trait("Watusi", "watusi", 7, "epic", { hornScale: 1.7, ears: "side", forelock: false })
  ],
  coat: [
    trait("Natural", "natural", 38),
    trait("Mud Dipped", "mud", 18, "uncommon", { overlay: "#8a5834" }),
    trait("Radioactive", "radioactive", 12, "rare", { override: "#91ad68", shade: "#42593a" }),
    trait("Blueberry", "blueberry", 10, "rare", { override: "#7188bc", shade: "#354468" }),
    trait("Negative", "negative", 8, "epic", { override: "#f0e6d1", shade: "#413a49" }),
    trait("Gold Rush", "gold", 7, "epic", { override: "#dfa846", shade: "#925a32" }),
    trait("Candy Static", "candy", 5, "epic", { override: "#c47f9e", shade: "#704d72" }),
    trait("Chrome Ghost", "chrome", 2, "mythic", { override: "#cce5df", shade: "#6683a0" })
  ],
  silhouette: [
    trait("Soft Block", "soft", 25, "common", { width: 1, height: 0, y: 0, jaw: "soft" }),
    trait("Long Ledger", "long", 18, "common", { width: 0, height: 2, y: 0, jaw: "long" }),
    trait("Low Brow", "low", 15, "uncommon", { width: 0, height: -2, y: 0, jaw: "low" }),
    trait("Wide Cheeks", "cheeks", 13, "uncommon", { width: 2, height: 0, y: 0, jaw: "cheeks" }),
    trait("Wedge Skull", "wedge", 11, "rare", { width: 0, height: 1, y: 0, jaw: "wedge" }),
    trait("Small Block", "tiny", 8, "rare", { width: -2, height: -2, y: 0, jaw: "tiny" }),
    trait("Hammer Brow", "hammer", 6, "epic", { width: 2, height: -1, y: 0, jaw: "hammer" }),
    trait("Totem Brow", "totem", 4, "epic", { width: -1, height: 2, y: 0, jaw: "totem" })
  ],
  faceLayout: [
    trait("Dead Center", "center", 28, "common", { spread: 0, y: 0, skew: 0 }),
    trait("High Beams", "high", 17, "common", { spread: 0, y: -2, skew: 0 }),
    trait("Low Battery", "low", 15, "uncommon", { spread: 0, y: 2, skew: 0 }),
    trait("Wide Apart", "wide", 13, "uncommon", { spread: 2, y: 0, skew: 0 }),
    trait("Close Watch", "close", 11, "rare", { spread: -2, y: 0, skew: 0 }),
    trait("Crooked Signal", "crooked", 8, "rare", { spread: 0, y: 0, skew: 2 }),
    trait("Fallen Left", "fallen", 5, "epic", { spread: 0, y: 1, skew: -2 }),
    trait("Split Vision", "split", 3, "mythic", { spread: 2, y: -1, skew: 2 })
  ],
  muzzle: [
    trait("Block Snout", "block", 24, "common", { width: 0, height: 0, y: 0 }),
    trait("Wide Bull", "wide", 18, "common", { width: 4, height: 0, y: 0 }),
    trait("Long Bear", "long", 15, "uncommon", { width: -2, height: 3, y: 0 }),
    trait("Koala Button", "button", 13, "uncommon", { width: -4, height: 2, y: 0 }),
    trait("Droop Muzzle", "droop", 11, "rare", { width: 0, height: 2, y: 1 }),
    trait("Tiny Snout", "tiny", 8, "rare", { width: -4, height: -2, y: 1 }),
    trait("Hammer Snout", "hammer", 7, "epic", { width: 4, height: 0, y: 0 }),
    trait("Split Jaw", "split", 4, "epic", { width: 2, height: 2, y: 0 })
  ],
  septum: [
    trait("Gold U-Ring", "ring", 58),
    trait("No Septum", "none", 35, "uncommon"),
    trait("Twin Gold Studs", "studs", 7, "rare")
  ],
  marking: [
    trait("Clean Face", "clean", 23),
    trait("Split Face", "split", 15, "uncommon"),
    trait("Ledger Blaze", "blaze", 13, "uncommon"),
    trait("Eye Bars", "bars", 11, "uncommon"),
    trait("Mud Freckles", "freckles", 10, "rare"),
    trait("Checker Cheeks", "checker", 8, "rare"),
    trait("Scar Stripe", "scar", 7, "rare"),
    trait("Half Dipped", "halfmud", 6, "epic"),
    trait("Eclipse Mask", "eclipse", 5, "epic"),
    trait("Ticker Barcode", "barcode", 4, "epic"),
    trait("War Paint", "warpaint", 3, "mythic"),
    trait("Static Mosaic", "mosaic", 2, "mythic")
  ],
  outfit: [
    trait("Bare Shoulders", "bare", 24),
    trait("Track Jacket", "track", 15, "uncommon"),
    trait("Mud Puffer", "puffer", 13, "uncommon"),
    trait("Grass Poncho", "poncho", 11, "uncommon"),
    trait("Work Overalls", "overalls", 10, "rare"),
    trait("Short Seller Suit", "suit", 8, "rare"),
    trait("Varsity Hide", "varsity", 7, "rare"),
    trait("Bone Bib", "bonebib", 5, "epic"),
    trait("Space Collar", "space", 4, "epic"),
    trait("Cult Robe", "cult", 3, "mythic"),
    trait("Ceremonial Wings", "wings", 2, "mythic"),
    trait("Hazard Rig", "hazard", 2, "mythic")
  ],
  pose: [
    trait("Square Stance", "front", 29, "common", { x: 0, y: 0, shoulder: 0 }),
    trait("Left Shoulder High", "left", 16, "common", { x: 0, y: 0, shoulder: 1 }),
    trait("Right Shoulder High", "right", 16, "common", { x: 0, y: 0, shoulder: -1 }),
    trait("High Collar", "high", 12, "uncommon", { x: 0, y: 0, shoulder: 2 }),
    trait("Low Collar", "low", 11, "uncommon", { x: 0, y: 0, shoulder: -2 }),
    trait("Tight Shoulders", "check", 8, "rare", { x: 0, y: 0, shoulder: 2 }),
    trait("Crooked Collar", "crooked", 5, "epic", { x: 0, y: 0, shoulder: -2 }),
    trait("Close Crop", "close", 3, "mythic", { x: 0, y: 0, shoulder: 0 })
  ],
  weather: [
    trait("Clear", "clear", 27),
    trait("Hard Dusk", "dusk", 17, "common"),
    trait("Pollen", "pollen", 14, "uncommon"),
    trait("Pixel Snow", "snow", 12, "uncommon"),
    trait("Smog Band", "smog", 10, "rare"),
    trait("Red Sun", "redsun", 8, "rare"),
    trait("Ticker Storm", "ticker", 7, "epic"),
    trait("Blackout", "blackout", 5, "epic")
  ],
  horns: [
    trait("Breed Standard", "standard", 30),
    trait("Sawed Off", "sawed", 14, "uncommon"),
    trait("Gold Tips", "goldtips", 13, "uncommon"),
    trait("Antenna Tips", "antenna", 11, "rare"),
    trait("Flowering", "flowers", 10, "rare"),
    trait("Candle Horns", "candles", 8, "epic"),
    trait("Diamond Fork", "diamond", 7, "epic"),
    trait("Double Decker", "double", 5, "mythic"),
    trait("Horn Roots, Big Ears", "roots", 2, "mythic")
  ],
  eyes: [
    trait("Drowsy", "drowsy", 23),
    trait("Wide", "wide", 19),
    trait("Side Eye", "side", 16, "uncommon"),
    trait("Block Glasses", "shades", 13, "uncommon"),
    trait("Green Candles", "green", 9, "rare"),
    trait("Red Candles", "red", 8, "rare"),
    trait("Laser Ledger", "laser", 6, "epic"),
    trait("Third Bell", "third", 4, "epic"),
    trait("Void Eyes", "void", 2, "mythic")
  ],
  headwear: [
    trait("Bare", "none", 32),
    trait("Tiny Trucker", "cap", 14, "uncommon"),
    trait("Beanie at the Top", "beanie", 12, "uncommon"),
    trait("Spatial Wrap Visor", "visor", 10, "rare"),
    trait("Grass Tuft", "grass", 8, "rare"),
    trait("Mud Bucket", "bucket", 7, "rare"),
    trait("Tin Foil Horn", "foil", 6, "epic"),
    trait("Weather Crown", "crown", 5, "epic"),
    trait("Exit Halo", "halo", 3, "mythic"),
    trait("Tiny BearBull", "tiny", 3, "mythic")
  ],
  mouth: [
    trait("Poker Face", "flat", 29),
    trait("Grass Chewer", "grass", 18),
    trait("Tongue Out", "tongue", 5, "rare"),
    trait("One Gold Tooth", "tooth", 13, "uncommon"),
    trait("Bubble Gum", "gum", 10, "rare"),
    trait("Cigar Stub", "cigar", 8, "epic"),
    trait("Diamond Drool", "drool", 5, "epic"),
    trait("Screaming Portal", "portal", 2, "mythic")
  ],
  neck: [
    trait("No Collar", "none", 27),
    trait("Mud Hoodie", "hoodie", 17, "uncommon"),
    trait("Cow Bell", "bell", 14, "uncommon"),
    trait("Gold Chain", "chain", 12, "rare"),
    trait("Hardware Wallet", "wallet", 10, "rare"),
    trait("Seed Phrase Tag", "seed", 8, "rare"),
    trait("Green Candle Earring", "earring", 6, "epic"),
    trait("Rug Cape", "cape", 4, "epic"),
    trait("Liquidation Medal", "medal", 2, "mythic")
  ],
  aura: [
    trait("Clear Air", "none", 36),
    trait("Flies", "flies", 16),
    trait("Dust", "dust", 14, "uncommon"),
    trait("Static", "static", 11, "rare"),
    trait("Green Stink", "stink", 9, "rare"),
    trait("Blue Flame", "flame", 7, "epic"),
    trait("Red Candle Rain", "rain", 4, "epic"),
    trait("Moon Ring", "moon", 2, "mythic"),
    trait("Tiny Orbiting Charts", "charts", 1, "mythic")
  ],
  backdrop: [
    trait("Pine Forest", "forest", 17),
    trait("Open Sky", "sky", 15),
    trait("Grass Field", "grass", 15),
    trait("Mud Pit", "mud", 14),
    trait("Bamboo Grove", "bamboo", 12, "uncommon"),
    trait("Bear Cave", "cave", 10, "uncommon"),
    trait("Storm Plateau", "storm", 7, "rare"),
    trait("Red Desert", "desert", 6, "rare"),
    trait("Frozen Lake", "ice", 3, "epic"),
    trait("Moon Pasture", "moon", 1, "mythic"),
    trait("Rain Window", "rainwindow", 8, "uncommon"),
    trait("Sunny Day", "sunny", 8),
    trait("Snow Cabin", "snow", 5, "rare"),
    trait("Firelight Room", "fire", 4, "rare"),
    trait("Computer Lab", "lab", 3, "epic"),
    trait("Night Rooftop", "rooftop", 2, "epic"),
    trait("Mountain Pass", "mountain", 9),
    trait("Blue Hour", "blue", 9),
    trait("Clean Horizon", "horizon", 8, "uncommon"),
    trait("Coral Sunset", "sunset", 7, "uncommon"),
    trait("Oasis Signal", "oasis", 5, "rare"),
    trait("Volcanic Ridge", "volcano", 4, "rare"),
    trait("Aurora Range", "aurora", 3, "epic"),
    trait("Neon Alley", "cityrain", 2, "epic")
  ],
  voice: [
    trait("Honey Grunt", "grunt", 18),
    trait("Copper Snort", "snort", 16),
    trait("Koala Click", "click", 13, "uncommon"),
    trait("Panda Pop", "pop", 12, "uncommon"),
    trait("Grizzly Bass", "rumble", 11, "rare"),
    trait("Ticker Chirp", "chirp", 10, "rare"),
    trait("Highland Yodel", "yodel", 8, "epic"),
    trait("Basement Moo", "moo", 7, "epic"),
    trait("Ghost Bell", "bell", 4, "mythic"),
    trait("Glitch Roar", "glitch", 1, "mythic")
  ],
  form: [
    trait("Normie", "normie", 42, "common"),
    trait("Degen", "degen", 23, "uncommon"),
    trait("Robot", "robot", 10, "rare"),
    trait("Zombie", "zombie", 8, "epic"),
    trait("Mad", "mad", 7, "epic"),
    trait("Skull", "skull", 4, "mythic"),
    trait("Hollow", "hollow", 3, "mythic"),
    trait("Possessed", "possessed", 3, "mythic")
  ],
  archetype: [
    trait("Dip Licker", "dip", 14),
    trait("Candle Eater", "candle", 13),
    trait("Bag Defender", "bag", 12),
    trait("Mud Monk", "mud", 11),
    trait("Grass Maxi", "grass", 10),
    trait("Cloud Snorter", "cloud", 9, "uncommon"),
    trait("Chart Goblin", "chart", 9, "uncommon"),
    trait("Forest Lurker", "forest", 8, "uncommon"),
    trait("Liquidity Shaman", "liquidity", 6, "rare"),
    trait("Exit Tourist", "exit", 5, "rare"),
    trait("Moon Janitor", "moon", 2, "epic"),
    trait("Zero Candle Prophet", "prophet", 1, "mythic")
  ]
};

// Preserve the original random stream for names, lineage, spectrum and personality.
// The art expansion has its own seed; changing its weights cannot shuffle those identities.
const foundationPools = { ...pools };
export const iconicTraits = {
  ears: [
    trait("Lineage Ears", "lineage", 30),
    trait("One Fold", "folded", 14, "uncommon"),
    trait("Battle Notch", "notched", 12, "uncommon"),
    trait("Wild Tufts", "tufted", 12, "uncommon"),
    trait("Fox Tips", "pointed", 10, "rare"),
    trait("Gold Hoops", "hoops", 8, "rare"),
    trait("Tunnel Plugs", "gauges", 6, "epic"),
    trait("Pasture Tag", "tagged", 5, "epic"),
    trait("Studio Cuffs", "cuffs", 3, "mythic")
  ],
  horns: [
    trait("Crescent Horns", "crescent", 24, "uncommon"),
    trait("Ram Curls", "ram", 21, "rare"),
    trait("Lightning Horns", "bolt", 18, "rare"),
    trait("Crystal Prongs", "crystal", 15, "epic"),
    trait("Broken Crown", "broken", 14, "uncommon"),
    trait("Chrome Blades", "chrome", 8, "mythic")
  ],
  eyes: [
    trait("Half Moon", "halfmoon", 25, "uncommon"),
    trait("Cross Eyed", "cross", 18, "rare"),
    trait("Star Struck", "star", 13, "epic"),
    trait("Odd Eyes", "odd", 15, "rare"),
    trait("Gold Monocle", "monocle", 10, "epic"),
    trait("Rally Goggles", "goggles", 11, "rare"),
    trait("Long Lashes", "lashes", 8, "uncommon")
  ],
  outfit: [
    trait("After Hours Tux", "tux", 16, "rare"),
    trait("Pinstripe Broker", "pinstripe", 16, "uncommon"),
    trait("Pit Crew Racer", "racing", 16, "uncommon"),
    trait("Flight Bomber", "bomber", 14, "uncommon"),
    trait("Indigo Kimono", "kimono", 12, "rare"),
    trait("Storm Slicker", "raincoat", 12, "uncommon"),
    trait("Shearling Coat", "shearling", 9, "epic"),
    trait("Chrome Guard", "armor", 5, "mythic")
  ]
};
for (const [key, extras] of Object.entries(iconicTraits)) {
  pools[key] = [...(pools[key] ?? []), ...extras];
}

// v0.24: independent finish-pass stream; original names/DNA/personality stay stable.
export const finishTraits = {
 backdrop: [trait("After Hours Charging", "chargeyard", 1, "mythic"), trait("Server Farm", "datacenter", 2, "epic"), trait("Cactus Break", "cactusgarden", 3, "rare"), trait("Cloud Nine To Five", "cloudnine", 2, "epic")],
 neck: [trait("Silver Laptop", "laptop", 3, "epic"), trait("Triple Camera Phone", "phone", 3, "epic"), trait("Emotional Support Cactus", "petcactus", 2, "mythic")],
 ears: [trait("White Wireless Buds", "earbuds", 1, "epic"), trait("One Lost Earbud", "onebud", 1, "mythic")],
 eyes: [trait("Buffering", "buffering", 4, "rare"), trait("Meeting Could Be An Email", "deadpan", 4, "rare"), trait("Unpaid Intern", "intern", 2, "epic")]
};
for (const [key, extras] of Object.entries(finishTraits)) pools[key] = [...pools[key], ...extras];
// Capture the v0.24 pick arrays before extending the public trait catalogue.
const preInsiderPools = {...pools};
export const insiderTraits = {
 neck: [trait("Compute Is My Personality", "gpu", 3, "epic"), trait("Runway Extender", "espresso", 3, "epic"), trait("Founder Mode Pager", "pager", 2, "mythic"), trait("Exit Strategy", "esc", 2, "mythic"), trait("Banana For Scale", "banana", 2, "epic")],
 outfit: [trait("One More Thing", "keynote", 3, "epic"), trait("Warm Intro Vest", "vcvest", 3, "epic")],
 headwear: [trait("CEO Of Nothing", "papercrown", 1, "mythic")],
 eyes: [trait("Pre-Revenue Vision", "prerevenue", 3, "rare"), trait("Priced In", "pricedin", 3, "rare")],
 backdrop: [trait("Infinite Runway", "jetrunway", 1, "mythic"), trait("Waiting For Rate Cuts", "ratecut", 2, "epic")]
};
for (const [key, extras] of Object.entries(insiderTraits)) pools[key] = [...pools[key], ...extras];
function applyInsiderTraits(item) {
 const random=randomFrom(`${item.seed}:insiders-v025`);
 const living=['normie','degen','mad'].includes(item.traits.form.value);
 const calmEars=!['hoops','gauges','cuffs','earbuds','onebud'].includes(item.traits.ears.value);
 const isFinish=key=>finishTraits[key]?.some(t=>t.value===item.traits[key].value);
 if(!isFinish('backdrop')&&random()<0.035)item.traits.backdrop=pick(insiderTraits.backdrop,random);
 // Keep every v0.24 keepsake. Add a single joke only where the optional prop slot is empty.
 if(living&&calmEars&&item.accessoryCount===0&&random()<0.085){item.traits.neck=pick(insiderTraits.neck,random);item.accessoryCount=1;}
 if(living&&calmEars&&item.accessoryCount===0&&random()<0.025){item.traits.headwear=pick(insiderTraits.headwear,random);item.accessoryCount=1;}
 if(living&&random()<0.045)item.traits.outfit=pick(insiderTraits.outfit,random);
 if(['normie','degen'].includes(item.traits.form.value)&&!isFinish('eyes')&&item.traits.headwear.value!=='visor'&&random()<0.065)item.traits.eyes=pick(insiderTraits.eyes,random);
}

function applyFinishTraits(item) {
 const random = randomFrom(`${item.seed}:finish-v024`);
 if (random() < 0.085) item.traits.backdrop = pick(finishTraits.backdrop, random);
 const living = ["normie", "degen", "mad"].includes(item.traits.form.value);
 if (living && random() < 0.09) {
  for (const [key, value] of Object.entries(ACCESSORY_DEFAULTS)) if (key !== 'outfit') item.traits[key] = pools[key].find(t => t.value === value);
  item.traits.neck = pick(finishTraits.neck, random);
 }
 if (living && random() < 0.04) item.traits.ears = pick(finishTraits.ears, random);
 if (["normie", "degen"].includes(item.traits.form.value) && item.traits.headwear.value !== 'visor' && random() < 0.14) item.traits.eyes = pick(finishTraits.eyes, random);
 item.accessoryCount = Object.entries(ACCESSORY_DEFAULTS).filter(([key,value])=>key !== 'outfit' && item.traits[key].value !== value).length;
}

function applyIconicTraits(item) {
  const random = randomFrom(`${item.seed}:iconic-v1`);
  const living = ["normie", "degen", "mad"].includes(item.traits.form.value);
  item.traits.ears = pick(preInsiderPools.ears, random);
  if (random() < 0.42) item.traits.horns = pick(iconicTraits.horns, random);
  // Rare forms keep their defining sockets. New expressions remain visible.
  if (["normie", "degen"].includes(item.traits.form.value)
      && item.traits.headwear.value !== "visor" && random() < 0.55) {
    item.traits.eyes = pick(iconicTraits.eyes, random);
  }
  if (living && item.traits.outfit.value === "bare" && random() < 0.74) {
    item.traits.outfit = pick(preInsiderPools.outfit.filter(({ value }) => value !== "bare"), random);
  }
  // Clothes get their own slot. At most one atmospheric/handheld/head prop remains.
  item.accessoryCount = Object.entries(ACCESSORY_DEFAULTS)
    .filter(([key, value]) => key !== "outfit" && item.traits[key].value !== value).length;
}

const moods = [
  { label: "Sleepy", energy: 0 }, { label: "Unbothered", energy: 1 }, { label: "Suspicious", energy: 2 },
  { label: "Zen", energy: 0 }, { label: "Cocky", energy: 3 }, { label: "Feral", energy: 4 },
  { label: "Gloomy", energy: 1 }, { label: "Chaotic", energy: 4 }, { label: "Tender", energy: 1 },
  { label: "Overleveraged", energy: 3 }, { label: "Delusional", energy: 2 }, { label: "Patient", energy: 0 }
];

const habits = [
  "Buys the top and calls it weather.",
  "Keeps the seed phrase under a wet rock.",
  "Only speaks after three red candles.",
  "Chews grass while everyone else refreshes.",
  "Has never sold. Has never learned.",
  "Counts clouds instead of confirmations.",
  "Sleeps through pumps and wakes for mud.",
  "Trusts one chart. It is upside down.",
  "Fears no bear, except the one in the mirror.",
  "Calls every dip an entrance and every peak a snack.",
  "Hears liquidity moving beneath the forest floor.",
  "Carries no alpha, only snacks.",
  "Practices aggressive stillness.",
  "Knows the exit. Refuses to point at it.",
  "Mooed once at the moon. The moon answered."
];

const weaknesses = [
  "Cannot resist a chart drawn in mud.",
  "Panics when the grass is too green.",
  "Believes every anonymous thread.",
  "Gets sentimental around old hardware wallets.",
  "Refuses to cross a bearish bridge.",
  "Mistakes thunder for a market alert.",
  "Collects worthless pebbles with total conviction.",
  "Has a private feud with the moon.",
  "Will trade dignity for one gold tooth.",
  "Forgets the plan whenever the candles move.",
  "Trusts pandas more than auditors.",
  "Needs applause before entering a puddle.",
  "Becomes philosophical after one bad trade.",
  "Cannot say no to ceremonial outerwear.",
  "Sees resistance where there is only a fence.",
  "Thinks every cave contains alpha."
];

const convictions = [
  "MUD IS A LIQUID ASSET.",
  "NO HORN, NO THESIS.",
  "THE FOREST ALWAYS PRICES IT IN.",
  "SLEEP IS A LONG POSITION.",
  "GRASS BEFORE GAS.",
  "NEVER FADE A PANDA.",
  "RED IS JUST GREEN WITH HISTORY.",
  "THE BELL KNOWS FIRST.",
  "A CAVE IS COLD STORAGE.",
  "THE MOON OWES ME MONEY.",
  "HOLD UNTIL THE MUD DRIES.",
  "EVERY EXIT NEEDS A TOURIST.",
  "BULLISH ON BAD WEATHER.",
  "BEARISH ON CLEAN SHOES.",
  "THE CHART IS UPSIDE DOWN ON PURPOSE.",
  "NO SIGNAL IS ALSO A SIGNAL."
];

const firstNames = ["Bruno", "Mallow", "Tusk", "Biscuit", "Crumb", "Marge", "Bramble", "Ticker", "Muddle", "Grit", "Nettle", "Pogo", "Bamboo", "Sludge", "Clover", "Gumbo", "Koda", "Miso"];
const lastNames = ["Dip", "Uptick", "Sideways", "Lowhorn", "Softhoof", "Redweek", "Moonchew", "Dustcoat", "Wobble", "Noonbell", "Mudwallet", "Longnap", "Grasshand", "Topbuyer", "Cloudhoof"];

export function hashSeed(seed) {
  let h = 2166136261;
  const text = String(seed);
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function randomFrom(seed) {
  let state = hashSeed(seed);
  return () => {
    state += 0x6d2b79f5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick(pool, random) {
  const total = pool.reduce((sum, item) => sum + item.weight, 0);
  let cursor = random() * total;
  for (const item of pool) {
    cursor -= item.weight;
    if (cursor <= 0) return { ...item };
  }
  return { ...pool.at(-1) };
}

const ACCESSORY_DEFAULTS = {
  headwear: "none",
  mouth: "flat",
  neck: "none",
  aura: "none",
  outfit: "bare",
  weather: "clear"
};

function enforceAccessoryBudget(traits, random) {
  // Props are punctuation, not identity. Most of the canonical reference set is
  // carried by anatomy, lineage, form and habitat, so only about one in five
  // tokens retains a visible optional accessory.
  const budget = random() < 0.22 ? 1 : 0;
  const active = Object.entries(ACCESSORY_DEFAULTS)
    .filter(([key, defaultValue]) => traits[key].value !== defaultValue)
    .map(([key]) => ({ key, priority: random() }))
    .sort((left, right) => left.priority - right.priority);
  const keep = new Set(active.slice(0, budget).map(({ key }) => key));
  active.slice(budget).forEach(({ key }) => {
    traits[key] = { ...pools[key].find((item) => item.value === ACCESSORY_DEFAULTS[key]) };
  });
  if (traits.headwear.value === "visor" && traits.eyes.value === "shades") {
    traits.eyes = { ...pools.eyes.find((item) => item.value === "wide") };
  }
  return keep.size;
}

export function genotypeFor(balance) {
  if (balance < 20) return { label: "Bear Dominant", rarity: "common" };
  if (balance < 45) return { label: "Bear-leaning", rarity: "common" };
  if (balance <= 55) return { label: "Perfect Hybrid", rarity: "epic" };
  if (balance <= 80) return { label: "Bull-leaning", rarity: "common" };
  return { label: "Bull Dominant", rarity: "common" };
}

export function spectrumAnatomy(balance) {
  if (!Number.isFinite(balance) || balance < 0 || balance > 100) {
    throw new RangeError("Bull percentage must be between 0 and 100.");
  }
  const bullness = balance / 100;
  const even = (value) => Math.round(value / 2) * 2;
  return {
    bullness,
    // Horns are part of the universal BearBull emblem. The spectrum changes
    // their reach and height, but even the most bear-dominant animal keeps a
    // compact, readable pair.
    hornStage: balance < 35 ? 1 : balance < 65 ? 2 : 3,
    earMode: balance < 40 ? "bear" : balance < 65 ? "hybrid" : "bull",
    // The cranium remains compact across the spectrum. Bull identity comes
    // from a longer nasal bridge, lateral ears and horn profile—not a taller
    // rectangular muzzle pasted onto a bear mask.
    headWidth: even(42 - bullness * 4),
    headHeight: even(40 + bullness * 4),
    muzzleWidth: even(18 + bullness * 4),
    muzzleHeight: even(16 + bullness * 4),
    lowerFaceTaper: balance < 35 ? 2 : balance < 65 ? 4 : 6
  };
}

export function hornExpressionFor(item) {
  const horns = item?.traits?.horns;
  if (!horns) throw new TypeError("A BearBull with a horns trait is required.");
  const stage = spectrumAnatomy(item.balance).hornStage;
  if (stage === 1) return `Bear Crown · ${horns.label}`;
  if (stage === 2) return `Hybrid Crown · ${horns.label}`;
  return horns.label;
}

export function rarityFor(points) {
  if (points >= 57) return "MYTHIC";
  if (points >= 47) return "EPIC";
  if (points >= 36) return "RARE";
  if (points >= 24) return "UNCOMMON";
  return "COMMON";
}

export function scoreBearBull(item) {
  return RARITY_POINTS[item.genotype.rarity] + Object.values(item.traits).reduce((sum, current) => sum + (RARITY_POINTS[current.rarity] ?? 0), 0);
}

function paletteFor(bearKind, coat, form) {
  const forms = {
    zombie: { coat: "#8faa67", shade: "#405637", mark: "#d1df8d" },
    skull: { coat: "#f0e4c9", shade: "#a18a70", mark: "#fff1d5" },
    hollow: { coat: "#34375d", shade: "#111424", mark: "#6f92ef" },
    possessed: { coat: "#2a3034", shade: "#101719", mark: "#6c8de5" }
  };
  // Robot is a cyborg treatment, not a replacement species. Keeping the
  // inherited hide color makes its bear/bull anatomy lead, while the metal
  // shade and mint circuitry preserve the form at icon scale.
  if (form.value === "robot") {
    return {
      coat: coat.override || bearKind.coat,
      shade: "#455b64",
      mark: "#83ebcf"
    };
  }
  if (forms[form.value]) return forms[form.value];
  return {
    coat: coat.override || bearKind.coat,
    shade: coat.shade || bearKind.shade,
    mark: coat.value === "natural" || coat.value === "mud" ? bearKind.mark : "#f3e6cb"
  };
}

export function generateBearBull(seed) {
  const normalizedSeed = String(seed || "bearbull");
  const random = randomFrom(normalizedSeed);
  const balance = Math.floor(random() * 101);
  const genotype = genotypeFor(balance);
  const bearKind = pick(pools.bearKind, random);
  const bullKind = pick(pools.bullKind, random);
  const form = pick(pools.form, random);
  const coat = pick(pools.coat, random);
  const septumRandom = randomFrom(`${normalizedSeed}:septum`);
  const traits = {
    bearKind,
    bullKind,
    form,
    coat,
    silhouette: pick(pools.silhouette, random),
    faceLayout: pick(pools.faceLayout, random),
    muzzle: pick(pools.muzzle, random),
    septum: pick(pools.septum, septumRandom),
    marking: pick(pools.marking, random),
    outfit: pick(foundationPools.outfit, random),
    pose: pick(pools.pose, random),
    weather: pick(pools.weather, random),
    horns: pick(foundationPools.horns, random),
    eyes: pick(foundationPools.eyes, random),
    headwear: pick(foundationPools.headwear, random),
    mouth: pick(pools.mouth, random),
    neck: pick(foundationPools.neck, random),
    aura: pick(pools.aura, random),
    backdrop: pick(foundationPools.backdrop, random),
    voice: pick(pools.voice, random),
    archetype: pick(pools.archetype, random)
  };
  const accessoryCount = enforceAccessoryBudget(traits, random);
  const mood = moods[Math.floor(random() * moods.length)];
  const personality = {
    title: `${traits.form.value === "normie" ? "" : `${traits.form.label} `}${mood.label} ${traits.archetype.label}`,
    mood: mood.label,
    energy: mood.energy,
    habit: habits[Math.floor(random() * habits.length)],
    weakness: weaknesses[Math.floor(random() * weaknesses.length)],
    conviction: convictions[Math.floor(random() * convictions.length)]
  };
  const item = {
    seed: normalizedSeed,
    id: hashSeed(normalizedSeed) % 10000,
    name: `${firstNames[Math.floor(random() * firstNames.length)]} ${lastNames[Math.floor(random() * lastNames.length)]}`,
    balance,
    genotype,
    traits,
    personality,
    palette: paletteFor(bearKind, coat, form),
    points: 0,
    rarity: "COMMON",
    cadence: Math.max(18, 58 - mood.energy * 8 + Math.floor(random() * 12)),
    phase: Math.floor(random() * 20),
    accessoryCount,
    tokenId: null,
    collisionNonce: 0,
    tokenGlyph: null
  };
  applyIconicTraits(item);
  applyFinishTraits(item);
  applyInsiderTraits(item);
  item.points = scoreBearBull(item);
  item.rarity = rarityFor(item.points);
  return item;
}

export function tokenGlyphFor(tokenId) {
  const id = normalizeTokenId(tokenId);
  const scrambled = (Math.imul(id + 1, 4051) ^ 0x2b67) & 0x3fff;
  return {
    code: `G-${scrambled.toString(16).toUpperCase().padStart(4, "0")}`,
    bits: scrambled.toString(2).padStart(14, "0")
  };
}

export function normalizeTokenId(tokenId) {
  const parsed = Number(tokenId);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed >= COLLECTION_SIZE) {
    throw new RangeError(`Token ID must be an integer from 0 to ${COLLECTION_SIZE - 1}.`);
  }
  return parsed;
}

export function generateBearBullForToken(tokenId, namespace = COLLECTION_NAMESPACE, collisionNonce = 0) {
  const id = normalizeTokenId(tokenId);
  if (!Number.isInteger(collisionNonce) || collisionNonce < 0) throw new RangeError("Collision nonce must be a non-negative integer.");
  const item = generateBearBull(`${namespace}:${String(id).padStart(4, "0")}:${collisionNonce}`);
  item.id = id;
  item.tokenId = id;
  item.collisionNonce = collisionNonce;
  item.tokenGlyph = tokenGlyphFor(id);
  return item;
}

const VISUAL_TRAITS = [
  "bearKind", "bullKind", "form", "coat", "silhouette", "faceLayout", "muzzle", "septum", "marking",
  "outfit", "pose", "weather", "horns", "eyes", "ears", "headwear", "mouth", "neck", "aura", "backdrop"
];

const METADATA_TRAIT_NAMES = {
  form: "Form",
  coat: "Coat",
  silhouette: "Silhouette",
  faceLayout: "Face Layout",
  muzzle: "Muzzle",
  septum: "Septum",
  marking: "Marking",
  outfit: "Outfit",
  pose: "Pose",
  weather: "Weather",
  horns: "Horns",
  eyes: "Eyes",
  ears: "Ears",
  headwear: "Headwear",
  mouth: "Mouth",
  neck: "Neck Artifact",
  aura: "Aura",
  backdrop: "Habitat",
  voice: "Voice",
  archetype: "Archetype"
};

export function visualSignature(item) {
  return [
    item.balance,
    ...VISUAL_TRAITS.map((key) => item.traits[key].value)
  ].join("|");
}

export function generateCollection(size = COLLECTION_SIZE, namespace = COLLECTION_NAMESPACE) {
  if (!Number.isInteger(size) || size < 1 || size > COLLECTION_SIZE) {
    throw new RangeError(`Collection size must be an integer from 1 to ${COLLECTION_SIZE}.`);
  }
  const signatures = new Set();
  const collection = [];
  for (let tokenId = 0; tokenId < size; tokenId += 1) {
    let collisionNonce = 0;
    let item = generateBearBullForToken(tokenId, namespace, collisionNonce);
    let signature = visualSignature(item);
    while (signatures.has(signature)) {
      collisionNonce += 1;
      item = generateBearBullForToken(tokenId, namespace, collisionNonce);
      signature = visualSignature(item);
      if (collisionNonce > 255) throw new Error(`Could not resolve visual collision for token ${tokenId}.`);
    }
    signatures.add(signature);
    collection.push(item);
  }
  return collection;
}

export function metadataFor(item, image = null) {
  const id = normalizeTokenId(item.tokenId ?? item.id);
  const attributes = [
    { trait_type: "Bear DNA", value: item.traits.bearKind.label },
    { trait_type: "Bull DNA", value: item.traits.bullKind.label },
    { trait_type: "Bull Percentage", display_type: "number", value: item.balance },
    { trait_type: "Horn Expression", value: hornExpressionFor(item) },
    { trait_type: "Genotype", value: item.genotype.label },
    ...Object.entries(item.traits)
      .filter(([key]) => !["bearKind", "bullKind"].includes(key))
      .map(([key, value]) => ({ trait_type: METADATA_TRAIT_NAMES[key] ?? key, value: value.label })),
    { trait_type: "Personality", value: item.personality.title },
    { trait_type: "Conviction", value: item.personality.conviction },
    { trait_type: "Rarity", value: item.rarity },
    { trait_type: "Background Rarity", value: item.rarity },
    { trait_type: "Rarity Points", display_type: "number", value: item.points },
    { trait_type: "Genesis Glyph", value: item.tokenGlyph?.code ?? tokenGlyphFor(id).code }
  ];
  const metadata = {
    name: `BearBull #${String(id).padStart(4, "0")} — ${item.name}`,
    description: "An original animated BearBull caught somewhere between bear weather and bull conviction.",
    attributes
  };
  if (image) metadata.image = image;
  return metadata;
}

export function randomSeed() {
  if (globalThis.crypto?.getRandomValues) {
    const values = new Uint32Array(2);
    globalThis.crypto.getRandomValues(values);
    return `bb-${values[0].toString(36)}-${values[1].toString(36)}`;
  }
  return `bb-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
